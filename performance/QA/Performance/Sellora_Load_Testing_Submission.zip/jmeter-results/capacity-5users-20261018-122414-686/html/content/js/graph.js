/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 461.0, "minX": 0.0, "maxY": 10714.0, "series": [{"data": [[0.0, 461.0], [0.1, 461.0], [0.2, 461.0], [0.3, 462.0], [0.4, 462.0], [0.5, 462.0], [0.6, 462.0], [0.7, 462.0], [0.8, 465.0], [0.9, 465.0], [1.0, 466.0], [1.1, 466.0], [1.2, 466.0], [1.3, 466.0], [1.4, 466.0], [1.5, 466.0], [1.6, 466.0], [1.7, 467.0], [1.8, 467.0], [1.9, 467.0], [2.0, 467.0], [2.1, 467.0], [2.2, 468.0], [2.3, 468.0], [2.4, 468.0], [2.5, 468.0], [2.6, 468.0], [2.7, 468.0], [2.8, 468.0], [2.9, 469.0], [3.0, 469.0], [3.1, 469.0], [3.2, 469.0], [3.3, 469.0], [3.4, 469.0], [3.5, 469.0], [3.6, 470.0], [3.7, 470.0], [3.8, 470.0], [3.9, 470.0], [4.0, 470.0], [4.1, 470.0], [4.2, 470.0], [4.3, 471.0], [4.4, 471.0], [4.5, 471.0], [4.6, 471.0], [4.7, 471.0], [4.8, 471.0], [4.9, 471.0], [5.0, 471.0], [5.1, 471.0], [5.2, 471.0], [5.3, 471.0], [5.4, 471.0], [5.5, 471.0], [5.6, 471.0], [5.7, 472.0], [5.8, 472.0], [5.9, 472.0], [6.0, 472.0], [6.1, 472.0], [6.2, 473.0], [6.3, 473.0], [6.4, 473.0], [6.5, 473.0], [6.6, 473.0], [6.7, 473.0], [6.8, 473.0], [6.9, 474.0], [7.0, 474.0], [7.1, 475.0], [7.2, 475.0], [7.3, 475.0], [7.4, 475.0], [7.5, 475.0], [7.6, 476.0], [7.7, 476.0], [7.8, 476.0], [7.9, 476.0], [8.0, 477.0], [8.1, 477.0], [8.2, 477.0], [8.3, 477.0], [8.4, 477.0], [8.5, 477.0], [8.6, 477.0], [8.7, 477.0], [8.8, 477.0], [8.9, 477.0], [9.0, 477.0], [9.1, 477.0], [9.2, 477.0], [9.3, 477.0], [9.4, 477.0], [9.5, 478.0], [9.6, 478.0], [9.7, 478.0], [9.8, 478.0], [9.9, 478.0], [10.0, 478.0], [10.1, 478.0], [10.2, 478.0], [10.3, 478.0], [10.4, 478.0], [10.5, 478.0], [10.6, 478.0], [10.7, 478.0], [10.8, 478.0], [10.9, 478.0], [11.0, 478.0], [11.1, 478.0], [11.2, 478.0], [11.3, 478.0], [11.4, 478.0], [11.5, 478.0], [11.6, 479.0], [11.7, 479.0], [11.8, 479.0], [11.9, 479.0], [12.0, 479.0], [12.1, 479.0], [12.2, 479.0], [12.3, 479.0], [12.4, 479.0], [12.5, 480.0], [12.6, 480.0], [12.7, 480.0], [12.8, 480.0], [12.9, 480.0], [13.0, 480.0], [13.1, 480.0], [13.2, 480.0], [13.3, 480.0], [13.4, 480.0], [13.5, 480.0], [13.6, 480.0], [13.7, 480.0], [13.8, 480.0], [13.9, 480.0], [14.0, 480.0], [14.1, 480.0], [14.2, 481.0], [14.3, 481.0], [14.4, 481.0], [14.5, 481.0], [14.6, 481.0], [14.7, 481.0], [14.8, 481.0], [14.9, 482.0], [15.0, 482.0], [15.1, 482.0], [15.2, 482.0], [15.3, 482.0], [15.4, 482.0], [15.5, 482.0], [15.6, 482.0], [15.7, 482.0], [15.8, 482.0], [15.9, 482.0], [16.0, 482.0], [16.1, 482.0], [16.2, 482.0], [16.3, 482.0], [16.4, 482.0], [16.5, 483.0], [16.6, 483.0], [16.7, 483.0], [16.8, 483.0], [16.9, 483.0], [17.0, 483.0], [17.1, 483.0], [17.2, 483.0], [17.3, 483.0], [17.4, 483.0], [17.5, 483.0], [17.6, 483.0], [17.7, 483.0], [17.8, 483.0], [17.9, 483.0], [18.0, 483.0], [18.1, 483.0], [18.2, 483.0], [18.3, 483.0], [18.4, 483.0], [18.5, 483.0], [18.6, 483.0], [18.7, 483.0], [18.8, 483.0], [18.9, 484.0], [19.0, 484.0], [19.1, 484.0], [19.2, 484.0], [19.3, 484.0], [19.4, 484.0], [19.5, 484.0], [19.6, 484.0], [19.7, 484.0], [19.8, 484.0], [19.9, 484.0], [20.0, 484.0], [20.1, 484.0], [20.2, 484.0], [20.3, 485.0], [20.4, 485.0], [20.5, 485.0], [20.6, 485.0], [20.7, 485.0], [20.8, 485.0], [20.9, 485.0], [21.0, 485.0], [21.1, 485.0], [21.2, 485.0], [21.3, 485.0], [21.4, 485.0], [21.5, 486.0], [21.6, 486.0], [21.7, 486.0], [21.8, 486.0], [21.9, 486.0], [22.0, 486.0], [22.1, 486.0], [22.2, 486.0], [22.3, 486.0], [22.4, 486.0], [22.5, 486.0], [22.6, 486.0], [22.7, 486.0], [22.8, 486.0], [22.9, 486.0], [23.0, 486.0], [23.1, 486.0], [23.2, 486.0], [23.3, 486.0], [23.4, 486.0], [23.5, 486.0], [23.6, 486.0], [23.7, 486.0], [23.8, 487.0], [23.9, 487.0], [24.0, 487.0], [24.1, 487.0], [24.2, 487.0], [24.3, 487.0], [24.4, 487.0], [24.5, 487.0], [24.6, 487.0], [24.7, 487.0], [24.8, 487.0], [24.9, 487.0], [25.0, 488.0], [25.1, 488.0], [25.2, 488.0], [25.3, 488.0], [25.4, 488.0], [25.5, 488.0], [25.6, 488.0], [25.7, 488.0], [25.8, 488.0], [25.9, 488.0], [26.0, 488.0], [26.1, 488.0], [26.2, 488.0], [26.3, 488.0], [26.4, 488.0], [26.5, 488.0], [26.6, 489.0], [26.7, 489.0], [26.8, 489.0], [26.9, 489.0], [27.0, 489.0], [27.1, 489.0], [27.2, 489.0], [27.3, 489.0], [27.4, 489.0], [27.5, 489.0], [27.6, 489.0], [27.7, 489.0], [27.8, 489.0], [27.9, 489.0], [28.0, 489.0], [28.1, 489.0], [28.2, 489.0], [28.3, 489.0], [28.4, 489.0], [28.5, 489.0], [28.6, 489.0], [28.7, 489.0], [28.8, 490.0], [28.9, 490.0], [29.0, 490.0], [29.1, 490.0], [29.2, 490.0], [29.3, 490.0], [29.4, 490.0], [29.5, 490.0], [29.6, 490.0], [29.7, 490.0], [29.8, 490.0], [29.9, 490.0], [30.0, 490.0], [30.1, 490.0], [30.2, 490.0], [30.3, 490.0], [30.4, 490.0], [30.5, 490.0], [30.6, 490.0], [30.7, 490.0], [30.8, 490.0], [30.9, 490.0], [31.0, 490.0], [31.1, 490.0], [31.2, 490.0], [31.3, 490.0], [31.4, 490.0], [31.5, 490.0], [31.6, 491.0], [31.7, 491.0], [31.8, 491.0], [31.9, 491.0], [32.0, 491.0], [32.1, 491.0], [32.2, 491.0], [32.3, 491.0], [32.4, 491.0], [32.5, 491.0], [32.6, 491.0], [32.7, 491.0], [32.8, 491.0], [32.9, 491.0], [33.0, 492.0], [33.1, 492.0], [33.2, 492.0], [33.3, 492.0], [33.4, 492.0], [33.5, 492.0], [33.6, 492.0], [33.7, 492.0], [33.8, 492.0], [33.9, 493.0], [34.0, 493.0], [34.1, 493.0], [34.2, 493.0], [34.3, 493.0], [34.4, 493.0], [34.5, 493.0], [34.6, 493.0], [34.7, 493.0], [34.8, 493.0], [34.9, 493.0], [35.0, 493.0], [35.1, 493.0], [35.2, 493.0], [35.3, 494.0], [35.4, 494.0], [35.5, 494.0], [35.6, 494.0], [35.7, 494.0], [35.8, 494.0], [35.9, 494.0], [36.0, 494.0], [36.1, 494.0], [36.2, 494.0], [36.3, 494.0], [36.4, 494.0], [36.5, 494.0], [36.6, 494.0], [36.7, 494.0], [36.8, 494.0], [36.9, 494.0], [37.0, 494.0], [37.1, 494.0], [37.2, 494.0], [37.3, 494.0], [37.4, 494.0], [37.5, 494.0], [37.6, 494.0], [37.7, 494.0], [37.8, 494.0], [37.9, 495.0], [38.0, 495.0], [38.1, 495.0], [38.2, 495.0], [38.3, 495.0], [38.4, 495.0], [38.5, 495.0], [38.6, 496.0], [38.7, 496.0], [38.8, 496.0], [38.9, 496.0], [39.0, 496.0], [39.1, 496.0], [39.2, 496.0], [39.3, 496.0], [39.4, 496.0], [39.5, 496.0], [39.6, 496.0], [39.7, 496.0], [39.8, 496.0], [39.9, 496.0], [40.0, 497.0], [40.1, 497.0], [40.2, 497.0], [40.3, 497.0], [40.4, 497.0], [40.5, 497.0], [40.6, 497.0], [40.7, 497.0], [40.8, 497.0], [40.9, 497.0], [41.0, 497.0], [41.1, 497.0], [41.2, 497.0], [41.3, 497.0], [41.4, 497.0], [41.5, 497.0], [41.6, 497.0], [41.7, 497.0], [41.8, 497.0], [41.9, 497.0], [42.0, 497.0], [42.1, 497.0], [42.2, 497.0], [42.3, 497.0], [42.4, 497.0], [42.5, 497.0], [42.6, 498.0], [42.7, 498.0], [42.8, 498.0], [42.9, 498.0], [43.0, 498.0], [43.1, 498.0], [43.2, 498.0], [43.3, 498.0], [43.4, 498.0], [43.5, 498.0], [43.6, 498.0], [43.7, 498.0], [43.8, 498.0], [43.9, 498.0], [44.0, 498.0], [44.1, 498.0], [44.2, 498.0], [44.3, 498.0], [44.4, 498.0], [44.5, 498.0], [44.6, 498.0], [44.7, 498.0], [44.8, 499.0], [44.9, 499.0], [45.0, 500.0], [45.1, 500.0], [45.2, 500.0], [45.3, 500.0], [45.4, 500.0], [45.5, 500.0], [45.6, 500.0], [45.7, 500.0], [45.8, 500.0], [45.9, 500.0], [46.0, 500.0], [46.1, 500.0], [46.2, 501.0], [46.3, 501.0], [46.4, 501.0], [46.5, 501.0], [46.6, 502.0], [46.7, 502.0], [46.8, 502.0], [46.9, 502.0], [47.0, 502.0], [47.1, 502.0], [47.2, 502.0], [47.3, 503.0], [47.4, 503.0], [47.5, 503.0], [47.6, 503.0], [47.7, 503.0], [47.8, 503.0], [47.9, 503.0], [48.0, 504.0], [48.1, 504.0], [48.2, 504.0], [48.3, 504.0], [48.4, 504.0], [48.5, 504.0], [48.6, 504.0], [48.7, 504.0], [48.8, 504.0], [48.9, 504.0], [49.0, 504.0], [49.1, 504.0], [49.2, 504.0], [49.3, 504.0], [49.4, 504.0], [49.5, 504.0], [49.6, 504.0], [49.7, 505.0], [49.8, 505.0], [49.9, 506.0], [50.0, 506.0], [50.1, 506.0], [50.2, 506.0], [50.3, 506.0], [50.4, 506.0], [50.5, 506.0], [50.6, 506.0], [50.7, 506.0], [50.8, 506.0], [50.9, 506.0], [51.0, 506.0], [51.1, 507.0], [51.2, 507.0], [51.3, 507.0], [51.4, 507.0], [51.5, 507.0], [51.6, 508.0], [51.7, 508.0], [51.8, 508.0], [51.9, 508.0], [52.0, 508.0], [52.1, 508.0], [52.2, 508.0], [52.3, 508.0], [52.4, 508.0], [52.5, 508.0], [52.6, 508.0], [52.7, 508.0], [52.8, 508.0], [52.9, 508.0], [53.0, 508.0], [53.1, 508.0], [53.2, 508.0], [53.3, 508.0], [53.4, 508.0], [53.5, 509.0], [53.6, 509.0], [53.7, 509.0], [53.8, 509.0], [53.9, 509.0], [54.0, 509.0], [54.1, 509.0], [54.2, 509.0], [54.3, 509.0], [54.4, 509.0], [54.5, 509.0], [54.6, 509.0], [54.7, 509.0], [54.8, 509.0], [54.9, 509.0], [55.0, 509.0], [55.1, 510.0], [55.2, 510.0], [55.3, 510.0], [55.4, 510.0], [55.5, 510.0], [55.6, 510.0], [55.7, 510.0], [55.8, 511.0], [55.9, 511.0], [56.0, 511.0], [56.1, 511.0], [56.2, 511.0], [56.3, 512.0], [56.4, 512.0], [56.5, 512.0], [56.6, 512.0], [56.7, 512.0], [56.8, 512.0], [56.9, 512.0], [57.0, 512.0], [57.1, 512.0], [57.2, 513.0], [57.3, 513.0], [57.4, 513.0], [57.5, 514.0], [57.6, 514.0], [57.7, 514.0], [57.8, 514.0], [57.9, 514.0], [58.0, 514.0], [58.1, 514.0], [58.2, 515.0], [58.3, 515.0], [58.4, 515.0], [58.5, 515.0], [58.6, 516.0], [58.7, 516.0], [58.8, 516.0], [58.9, 516.0], [59.0, 516.0], [59.1, 518.0], [59.2, 518.0], [59.3, 519.0], [59.4, 519.0], [59.5, 519.0], [59.6, 519.0], [59.7, 519.0], [59.8, 520.0], [59.9, 520.0], [60.0, 521.0], [60.1, 521.0], [60.2, 521.0], [60.3, 522.0], [60.4, 522.0], [60.5, 525.0], [60.6, 525.0], [60.7, 525.0], [60.8, 525.0], [60.9, 525.0], [61.0, 525.0], [61.1, 525.0], [61.2, 526.0], [61.3, 526.0], [61.4, 526.0], [61.5, 527.0], [61.6, 527.0], [61.7, 527.0], [61.8, 527.0], [61.9, 528.0], [62.0, 528.0], [62.1, 528.0], [62.2, 528.0], [62.3, 528.0], [62.4, 531.0], [62.5, 531.0], [62.6, 531.0], [62.7, 531.0], [62.8, 531.0], [62.9, 532.0], [63.0, 532.0], [63.1, 532.0], [63.2, 532.0], [63.3, 532.0], [63.4, 532.0], [63.5, 532.0], [63.6, 533.0], [63.7, 533.0], [63.8, 535.0], [63.9, 535.0], [64.0, 537.0], [64.1, 537.0], [64.2, 537.0], [64.3, 538.0], [64.4, 538.0], [64.5, 538.0], [64.6, 538.0], [64.7, 538.0], [64.8, 541.0], [64.9, 541.0], [65.0, 542.0], [65.1, 542.0], [65.2, 545.0], [65.3, 545.0], [65.4, 545.0], [65.5, 546.0], [65.6, 546.0], [65.7, 549.0], [65.8, 549.0], [65.9, 549.0], [66.0, 549.0], [66.1, 549.0], [66.2, 550.0], [66.3, 550.0], [66.4, 551.0], [66.5, 551.0], [66.6, 551.0], [66.7, 551.0], [66.8, 551.0], [66.9, 552.0], [67.0, 552.0], [67.1, 555.0], [67.2, 555.0], [67.3, 561.0], [67.4, 561.0], [67.5, 561.0], [67.6, 561.0], [67.7, 561.0], [67.8, 567.0], [67.9, 567.0], [68.0, 569.0], [68.1, 569.0], [68.2, 569.0], [68.3, 570.0], [68.4, 570.0], [68.5, 576.0], [68.6, 576.0], [68.7, 576.0], [68.8, 587.0], [68.9, 587.0], [69.0, 591.0], [69.1, 591.0], [69.2, 593.0], [69.3, 593.0], [69.4, 593.0], [69.5, 595.0], [69.6, 595.0], [69.7, 601.0], [69.8, 601.0], [69.9, 601.0], [70.0, 601.0], [70.1, 601.0], [70.2, 606.0], [70.3, 606.0], [70.4, 612.0], [70.5, 612.0], [70.6, 619.0], [70.7, 619.0], [70.8, 619.0], [70.9, 647.0], [71.0, 647.0], [71.1, 649.0], [71.2, 649.0], [71.3, 659.0], [71.4, 659.0], [71.5, 659.0], [71.6, 660.0], [71.7, 660.0], [71.8, 661.0], [71.9, 661.0], [72.0, 665.0], [72.1, 665.0], [72.2, 665.0], [72.3, 666.0], [72.4, 666.0], [72.5, 666.0], [72.6, 666.0], [72.7, 666.0], [72.8, 675.0], [72.9, 675.0], [73.0, 675.0], [73.1, 675.0], [73.2, 676.0], [73.3, 676.0], [73.4, 676.0], [73.5, 679.0], [73.6, 679.0], [73.7, 679.0], [73.8, 679.0], [73.9, 680.0], [74.0, 680.0], [74.1, 680.0], [74.2, 681.0], [74.3, 681.0], [74.4, 682.0], [74.5, 682.0], [74.6, 683.0], [74.7, 683.0], [74.8, 683.0], [74.9, 684.0], [75.0, 684.0], [75.1, 686.0], [75.2, 686.0], [75.3, 688.0], [75.4, 688.0], [75.5, 688.0], [75.6, 689.0], [75.7, 689.0], [75.8, 689.0], [75.9, 689.0], [76.0, 690.0], [76.1, 690.0], [76.2, 690.0], [76.3, 691.0], [76.4, 691.0], [76.5, 691.0], [76.6, 691.0], [76.7, 691.0], [76.8, 692.0], [76.9, 692.0], [77.0, 692.0], [77.1, 692.0], [77.2, 693.0], [77.3, 693.0], [77.4, 693.0], [77.5, 694.0], [77.6, 694.0], [77.7, 695.0], [77.8, 695.0], [77.9, 698.0], [78.0, 698.0], [78.1, 698.0], [78.2, 698.0], [78.3, 698.0], [78.4, 699.0], [78.5, 699.0], [78.6, 700.0], [78.7, 700.0], [78.8, 700.0], [78.9, 700.0], [79.0, 700.0], [79.1, 703.0], [79.2, 703.0], [79.3, 703.0], [79.4, 703.0], [79.5, 703.0], [79.6, 703.0], [79.7, 703.0], [79.8, 704.0], [79.9, 704.0], [80.0, 704.0], [80.1, 704.0], [80.2, 704.0], [80.3, 704.0], [80.4, 704.0], [80.5, 705.0], [80.6, 705.0], [80.7, 705.0], [80.8, 707.0], [80.9, 707.0], [81.0, 707.0], [81.1, 707.0], [81.2, 709.0], [81.3, 709.0], [81.4, 709.0], [81.5, 711.0], [81.6, 711.0], [81.7, 711.0], [81.8, 711.0], [81.9, 712.0], [82.0, 712.0], [82.1, 712.0], [82.2, 712.0], [82.3, 712.0], [82.4, 713.0], [82.5, 713.0], [82.6, 713.0], [82.7, 713.0], [82.8, 713.0], [82.9, 715.0], [83.0, 715.0], [83.1, 719.0], [83.2, 719.0], [83.3, 730.0], [83.4, 730.0], [83.5, 730.0], [83.6, 746.0], [83.7, 746.0], [83.8, 749.0], [83.9, 749.0], [84.0, 753.0], [84.1, 753.0], [84.2, 753.0], [84.3, 755.0], [84.4, 755.0], [84.5, 757.0], [84.6, 757.0], [84.7, 757.0], [84.8, 759.0], [84.9, 759.0], [85.0, 764.0], [85.1, 764.0], [85.2, 786.0], [85.3, 786.0], [85.4, 786.0], [85.5, 797.0], [85.6, 797.0], [85.7, 805.0], [85.8, 805.0], [85.9, 851.0], [86.0, 851.0], [86.1, 851.0], [86.2, 885.0], [86.3, 885.0], [86.4, 920.0], [86.5, 920.0], [86.6, 927.0], [86.7, 927.0], [86.8, 927.0], [86.9, 938.0], [87.0, 938.0], [87.1, 938.0], [87.2, 938.0], [87.3, 942.0], [87.4, 942.0], [87.5, 942.0], [87.6, 943.0], [87.7, 943.0], [87.8, 946.0], [87.9, 946.0], [88.0, 946.0], [88.1, 946.0], [88.2, 946.0], [88.3, 950.0], [88.4, 950.0], [88.5, 954.0], [88.6, 954.0], [88.7, 954.0], [88.8, 955.0], [88.9, 955.0], [89.0, 969.0], [89.1, 969.0], [89.2, 979.0], [89.3, 979.0], [89.4, 979.0], [89.5, 997.0], [89.6, 997.0], [89.7, 1002.0], [89.8, 1002.0], [89.9, 1002.0], [90.0, 1002.0], [90.1, 1002.0], [90.2, 1003.0], [90.3, 1003.0], [90.4, 1005.0], [90.5, 1005.0], [90.6, 1009.0], [90.7, 1009.0], [90.8, 1009.0], [90.9, 1067.0], [91.0, 1067.0], [91.1, 1091.0], [91.2, 1091.0], [91.3, 1091.0], [91.4, 1091.0], [91.5, 1091.0], [91.6, 1171.0], [91.7, 1171.0], [91.8, 1227.0], [91.9, 1227.0], [92.0, 1234.0], [92.1, 1234.0], [92.2, 1234.0], [92.3, 1236.0], [92.4, 1236.0], [92.5, 1261.0], [92.6, 1261.0], [92.7, 1261.0], [92.8, 1270.0], [92.9, 1270.0], [93.0, 1348.0], [93.1, 1348.0], [93.2, 1374.0], [93.3, 1374.0], [93.4, 1374.0], [93.5, 1509.0], [93.6, 1509.0], [93.7, 1518.0], [93.8, 1518.0], [93.9, 1548.0], [94.0, 1548.0], [94.1, 1548.0], [94.2, 1551.0], [94.3, 1551.0], [94.4, 1570.0], [94.5, 1570.0], [94.6, 1631.0], [94.7, 1631.0], [94.8, 1631.0], [94.9, 1689.0], [95.0, 1689.0], [95.1, 1705.0], [95.2, 1705.0], [95.3, 1725.0], [95.4, 1725.0], [95.5, 1725.0], [95.6, 1795.0], [95.7, 1795.0], [95.8, 1840.0], [95.9, 1840.0], [96.0, 1904.0], [96.1, 1904.0], [96.2, 1904.0], [96.3, 1923.0], [96.4, 1923.0], [96.5, 1938.0], [96.6, 1938.0], [96.7, 1938.0], [96.8, 1947.0], [96.9, 1947.0], [97.0, 1973.0], [97.1, 1973.0], [97.2, 2084.0], [97.3, 2084.0], [97.4, 2084.0], [97.5, 2111.0], [97.6, 2111.0], [97.7, 2114.0], [97.8, 2114.0], [97.9, 2129.0], [98.0, 2129.0], [98.1, 2129.0], [98.2, 2563.0], [98.3, 2563.0], [98.4, 2687.0], [98.5, 2687.0], [98.6, 2710.0], [98.7, 2710.0], [98.8, 2710.0], [98.9, 3064.0], [99.0, 3064.0], [99.1, 3229.0], [99.2, 3229.0], [99.3, 10233.0], [99.4, 10233.0], [99.5, 10233.0], [99.6, 10238.0], [99.7, 10238.0], [99.8, 10714.0], [99.9, 10714.0]], "isOverall": false, "label": "GET - List Orders", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 400.0, "maxY": 191.0, "series": [{"data": [[2100.0, 3.0], [600.0, 38.0], [10200.0, 2.0], [2500.0, 1.0], [2600.0, 1.0], [10700.0, 1.0], [700.0, 30.0], [2700.0, 1.0], [3000.0, 1.0], [800.0, 3.0], [3200.0, 1.0], [900.0, 14.0], [1000.0, 8.0], [1100.0, 1.0], [1200.0, 5.0], [1300.0, 2.0], [1500.0, 5.0], [400.0, 191.0], [1600.0, 2.0], [1700.0, 3.0], [1800.0, 1.0], [1900.0, 5.0], [500.0, 105.0], [2000.0, 1.0]], "isOverall": false, "label": "GET - List Orders", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 10700.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 5.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 199.0, "series": [{"data": [[0.0, 196.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 199.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [[2.0, 25.0]], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [[3.0, 5.0]], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 3.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 3.6, "minX": 1.792306485E12, "maxY": 5.0, "series": [{"data": [[1.79230662E12, 5.0], [1.792306535E12, 5.0], [1.79230658E12, 5.0], [1.792306495E12, 5.0], [1.79230653E12, 5.0], [1.792306615E12, 5.0], [1.79230649E12, 5.0], [1.792306575E12, 5.0], [1.792306525E12, 5.0], [1.79230661E12, 5.0], [1.792306485E12, 5.0], [1.79230657E12, 5.0], [1.79230652E12, 5.0], [1.792306605E12, 5.0], [1.792306565E12, 5.0], [1.792306555E12, 5.0], [1.7923066E12, 5.0], [1.792306515E12, 5.0], [1.79230656E12, 5.0], [1.79230655E12, 5.0], [1.792306635E12, 3.6], [1.79230651E12, 5.0], [1.792306595E12, 5.0], [1.792306545E12, 5.0], [1.79230663E12, 5.0], [1.792306505E12, 5.0], [1.79230659E12, 5.0], [1.79230654E12, 5.0], [1.792306625E12, 5.0], [1.7923065E12, 5.0], [1.792306585E12, 5.0]], "isOverall": false, "label": "Thread Group", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.792306635E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 552.0, "minX": 1.0, "maxY": 2563.0, "series": [{"data": [[2.0, 552.0], [1.0, 2563.0], [5.0, 726.9598108747041]], "isOverall": false, "label": "GET - List Orders", "isController": false}, {"data": [[4.983529411764706, 730.8682352941173]], "isOverall": false, "label": "GET - List Orders-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 5.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 614.4, "minX": 1.792306485E12, "maxY": 26715.6, "series": [{"data": [[1.79230662E12, 12347.8], [1.792306535E12, 25231.4], [1.79230658E12, 20778.8], [1.792306495E12, 20778.8], [1.79230653E12, 23748.4], [1.792306615E12, 6557.8], [1.79230649E12, 20778.8], [1.792306575E12, 25231.4], [1.792306525E12, 23747.2], [1.79230661E12, 15511.0], [1.792306485E12, 2968.4], [1.79230657E12, 22263.0], [1.79230652E12, 13357.8], [1.792306605E12, 25231.4], [1.792306565E12, 23747.2], [1.792306555E12, 25231.4], [1.7923066E12, 22263.0], [1.792306515E12, 26715.6], [1.79230656E12, 19294.6], [1.79230655E12, 22263.0], [1.792306635E12, 7421.0], [1.79230651E12, 23747.2], [1.792306595E12, 25232.6], [1.792306545E12, 23747.2], [1.79230663E12, 20778.8], [1.792306505E12, 22263.0], [1.79230659E12, 22263.0], [1.79230654E12, 20778.8], [1.792306625E12, 20778.8], [1.7923065E12, 23747.2], [1.792306585E12, 17810.4]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.79230662E12, 2150.4], [1.792306535E12, 5222.4], [1.79230658E12, 4300.8], [1.792306495E12, 4300.8], [1.79230653E12, 4915.2], [1.792306615E12, 1228.8], [1.79230649E12, 4300.8], [1.792306575E12, 5222.4], [1.792306525E12, 4915.2], [1.79230661E12, 3072.0], [1.792306485E12, 614.4], [1.79230657E12, 4608.0], [1.79230652E12, 2764.8], [1.792306605E12, 5222.4], [1.792306565E12, 4915.2], [1.792306555E12, 5222.4], [1.7923066E12, 4608.0], [1.792306515E12, 5529.6], [1.79230656E12, 3993.6], [1.79230655E12, 4608.0], [1.792306635E12, 1536.0], [1.79230651E12, 4915.2], [1.792306595E12, 5222.4], [1.792306545E12, 4915.2], [1.79230663E12, 4300.8], [1.792306505E12, 4608.0], [1.79230659E12, 4608.0], [1.79230654E12, 4300.8], [1.792306625E12, 4300.8], [1.7923065E12, 4915.2], [1.792306585E12, 3686.4]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.792306635E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 486.43749999999994, "minX": 1.792306485E12, "maxY": 3625.8999999999996, "series": [{"data": [[1.79230662E12, 3625.8999999999996], [1.792306535E12, 505.3529411764706], [1.79230658E12, 822.9285714285713], [1.792306495E12, 770.4999999999999], [1.79230653E12, 525.5], [1.792306615E12, 1240.6], [1.79230649E12, 667.7857142857142], [1.792306575E12, 537.7647058823529], [1.792306525E12, 916.0625000000001], [1.79230661E12, 644.5454545454545], [1.792306485E12, 593.5], [1.79230657E12, 541.2], [1.79230652E12, 1055.888888888889], [1.792306605E12, 546.9999999999999], [1.792306565E12, 580.625], [1.792306555E12, 540.3529411764707], [1.7923066E12, 530.1333333333333], [1.792306515E12, 510.66666666666674], [1.79230656E12, 938.6153846153845], [1.79230655E12, 523.6666666666666], [1.792306635E12, 1029.0], [1.79230651E12, 486.43749999999994], [1.792306595E12, 531.5294117647057], [1.792306545E12, 533.5625], [1.79230663E12, 583.7142857142858], [1.792306505E12, 536.0], [1.79230659E12, 865.0666666666666], [1.79230654E12, 798.2142857142856], [1.792306625E12, 895.3571428571428], [1.7923065E12, 796.3125], [1.792306585E12, 724.0]], "isOverall": false, "label": "GET - List Orders", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.792306635E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 486.43749999999994, "minX": 1.792306485E12, "maxY": 1122.2, "series": [{"data": [[1.79230662E12, 507.40000000000003], [1.792306535E12, 505.23529411764713], [1.79230658E12, 822.8571428571428], [1.792306495E12, 770.4999999999999], [1.79230653E12, 521.9375], [1.792306615E12, 1122.2], [1.79230649E12, 667.7142857142857], [1.792306575E12, 537.7647058823529], [1.792306525E12, 916.0625000000001], [1.79230661E12, 573.0909090909091], [1.792306485E12, 593.5], [1.79230657E12, 541.2], [1.79230652E12, 1055.7777777777778], [1.792306605E12, 546.9999999999999], [1.792306565E12, 580.4999999999999], [1.792306555E12, 540.3529411764707], [1.7923066E12, 530.0666666666666], [1.792306515E12, 498.6111111111112], [1.79230656E12, 938.6153846153845], [1.79230655E12, 523.5999999999999], [1.792306635E12, 1029.0], [1.79230651E12, 486.43749999999994], [1.792306595E12, 530.9411764705883], [1.792306545E12, 533.4374999999999], [1.79230663E12, 568.7142857142857], [1.792306505E12, 536.0], [1.79230659E12, 865.0], [1.79230654E12, 796.7142857142856], [1.792306625E12, 880.9285714285714], [1.7923065E12, 796.25], [1.792306585E12, 724.0]], "isOverall": false, "label": "GET - List Orders", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.792306635E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 0.0, "minX": 1.792306485E12, "maxY": 740.8, "series": [{"data": [[1.79230662E12, 43.5], [1.792306535E12, 0.0], [1.79230658E12, 171.14285714285714], [1.792306495E12, 0.0], [1.79230653E12, 0.0], [1.792306615E12, 740.8], [1.79230649E12, 0.0], [1.792306575E12, 0.0], [1.792306525E12, 79.31250000000001], [1.79230661E12, 0.0], [1.792306485E12, 0.0], [1.79230657E12, 0.0], [1.79230652E12, 288.22222222222223], [1.792306605E12, 0.0], [1.792306565E12, 0.0], [1.792306555E12, 0.0], [1.7923066E12, 0.0], [1.792306515E12, 0.0], [1.79230656E12, 0.0], [1.79230655E12, 0.0], [1.792306635E12, 0.0], [1.79230651E12, 0.0], [1.792306595E12, 0.0], [1.792306545E12, 0.0], [1.79230663E12, 0.0], [1.792306505E12, 0.0], [1.79230659E12, 0.0], [1.79230654E12, 0.0], [1.792306625E12, 134.64285714285714], [1.7923065E12, 0.0], [1.792306585E12, 76.41666666666666]], "isOverall": false, "label": "GET - List Orders", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.792306635E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 461.0, "minX": 1.792306485E12, "maxY": 3229.0, "series": [{"data": [[1.79230662E12, 1234.0], [1.792306535E12, 593.0], [1.79230658E12, 1947.0], [1.792306495E12, 1923.0], [1.79230653E12, 601.0], [1.792306615E12, 2687.0], [1.79230649E12, 1227.0], [1.792306575E12, 938.0], [1.792306525E12, 2710.0], [1.79230661E12, 1002.0], [1.792306485E12, 693.0], [1.79230657E12, 699.0], [1.79230652E12, 1938.0], [1.792306605E12, 1551.0], [1.792306565E12, 938.0], [1.792306555E12, 1261.0], [1.7923066E12, 704.0], [1.792306515E12, 711.0], [1.79230656E12, 3229.0], [1.79230655E12, 1005.0], [1.792306635E12, 2563.0], [1.79230651E12, 507.0], [1.792306595E12, 759.0], [1.792306545E12, 700.0], [1.79230663E12, 997.0], [1.792306505E12, 746.0], [1.79230659E12, 2114.0], [1.79230654E12, 2129.0], [1.792306625E12, 3064.0], [1.7923065E12, 1705.0], [1.792306585E12, 1003.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.79230662E12, 476.0], [1.792306535E12, 466.0], [1.79230658E12, 475.0], [1.792306495E12, 478.0], [1.79230653E12, 497.0], [1.792306615E12, 469.0], [1.79230649E12, 470.0], [1.792306575E12, 470.0], [1.792306525E12, 478.0], [1.79230661E12, 462.0], [1.792306485E12, 494.0], [1.79230657E12, 479.0], [1.79230652E12, 466.0], [1.792306605E12, 465.0], [1.792306565E12, 467.0], [1.792306555E12, 462.0], [1.7923066E12, 461.0], [1.792306515E12, 480.0], [1.79230656E12, 490.0], [1.79230655E12, 474.0], [1.792306635E12, 552.0], [1.79230651E12, 468.0], [1.792306595E12, 467.0], [1.792306545E12, 477.0], [1.79230663E12, 489.0], [1.792306505E12, 469.0], [1.79230659E12, 483.0], [1.79230654E12, 469.0], [1.792306625E12, 470.0], [1.7923065E12, 471.0], [1.792306585E12, 498.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.79230662E12, 1234.0], [1.792306535E12, 567.4], [1.79230658E12, 1732.5], [1.792306495E12, 1716.0], [1.79230653E12, 591.2], [1.792306615E12, 2687.0], [1.79230649E12, 1085.0], [1.792306575E12, 719.5999999999998], [1.792306525E12, 2271.8000000000006], [1.79230661E12, 999.7], [1.792306485E12, 693.0], [1.79230657E12, 694.2], [1.79230652E12, 1938.0], [1.792306605E12, 717.3999999999993], [1.792306565E12, 780.5000000000001], [1.792306555E12, 672.1999999999995], [1.7923066E12, 703.4], [1.792306515E12, 535.5000000000002], [1.79230656E12, 2627.3999999999996], [1.79230655E12, 709.2000000000002], [1.792306635E12, 2563.0], [1.79230651E12, 503.5], [1.792306595E12, 723.8], [1.792306545E12, 685.3000000000001], [1.79230663E12, 873.0], [1.792306505E12, 726.2], [1.79230659E12, 2112.2], [1.79230654E12, 1984.5], [1.792306625E12, 2484.0], [1.7923065E12, 1595.1000000000001], [1.792306585E12, 992.8000000000001]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.79230662E12, 1234.0], [1.792306535E12, 593.0], [1.79230658E12, 1947.0], [1.792306495E12, 1923.0], [1.79230653E12, 601.0], [1.792306615E12, 2687.0], [1.79230649E12, 1227.0], [1.792306575E12, 938.0], [1.792306525E12, 2710.0], [1.79230661E12, 1002.0], [1.792306485E12, 693.0], [1.79230657E12, 699.0], [1.79230652E12, 1938.0], [1.792306605E12, 1551.0], [1.792306565E12, 938.0], [1.792306555E12, 1261.0], [1.7923066E12, 704.0], [1.792306515E12, 711.0], [1.79230656E12, 3229.0], [1.79230655E12, 1005.0], [1.792306635E12, 2563.0], [1.79230651E12, 507.0], [1.792306595E12, 759.0], [1.792306545E12, 700.0], [1.79230663E12, 997.0], [1.792306505E12, 746.0], [1.79230659E12, 2114.0], [1.79230654E12, 2129.0], [1.792306625E12, 3064.0], [1.7923065E12, 1705.0], [1.792306585E12, 1003.0]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.79230662E12, 684.0], [1.792306535E12, 494.0], [1.79230658E12, 502.5], [1.792306495E12, 665.0], [1.79230653E12, 510.5], [1.792306615E12, 1228.0], [1.79230649E12, 686.5], [1.792306575E12, 489.0], [1.792306525E12, 547.0], [1.79230661E12, 501.0], [1.792306485E12, 593.5], [1.79230657E12, 508.0], [1.79230652E12, 1002.0], [1.792306605E12, 486.0], [1.792306565E12, 496.5], [1.792306555E12, 497.0], [1.7923066E12, 495.0], [1.792306515E12, 498.0], [1.79230656E12, 660.0], [1.79230655E12, 489.0], [1.792306635E12, 666.0], [1.79230651E12, 486.0], [1.792306595E12, 490.0], [1.792306545E12, 501.5], [1.79230663E12, 542.0], [1.792306505E12, 490.0], [1.79230659E12, 576.0], [1.79230654E12, 525.5], [1.792306625E12, 578.0], [1.7923065E12, 724.0], [1.792306585E12, 681.0]], "isOverall": false, "label": "Median", "isController": false}, {"data": [[1.79230662E12, 1234.0], [1.792306535E12, 593.0], [1.79230658E12, 1947.0], [1.792306495E12, 1923.0], [1.79230653E12, 601.0], [1.792306615E12, 2687.0], [1.79230649E12, 1227.0], [1.792306575E12, 938.0], [1.792306525E12, 2710.0], [1.79230661E12, 1002.0], [1.792306485E12, 693.0], [1.79230657E12, 699.0], [1.79230652E12, 1938.0], [1.792306605E12, 1551.0], [1.792306565E12, 938.0], [1.792306555E12, 1261.0], [1.7923066E12, 704.0], [1.792306515E12, 711.0], [1.79230656E12, 3229.0], [1.79230655E12, 1005.0], [1.792306635E12, 2563.0], [1.79230651E12, 507.0], [1.792306595E12, 759.0], [1.792306545E12, 700.0], [1.79230663E12, 997.0], [1.792306505E12, 746.0], [1.79230659E12, 2114.0], [1.79230654E12, 2129.0], [1.792306625E12, 3064.0], [1.7923065E12, 1705.0], [1.792306585E12, 1003.0]], "isOverall": false, "label": "95th percentile", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.792306635E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 494.0, "minX": 1.0, "maxY": 10238.0, "series": [{"data": [[2.0, 507.5], [4.0, 506.0], [1.0, 507.0], [5.0, 494.0], [3.0, 508.0]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[1.0, 5412.0], [4.0, 10238.0], [3.0, 5750.0]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 5.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 0.0, "minX": 1.0, "maxY": 508.0, "series": [{"data": [[2.0, 507.5], [4.0, 506.0], [1.0, 507.0], [5.0, 494.0], [3.0, 508.0]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[1.0, 0.0], [4.0, 0.0], [3.0, 0.0]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 5.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 0.8, "minX": 1.792306485E12, "maxY": 3.8, "series": [{"data": [[1.79230662E12, 1.4], [1.792306535E12, 3.4], [1.79230658E12, 2.6], [1.792306495E12, 2.8], [1.79230653E12, 3.4], [1.792306615E12, 0.8], [1.79230649E12, 2.8], [1.792306575E12, 3.4], [1.792306525E12, 2.6], [1.79230661E12, 2.8], [1.792306485E12, 1.0], [1.79230657E12, 3.0], [1.79230652E12, 2.4], [1.792306605E12, 3.2], [1.792306565E12, 3.2], [1.792306555E12, 3.2], [1.7923066E12, 3.4], [1.792306515E12, 3.0], [1.79230656E12, 2.6], [1.79230655E12, 3.6], [1.792306635E12, 0.8], [1.79230651E12, 3.8], [1.792306595E12, 3.0], [1.792306545E12, 3.0], [1.79230663E12, 3.0], [1.792306505E12, 3.2], [1.79230659E12, 2.8], [1.79230654E12, 2.6], [1.792306625E12, 2.6], [1.7923065E12, 2.6], [1.792306585E12, 3.0]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.792306635E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 0.2, "minX": 1.792306485E12, "maxY": 3.6, "series": [{"data": [[1.79230662E12, 1.4], [1.792306535E12, 3.4], [1.79230658E12, 2.8], [1.792306495E12, 2.8], [1.79230653E12, 3.2], [1.792306615E12, 0.8], [1.79230649E12, 2.8], [1.792306575E12, 3.4], [1.792306525E12, 3.2], [1.79230661E12, 2.0], [1.792306485E12, 0.4], [1.79230657E12, 3.0], [1.79230652E12, 1.8], [1.792306605E12, 3.4], [1.792306565E12, 3.2], [1.792306555E12, 3.4], [1.7923066E12, 3.0], [1.792306515E12, 3.6], [1.79230656E12, 2.6], [1.79230655E12, 3.0], [1.792306635E12, 1.0], [1.79230651E12, 3.2], [1.792306595E12, 3.4], [1.792306545E12, 3.2], [1.79230663E12, 2.8], [1.792306505E12, 3.0], [1.79230659E12, 3.0], [1.79230654E12, 2.8], [1.792306625E12, 2.8], [1.7923065E12, 3.2], [1.792306585E12, 2.4]], "isOverall": false, "label": "200", "isController": false}, {"data": [[1.79230662E12, 0.6]], "isOverall": false, "label": "Non HTTP response code: java.net.SocketTimeoutException", "isController": false}, {"data": [[1.79230661E12, 0.2], [1.792306615E12, 0.2]], "isOverall": false, "label": "Non HTTP response code: java.net.SocketException", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.792306635E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 0.2, "minX": 1.792306485E12, "maxY": 3.6, "series": [{"data": [[1.79230662E12, 1.4], [1.792306535E12, 3.4], [1.79230658E12, 2.8], [1.792306495E12, 2.8], [1.79230653E12, 3.2], [1.792306615E12, 0.8], [1.79230649E12, 2.8], [1.792306575E12, 3.4], [1.792306525E12, 3.2], [1.79230661E12, 2.0], [1.792306485E12, 0.4], [1.79230657E12, 3.0], [1.79230652E12, 1.8], [1.792306605E12, 3.4], [1.792306565E12, 3.2], [1.792306555E12, 3.4], [1.7923066E12, 3.0], [1.792306515E12, 3.6], [1.79230656E12, 2.6], [1.79230655E12, 3.0], [1.792306635E12, 1.0], [1.79230651E12, 3.2], [1.792306595E12, 3.4], [1.792306545E12, 3.2], [1.79230663E12, 2.8], [1.792306505E12, 3.0], [1.79230659E12, 3.0], [1.79230654E12, 2.8], [1.792306625E12, 2.8], [1.7923065E12, 3.2], [1.792306585E12, 2.4]], "isOverall": false, "label": "GET - List Orders-success", "isController": false}, {"data": [[1.79230662E12, 0.6], [1.79230661E12, 0.2], [1.792306615E12, 0.2]], "isOverall": false, "label": "GET - List Orders-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.792306635E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 0.2, "minX": 1.792306485E12, "maxY": 3.6, "series": [{"data": [[1.79230662E12, 1.4], [1.792306535E12, 3.4], [1.79230658E12, 2.8], [1.792306495E12, 2.8], [1.79230653E12, 3.2], [1.792306615E12, 0.8], [1.79230649E12, 2.8], [1.792306575E12, 3.4], [1.792306525E12, 3.2], [1.79230661E12, 2.0], [1.792306485E12, 0.4], [1.79230657E12, 3.0], [1.79230652E12, 1.8], [1.792306605E12, 3.4], [1.792306565E12, 3.2], [1.792306555E12, 3.4], [1.7923066E12, 3.0], [1.792306515E12, 3.6], [1.79230656E12, 2.6], [1.79230655E12, 3.0], [1.792306635E12, 1.0], [1.79230651E12, 3.2], [1.792306595E12, 3.4], [1.792306545E12, 3.2], [1.79230663E12, 2.8], [1.792306505E12, 3.0], [1.79230659E12, 3.0], [1.79230654E12, 2.8], [1.792306625E12, 2.8], [1.7923065E12, 3.2], [1.792306585E12, 2.4]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [[1.79230662E12, 0.6], [1.79230661E12, 0.2], [1.792306615E12, 0.2]], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.792306635E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

