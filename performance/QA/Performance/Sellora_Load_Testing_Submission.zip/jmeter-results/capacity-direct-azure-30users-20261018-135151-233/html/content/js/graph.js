/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 113.0, "minX": 0.0, "maxY": 3705.0, "series": [{"data": [[0.0, 113.0], [0.1, 116.0], [0.2, 118.0], [0.3, 119.0], [0.4, 119.0], [0.5, 120.0], [0.6, 120.0], [0.7, 121.0], [0.8, 121.0], [0.9, 122.0], [1.0, 122.0], [1.1, 122.0], [1.2, 123.0], [1.3, 123.0], [1.4, 123.0], [1.5, 123.0], [1.6, 124.0], [1.7, 124.0], [1.8, 124.0], [1.9, 124.0], [2.0, 125.0], [2.1, 125.0], [2.2, 125.0], [2.3, 125.0], [2.4, 125.0], [2.5, 126.0], [2.6, 126.0], [2.7, 126.0], [2.8, 126.0], [2.9, 127.0], [3.0, 127.0], [3.1, 127.0], [3.2, 127.0], [3.3, 128.0], [3.4, 128.0], [3.5, 128.0], [3.6, 128.0], [3.7, 128.0], [3.8, 128.0], [3.9, 128.0], [4.0, 128.0], [4.1, 128.0], [4.2, 128.0], [4.3, 129.0], [4.4, 129.0], [4.5, 129.0], [4.6, 129.0], [4.7, 129.0], [4.8, 129.0], [4.9, 130.0], [5.0, 130.0], [5.1, 130.0], [5.2, 130.0], [5.3, 130.0], [5.4, 131.0], [5.5, 131.0], [5.6, 131.0], [5.7, 131.0], [5.8, 131.0], [5.9, 131.0], [6.0, 131.0], [6.1, 131.0], [6.2, 132.0], [6.3, 132.0], [6.4, 132.0], [6.5, 132.0], [6.6, 132.0], [6.7, 132.0], [6.8, 132.0], [6.9, 132.0], [7.0, 132.0], [7.1, 132.0], [7.2, 132.0], [7.3, 133.0], [7.4, 133.0], [7.5, 133.0], [7.6, 133.0], [7.7, 133.0], [7.8, 133.0], [7.9, 133.0], [8.0, 133.0], [8.1, 133.0], [8.2, 133.0], [8.3, 133.0], [8.4, 133.0], [8.5, 134.0], [8.6, 134.0], [8.7, 134.0], [8.8, 134.0], [8.9, 134.0], [9.0, 134.0], [9.1, 134.0], [9.2, 134.0], [9.3, 134.0], [9.4, 134.0], [9.5, 135.0], [9.6, 135.0], [9.7, 135.0], [9.8, 135.0], [9.9, 135.0], [10.0, 135.0], [10.1, 135.0], [10.2, 135.0], [10.3, 135.0], [10.4, 135.0], [10.5, 136.0], [10.6, 136.0], [10.7, 136.0], [10.8, 136.0], [10.9, 136.0], [11.0, 136.0], [11.1, 136.0], [11.2, 136.0], [11.3, 137.0], [11.4, 137.0], [11.5, 137.0], [11.6, 137.0], [11.7, 137.0], [11.8, 137.0], [11.9, 137.0], [12.0, 137.0], [12.1, 137.0], [12.2, 137.0], [12.3, 137.0], [12.4, 137.0], [12.5, 137.0], [12.6, 137.0], [12.7, 137.0], [12.8, 137.0], [12.9, 138.0], [13.0, 138.0], [13.1, 138.0], [13.2, 138.0], [13.3, 138.0], [13.4, 138.0], [13.5, 138.0], [13.6, 138.0], [13.7, 138.0], [13.8, 138.0], [13.9, 139.0], [14.0, 139.0], [14.1, 139.0], [14.2, 139.0], [14.3, 139.0], [14.4, 139.0], [14.5, 139.0], [14.6, 139.0], [14.7, 139.0], [14.8, 139.0], [14.9, 139.0], [15.0, 140.0], [15.1, 140.0], [15.2, 140.0], [15.3, 140.0], [15.4, 140.0], [15.5, 140.0], [15.6, 140.0], [15.7, 140.0], [15.8, 140.0], [15.9, 140.0], [16.0, 140.0], [16.1, 141.0], [16.2, 141.0], [16.3, 141.0], [16.4, 141.0], [16.5, 141.0], [16.6, 141.0], [16.7, 141.0], [16.8, 141.0], [16.9, 141.0], [17.0, 141.0], [17.1, 141.0], [17.2, 141.0], [17.3, 141.0], [17.4, 141.0], [17.5, 141.0], [17.6, 142.0], [17.7, 142.0], [17.8, 142.0], [17.9, 142.0], [18.0, 142.0], [18.1, 142.0], [18.2, 142.0], [18.3, 142.0], [18.4, 142.0], [18.5, 142.0], [18.6, 142.0], [18.7, 142.0], [18.8, 142.0], [18.9, 143.0], [19.0, 143.0], [19.1, 143.0], [19.2, 143.0], [19.3, 143.0], [19.4, 143.0], [19.5, 143.0], [19.6, 143.0], [19.7, 143.0], [19.8, 143.0], [19.9, 143.0], [20.0, 143.0], [20.1, 143.0], [20.2, 143.0], [20.3, 143.0], [20.4, 143.0], [20.5, 143.0], [20.6, 144.0], [20.7, 144.0], [20.8, 144.0], [20.9, 144.0], [21.0, 144.0], [21.1, 144.0], [21.2, 144.0], [21.3, 144.0], [21.4, 144.0], [21.5, 144.0], [21.6, 144.0], [21.7, 144.0], [21.8, 144.0], [21.9, 144.0], [22.0, 144.0], [22.1, 144.0], [22.2, 145.0], [22.3, 145.0], [22.4, 145.0], [22.5, 145.0], [22.6, 145.0], [22.7, 145.0], [22.8, 145.0], [22.9, 145.0], [23.0, 145.0], [23.1, 145.0], [23.2, 145.0], [23.3, 145.0], [23.4, 145.0], [23.5, 145.0], [23.6, 146.0], [23.7, 146.0], [23.8, 146.0], [23.9, 146.0], [24.0, 146.0], [24.1, 146.0], [24.2, 146.0], [24.3, 146.0], [24.4, 146.0], [24.5, 146.0], [24.6, 146.0], [24.7, 146.0], [24.8, 146.0], [24.9, 146.0], [25.0, 147.0], [25.1, 147.0], [25.2, 147.0], [25.3, 147.0], [25.4, 147.0], [25.5, 147.0], [25.6, 147.0], [25.7, 147.0], [25.8, 147.0], [25.9, 147.0], [26.0, 147.0], [26.1, 147.0], [26.2, 147.0], [26.3, 147.0], [26.4, 148.0], [26.5, 148.0], [26.6, 148.0], [26.7, 148.0], [26.8, 148.0], [26.9, 148.0], [27.0, 148.0], [27.1, 148.0], [27.2, 148.0], [27.3, 148.0], [27.4, 148.0], [27.5, 149.0], [27.6, 149.0], [27.7, 149.0], [27.8, 149.0], [27.9, 149.0], [28.0, 149.0], [28.1, 149.0], [28.2, 149.0], [28.3, 149.0], [28.4, 149.0], [28.5, 149.0], [28.6, 149.0], [28.7, 149.0], [28.8, 150.0], [28.9, 150.0], [29.0, 150.0], [29.1, 150.0], [29.2, 150.0], [29.3, 150.0], [29.4, 150.0], [29.5, 150.0], [29.6, 150.0], [29.7, 150.0], [29.8, 150.0], [29.9, 150.0], [30.0, 150.0], [30.1, 150.0], [30.2, 150.0], [30.3, 150.0], [30.4, 150.0], [30.5, 150.0], [30.6, 150.0], [30.7, 150.0], [30.8, 151.0], [30.9, 151.0], [31.0, 151.0], [31.1, 151.0], [31.2, 151.0], [31.3, 151.0], [31.4, 151.0], [31.5, 151.0], [31.6, 151.0], [31.7, 151.0], [31.8, 151.0], [31.9, 152.0], [32.0, 152.0], [32.1, 152.0], [32.2, 152.0], [32.3, 152.0], [32.4, 152.0], [32.5, 152.0], [32.6, 152.0], [32.7, 152.0], [32.8, 152.0], [32.9, 152.0], [33.0, 153.0], [33.1, 153.0], [33.2, 153.0], [33.3, 153.0], [33.4, 153.0], [33.5, 153.0], [33.6, 153.0], [33.7, 153.0], [33.8, 153.0], [33.9, 153.0], [34.0, 153.0], [34.1, 153.0], [34.2, 154.0], [34.3, 154.0], [34.4, 154.0], [34.5, 154.0], [34.6, 154.0], [34.7, 154.0], [34.8, 154.0], [34.9, 154.0], [35.0, 154.0], [35.1, 154.0], [35.2, 154.0], [35.3, 154.0], [35.4, 154.0], [35.5, 154.0], [35.6, 154.0], [35.7, 154.0], [35.8, 154.0], [35.9, 154.0], [36.0, 155.0], [36.1, 155.0], [36.2, 155.0], [36.3, 155.0], [36.4, 155.0], [36.5, 155.0], [36.6, 155.0], [36.7, 155.0], [36.8, 155.0], [36.9, 155.0], [37.0, 156.0], [37.1, 156.0], [37.2, 156.0], [37.3, 156.0], [37.4, 156.0], [37.5, 156.0], [37.6, 156.0], [37.7, 156.0], [37.8, 156.0], [37.9, 156.0], [38.0, 156.0], [38.1, 156.0], [38.2, 156.0], [38.3, 156.0], [38.4, 156.0], [38.5, 156.0], [38.6, 157.0], [38.7, 157.0], [38.8, 157.0], [38.9, 157.0], [39.0, 157.0], [39.1, 157.0], [39.2, 157.0], [39.3, 157.0], [39.4, 157.0], [39.5, 157.0], [39.6, 157.0], [39.7, 157.0], [39.8, 157.0], [39.9, 157.0], [40.0, 157.0], [40.1, 158.0], [40.2, 158.0], [40.3, 158.0], [40.4, 158.0], [40.5, 158.0], [40.6, 158.0], [40.7, 158.0], [40.8, 158.0], [40.9, 158.0], [41.0, 158.0], [41.1, 158.0], [41.2, 159.0], [41.3, 159.0], [41.4, 159.0], [41.5, 159.0], [41.6, 159.0], [41.7, 159.0], [41.8, 159.0], [41.9, 159.0], [42.0, 159.0], [42.1, 159.0], [42.2, 159.0], [42.3, 159.0], [42.4, 159.0], [42.5, 159.0], [42.6, 159.0], [42.7, 160.0], [42.8, 160.0], [42.9, 160.0], [43.0, 160.0], [43.1, 160.0], [43.2, 160.0], [43.3, 160.0], [43.4, 160.0], [43.5, 160.0], [43.6, 160.0], [43.7, 160.0], [43.8, 161.0], [43.9, 161.0], [44.0, 161.0], [44.1, 161.0], [44.2, 161.0], [44.3, 161.0], [44.4, 162.0], [44.5, 162.0], [44.6, 162.0], [44.7, 162.0], [44.8, 162.0], [44.9, 162.0], [45.0, 162.0], [45.1, 162.0], [45.2, 162.0], [45.3, 162.0], [45.4, 163.0], [45.5, 163.0], [45.6, 163.0], [45.7, 163.0], [45.8, 163.0], [45.9, 163.0], [46.0, 163.0], [46.1, 163.0], [46.2, 163.0], [46.3, 163.0], [46.4, 163.0], [46.5, 163.0], [46.6, 164.0], [46.7, 164.0], [46.8, 164.0], [46.9, 164.0], [47.0, 164.0], [47.1, 164.0], [47.2, 164.0], [47.3, 164.0], [47.4, 164.0], [47.5, 165.0], [47.6, 165.0], [47.7, 165.0], [47.8, 165.0], [47.9, 165.0], [48.0, 165.0], [48.1, 165.0], [48.2, 165.0], [48.3, 165.0], [48.4, 165.0], [48.5, 165.0], [48.6, 166.0], [48.7, 166.0], [48.8, 166.0], [48.9, 166.0], [49.0, 166.0], [49.1, 166.0], [49.2, 166.0], [49.3, 166.0], [49.4, 167.0], [49.5, 167.0], [49.6, 167.0], [49.7, 167.0], [49.8, 167.0], [49.9, 167.0], [50.0, 167.0], [50.1, 167.0], [50.2, 168.0], [50.3, 168.0], [50.4, 168.0], [50.5, 168.0], [50.6, 168.0], [50.7, 168.0], [50.8, 168.0], [50.9, 168.0], [51.0, 169.0], [51.1, 169.0], [51.2, 169.0], [51.3, 169.0], [51.4, 169.0], [51.5, 169.0], [51.6, 169.0], [51.7, 170.0], [51.8, 170.0], [51.9, 170.0], [52.0, 170.0], [52.1, 170.0], [52.2, 170.0], [52.3, 170.0], [52.4, 170.0], [52.5, 170.0], [52.6, 171.0], [52.7, 171.0], [52.8, 171.0], [52.9, 171.0], [53.0, 171.0], [53.1, 171.0], [53.2, 171.0], [53.3, 171.0], [53.4, 171.0], [53.5, 171.0], [53.6, 172.0], [53.7, 172.0], [53.8, 172.0], [53.9, 172.0], [54.0, 172.0], [54.1, 172.0], [54.2, 172.0], [54.3, 172.0], [54.4, 172.0], [54.5, 173.0], [54.6, 173.0], [54.7, 173.0], [54.8, 173.0], [54.9, 173.0], [55.0, 173.0], [55.1, 173.0], [55.2, 173.0], [55.3, 174.0], [55.4, 174.0], [55.5, 174.0], [55.6, 174.0], [55.7, 174.0], [55.8, 174.0], [55.9, 175.0], [56.0, 175.0], [56.1, 175.0], [56.2, 175.0], [56.3, 176.0], [56.4, 176.0], [56.5, 176.0], [56.6, 176.0], [56.7, 176.0], [56.8, 177.0], [56.9, 177.0], [57.0, 177.0], [57.1, 177.0], [57.2, 177.0], [57.3, 177.0], [57.4, 177.0], [57.5, 178.0], [57.6, 178.0], [57.7, 178.0], [57.8, 178.0], [57.9, 178.0], [58.0, 178.0], [58.1, 178.0], [58.2, 178.0], [58.3, 178.0], [58.4, 179.0], [58.5, 179.0], [58.6, 179.0], [58.7, 179.0], [58.8, 179.0], [58.9, 179.0], [59.0, 179.0], [59.1, 180.0], [59.2, 180.0], [59.3, 180.0], [59.4, 180.0], [59.5, 180.0], [59.6, 181.0], [59.7, 181.0], [59.8, 181.0], [59.9, 181.0], [60.0, 181.0], [60.1, 182.0], [60.2, 182.0], [60.3, 182.0], [60.4, 182.0], [60.5, 182.0], [60.6, 183.0], [60.7, 183.0], [60.8, 183.0], [60.9, 183.0], [61.0, 183.0], [61.1, 183.0], [61.2, 184.0], [61.3, 184.0], [61.4, 184.0], [61.5, 184.0], [61.6, 184.0], [61.7, 184.0], [61.8, 184.0], [61.9, 185.0], [62.0, 185.0], [62.1, 185.0], [62.2, 185.0], [62.3, 186.0], [62.4, 186.0], [62.5, 186.0], [62.6, 186.0], [62.7, 186.0], [62.8, 187.0], [62.9, 187.0], [63.0, 187.0], [63.1, 187.0], [63.2, 187.0], [63.3, 188.0], [63.4, 188.0], [63.5, 188.0], [63.6, 188.0], [63.7, 188.0], [63.8, 188.0], [63.9, 189.0], [64.0, 189.0], [64.1, 189.0], [64.2, 189.0], [64.3, 190.0], [64.4, 190.0], [64.5, 190.0], [64.6, 190.0], [64.7, 191.0], [64.8, 191.0], [64.9, 191.0], [65.0, 192.0], [65.1, 192.0], [65.2, 192.0], [65.3, 192.0], [65.4, 193.0], [65.5, 193.0], [65.6, 193.0], [65.7, 193.0], [65.8, 193.0], [65.9, 194.0], [66.0, 194.0], [66.1, 194.0], [66.2, 195.0], [66.3, 195.0], [66.4, 195.0], [66.5, 195.0], [66.6, 195.0], [66.7, 196.0], [66.8, 196.0], [66.9, 196.0], [67.0, 197.0], [67.1, 197.0], [67.2, 197.0], [67.3, 197.0], [67.4, 198.0], [67.5, 198.0], [67.6, 199.0], [67.7, 199.0], [67.8, 199.0], [67.9, 199.0], [68.0, 200.0], [68.1, 200.0], [68.2, 200.0], [68.3, 200.0], [68.4, 200.0], [68.5, 201.0], [68.6, 201.0], [68.7, 201.0], [68.8, 201.0], [68.9, 202.0], [69.0, 202.0], [69.1, 202.0], [69.2, 202.0], [69.3, 202.0], [69.4, 202.0], [69.5, 203.0], [69.6, 203.0], [69.7, 203.0], [69.8, 204.0], [69.9, 204.0], [70.0, 204.0], [70.1, 205.0], [70.2, 206.0], [70.3, 206.0], [70.4, 206.0], [70.5, 206.0], [70.6, 206.0], [70.7, 206.0], [70.8, 207.0], [70.9, 207.0], [71.0, 207.0], [71.1, 208.0], [71.2, 209.0], [71.3, 210.0], [71.4, 210.0], [71.5, 211.0], [71.6, 211.0], [71.7, 211.0], [71.8, 211.0], [71.9, 212.0], [72.0, 212.0], [72.1, 212.0], [72.2, 213.0], [72.3, 213.0], [72.4, 213.0], [72.5, 213.0], [72.6, 214.0], [72.7, 214.0], [72.8, 214.0], [72.9, 214.0], [73.0, 214.0], [73.1, 215.0], [73.2, 216.0], [73.3, 216.0], [73.4, 217.0], [73.5, 218.0], [73.6, 218.0], [73.7, 218.0], [73.8, 218.0], [73.9, 218.0], [74.0, 218.0], [74.1, 219.0], [74.2, 219.0], [74.3, 220.0], [74.4, 220.0], [74.5, 221.0], [74.6, 222.0], [74.7, 223.0], [74.8, 223.0], [74.9, 224.0], [75.0, 224.0], [75.1, 224.0], [75.2, 224.0], [75.3, 225.0], [75.4, 225.0], [75.5, 225.0], [75.6, 226.0], [75.7, 226.0], [75.8, 226.0], [75.9, 227.0], [76.0, 227.0], [76.1, 228.0], [76.2, 228.0], [76.3, 229.0], [76.4, 230.0], [76.5, 230.0], [76.6, 230.0], [76.7, 231.0], [76.8, 232.0], [76.9, 232.0], [77.0, 233.0], [77.1, 233.0], [77.2, 234.0], [77.3, 235.0], [77.4, 235.0], [77.5, 236.0], [77.6, 237.0], [77.7, 237.0], [77.8, 238.0], [77.9, 239.0], [78.0, 239.0], [78.1, 240.0], [78.2, 241.0], [78.3, 242.0], [78.4, 242.0], [78.5, 243.0], [78.6, 244.0], [78.7, 244.0], [78.8, 245.0], [78.9, 245.0], [79.0, 246.0], [79.1, 247.0], [79.2, 248.0], [79.3, 250.0], [79.4, 252.0], [79.5, 252.0], [79.6, 253.0], [79.7, 254.0], [79.8, 254.0], [79.9, 255.0], [80.0, 256.0], [80.1, 257.0], [80.2, 258.0], [80.3, 259.0], [80.4, 260.0], [80.5, 260.0], [80.6, 262.0], [80.7, 263.0], [80.8, 264.0], [80.9, 265.0], [81.0, 266.0], [81.1, 267.0], [81.2, 268.0], [81.3, 270.0], [81.4, 271.0], [81.5, 273.0], [81.6, 274.0], [81.7, 275.0], [81.8, 276.0], [81.9, 277.0], [82.0, 279.0], [82.1, 279.0], [82.2, 281.0], [82.3, 283.0], [82.4, 285.0], [82.5, 286.0], [82.6, 287.0], [82.7, 289.0], [82.8, 291.0], [82.9, 291.0], [83.0, 292.0], [83.1, 293.0], [83.2, 295.0], [83.3, 296.0], [83.4, 299.0], [83.5, 300.0], [83.6, 301.0], [83.7, 302.0], [83.8, 306.0], [83.9, 306.0], [84.0, 308.0], [84.1, 308.0], [84.2, 309.0], [84.3, 309.0], [84.4, 311.0], [84.5, 313.0], [84.6, 316.0], [84.7, 316.0], [84.8, 318.0], [84.9, 320.0], [85.0, 324.0], [85.1, 326.0], [85.2, 329.0], [85.3, 330.0], [85.4, 333.0], [85.5, 334.0], [85.6, 336.0], [85.7, 338.0], [85.8, 339.0], [85.9, 341.0], [86.0, 342.0], [86.1, 343.0], [86.2, 347.0], [86.3, 347.0], [86.4, 348.0], [86.5, 349.0], [86.6, 351.0], [86.7, 352.0], [86.8, 353.0], [86.9, 354.0], [87.0, 356.0], [87.1, 357.0], [87.2, 358.0], [87.3, 359.0], [87.4, 361.0], [87.5, 361.0], [87.6, 362.0], [87.7, 363.0], [87.8, 365.0], [87.9, 365.0], [88.0, 368.0], [88.1, 369.0], [88.2, 370.0], [88.3, 371.0], [88.4, 373.0], [88.5, 376.0], [88.6, 378.0], [88.7, 379.0], [88.8, 380.0], [88.9, 380.0], [89.0, 382.0], [89.1, 383.0], [89.2, 386.0], [89.3, 387.0], [89.4, 389.0], [89.5, 390.0], [89.6, 393.0], [89.7, 395.0], [89.8, 398.0], [89.9, 401.0], [90.0, 402.0], [90.1, 402.0], [90.2, 403.0], [90.3, 405.0], [90.4, 407.0], [90.5, 408.0], [90.6, 411.0], [90.7, 412.0], [90.8, 412.0], [90.9, 415.0], [91.0, 417.0], [91.1, 418.0], [91.2, 422.0], [91.3, 427.0], [91.4, 431.0], [91.5, 437.0], [91.6, 439.0], [91.7, 441.0], [91.8, 445.0], [91.9, 450.0], [92.0, 455.0], [92.1, 458.0], [92.2, 466.0], [92.3, 471.0], [92.4, 484.0], [92.5, 486.0], [92.6, 493.0], [92.7, 494.0], [92.8, 502.0], [92.9, 514.0], [93.0, 529.0], [93.1, 531.0], [93.2, 534.0], [93.3, 542.0], [93.4, 548.0], [93.5, 555.0], [93.6, 562.0], [93.7, 566.0], [93.8, 567.0], [93.9, 582.0], [94.0, 599.0], [94.1, 602.0], [94.2, 614.0], [94.3, 620.0], [94.4, 628.0], [94.5, 633.0], [94.6, 646.0], [94.7, 649.0], [94.8, 655.0], [94.9, 659.0], [95.0, 671.0], [95.1, 677.0], [95.2, 683.0], [95.3, 692.0], [95.4, 703.0], [95.5, 708.0], [95.6, 714.0], [95.7, 717.0], [95.8, 728.0], [95.9, 745.0], [96.0, 772.0], [96.1, 788.0], [96.2, 816.0], [96.3, 842.0], [96.4, 887.0], [96.5, 924.0], [96.6, 941.0], [96.7, 948.0], [96.8, 951.0], [96.9, 974.0], [97.0, 993.0], [97.1, 1011.0], [97.2, 1041.0], [97.3, 1067.0], [97.4, 1093.0], [97.5, 1095.0], [97.6, 1109.0], [97.7, 1138.0], [97.8, 1227.0], [97.9, 1248.0], [98.0, 1347.0], [98.1, 1521.0], [98.2, 1588.0], [98.3, 1615.0], [98.4, 1659.0], [98.5, 1666.0], [98.6, 1731.0], [98.7, 1767.0], [98.8, 1840.0], [98.9, 1867.0], [99.0, 1926.0], [99.1, 2078.0], [99.2, 2426.0], [99.3, 2465.0], [99.4, 2468.0], [99.5, 2530.0], [99.6, 2609.0], [99.7, 2658.0], [99.8, 2724.0], [99.9, 3520.0], [100.0, 3705.0]], "isOverall": false, "label": "GET - List Orders Direct Azure", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 100.0, "maxY": 2377.0, "series": [{"data": [[600.0, 48.0], [700.0, 26.0], [800.0, 10.0], [900.0, 21.0], [1000.0, 17.0], [1100.0, 8.0], [1200.0, 8.0], [1300.0, 3.0], [1400.0, 1.0], [1500.0, 6.0], [100.0, 2377.0], [1600.0, 9.0], [1700.0, 7.0], [1800.0, 10.0], [1900.0, 1.0], [2000.0, 3.0], [2300.0, 3.0], [2400.0, 9.0], [2500.0, 4.0], [2600.0, 6.0], [2700.0, 3.0], [2800.0, 1.0], [2900.0, 1.0], [200.0, 541.0], [3500.0, 1.0], [3700.0, 3.0], [300.0, 225.0], [400.0, 101.0], [500.0, 45.0]], "isOverall": false, "label": "GET - List Orders Direct Azure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 3700.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 67.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 3245.0, "series": [{"data": [[0.0, 3245.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 186.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [[2.0, 67.0]], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 2.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 23.91428571428571, "minX": 1.792311745E12, "maxY": 30.0, "series": [{"data": [[1.79231179E12, 30.0], [1.792311875E12, 30.0], [1.79231183E12, 30.0], [1.792311745E12, 30.0], [1.792311795E12, 30.0], [1.79231184E12, 30.0], [1.79231175E12, 30.0], [1.792311835E12, 30.0], [1.79231188E12, 30.0], [1.79231176E12, 30.0], [1.792311845E12, 30.0], [1.792311755E12, 30.0], [1.7923118E12, 30.0], [1.792311885E12, 30.0], [1.79231185E12, 30.0], [1.792311765E12, 30.0], [1.79231189E12, 23.91428571428571], [1.792311805E12, 30.0], [1.79231177E12, 30.0], [1.792311855E12, 30.0], [1.79231181E12, 30.0], [1.79231186E12, 30.0], [1.792311775E12, 30.0], [1.792311815E12, 30.0], [1.79231178E12, 30.0], [1.792311865E12, 30.0], [1.79231182E12, 30.0], [1.79231187E12, 30.0], [1.792311785E12, 30.0], [1.792311825E12, 30.0]], "isOverall": false, "label": "Thread Group", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.79231189E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 127.0, "minX": 1.0, "maxY": 300.0, "series": [{"data": [[2.0, 141.0], [3.0, 136.0], [4.0, 300.0], [5.0, 127.0], [6.0, 138.0], [7.0, 140.0], [8.0, 149.0], [9.0, 160.0], [10.0, 139.0], [11.0, 128.0], [12.0, 143.0], [13.0, 216.0], [14.0, 154.0], [15.0, 196.0], [16.0, 232.0], [1.0, 154.0], [17.0, 230.0], [21.0, 233.5], [22.0, 241.0], [23.0, 219.0], [24.0, 185.0], [25.0, 203.0], [28.0, 207.33333333333334], [29.0, 191.0], [30.0, 260.7996540789868]], "isOverall": false, "label": "GET - List Orders Direct Azure", "isController": false}, {"data": [[29.878216123499147, 260.2035448827916]], "isOverall": false, "label": "GET - List Orders Direct Azure-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 30.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 20671.2, "minX": 1.792311745E12, "maxY": 214269.6, "series": [{"data": [[1.79231179E12, 180514.8], [1.792311875E12, 184919.0], [1.79231183E12, 174644.4], [1.792311745E12, 148229.0], [1.792311795E12, 195190.8], [1.79231184E12, 179047.2], [1.79231175E12, 186386.6], [1.792311835E12, 159968.4], [1.79231188E12, 198131.6], [1.79231176E12, 173176.8], [1.792311845E12, 189320.4], [1.792311755E12, 176112.0], [1.7923118E12, 152630.4], [1.792311885E12, 176112.0], [1.79231185E12, 189320.4], [1.792311765E12, 184919.0], [1.79231189E12, 102733.4], [1.792311805E12, 136486.8], [1.79231177E12, 196658.4], [1.792311855E12, 180516.2], [1.79231181E12, 155565.6], [1.79231186E12, 186385.2], [1.792311775E12, 171709.2], [1.792311815E12, 96863.0], [1.79231178E12, 179047.2], [1.792311865E12, 174644.4], [1.79231182E12, 129148.8], [1.79231187E12, 183450.0], [1.792311785E12, 177581.0], [1.792311825E12, 214269.6]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.79231179E12, 38523.6], [1.792311875E12, 39463.2], [1.79231183E12, 37270.8], [1.792311745E12, 31633.2], [1.792311795E12, 41655.6], [1.79231184E12, 38210.4], [1.79231175E12, 39776.4], [1.792311835E12, 34138.8], [1.79231188E12, 42282.0], [1.79231176E12, 36957.6], [1.792311845E12, 40402.8], [1.792311755E12, 37584.0], [1.7923118E12, 32572.8], [1.792311885E12, 37584.0], [1.79231185E12, 40402.8], [1.792311765E12, 39463.2], [1.79231189E12, 21924.0], [1.792311805E12, 29127.6], [1.79231177E12, 41968.8], [1.792311855E12, 38523.6], [1.79231181E12, 33199.2], [1.79231186E12, 39776.4], [1.792311775E12, 36644.4], [1.792311815E12, 20671.2], [1.79231178E12, 38210.4], [1.792311865E12, 37270.8], [1.79231182E12, 27561.6], [1.79231187E12, 39150.0], [1.792311785E12, 37897.2], [1.792311825E12, 45727.2]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.79231189E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 149.95275590551176, "minX": 1.792311745E12, "maxY": 1178.5795454545448, "series": [{"data": [[1.79231179E12, 212.11382113821134], [1.792311875E12, 214.52380952380946], [1.79231183E12, 197.8823529411765], [1.792311745E12, 403.00000000000006], [1.792311795E12, 151.3984962406015], [1.79231184E12, 181.1311475409835], [1.79231175E12, 207.81889763779535], [1.792311835E12, 305.45871559633025], [1.79231188E12, 152.2888888888888], [1.79231176E12, 256.94067796610165], [1.792311845E12, 228.9302325581395], [1.792311755E12, 220.85000000000005], [1.7923118E12, 281.8846153846154], [1.792311885E12, 231.82499999999993], [1.79231185E12, 152.29457364341079], [1.792311765E12, 210.1349206349207], [1.79231189E12, 191.6], [1.792311805E12, 687.8924731182794], [1.79231177E12, 169.71641791044783], [1.792311855E12, 185.9756097560976], [1.79231181E12, 468.81132075471686], [1.79231186E12, 149.95275590551176], [1.792311775E12, 229.5555555555556], [1.792311815E12, 327.1515151515152], [1.79231178E12, 238.98360655737704], [1.792311865E12, 238.10084033613467], [1.79231182E12, 1178.5795454545448], [1.79231187E12, 188.96000000000004], [1.792311785E12, 183.1239669421488], [1.792311825E12, 229.8287671232877]], "isOverall": false, "label": "GET - List Orders Direct Azure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.79231189E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 145.85925925925926, "minX": 1.792311745E12, "maxY": 917.7954545454543, "series": [{"data": [[1.79231179E12, 194.54471544715446], [1.792311875E12, 193.3174603174603], [1.79231183E12, 192.07563025210086], [1.792311745E12, 391.7623762376238], [1.792311795E12, 147.12030075187965], [1.79231184E12, 176.60655737704914], [1.79231175E12, 198.0866141732284], [1.792311835E12, 286.85321100917434], [1.79231188E12, 145.85925925925926], [1.79231176E12, 250.90677966101683], [1.792311845E12, 220.09302325581402], [1.792311755E12, 207.06666666666672], [1.7923118E12, 249.6923076923076], [1.792311885E12, 218.50833333333333], [1.79231185E12, 146.59689922480615], [1.792311765E12, 195.66666666666666], [1.79231189E12, 186.9142857142857], [1.792311805E12, 578.784946236559], [1.79231177E12, 165.23134328358208], [1.792311855E12, 182.05691056910572], [1.79231181E12, 406.5660377358491], [1.79231186E12, 146.9133858267717], [1.792311775E12, 223.3846153846154], [1.792311815E12, 267.590909090909], [1.79231178E12, 232.13114754098365], [1.792311865E12, 213.82352941176464], [1.79231182E12, 917.7954545454543], [1.79231187E12, 174.32000000000002], [1.792311785E12, 173.1322314049587], [1.792311825E12, 187.21232876712327]], "isOverall": false, "label": "GET - List Orders Direct Azure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.79231189E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 0.0, "minX": 1.792311745E12, "maxY": 72.73394495412842, "series": [{"data": [[1.79231179E12, 0.0], [1.792311875E12, 0.0], [1.79231183E12, 0.0], [1.792311745E12, 0.0], [1.792311795E12, 0.0], [1.79231184E12, 24.86885245901638], [1.79231175E12, 0.0], [1.792311835E12, 72.73394495412842], [1.79231188E12, 0.0], [1.79231176E12, 0.0], [1.792311845E12, 8.201550387596901], [1.792311755E12, 0.0], [1.7923118E12, 0.0], [1.792311885E12, 0.0], [1.79231185E12, 0.0], [1.792311765E12, 0.0], [1.79231189E12, 0.0], [1.792311805E12, 0.0], [1.79231177E12, 0.0], [1.792311855E12, 0.0], [1.79231181E12, 0.0], [1.79231186E12, 0.0], [1.792311775E12, 42.008547008547], [1.792311815E12, 0.0], [1.79231178E12, 44.401639344262286], [1.792311865E12, 0.0], [1.79231182E12, 0.0], [1.79231187E12, 0.0], [1.792311785E12, 0.0], [1.792311825E12, 0.0]], "isOverall": false, "label": "GET - List Orders Direct Azure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.79231189E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 113.0, "minX": 1.792311745E12, "maxY": 3705.0, "series": [{"data": [[1.79231179E12, 1094.0], [1.792311875E12, 1528.0], [1.79231183E12, 427.0], [1.792311745E12, 1258.0], [1.792311795E12, 244.0], [1.79231184E12, 807.0], [1.79231175E12, 1926.0], [1.792311835E12, 2666.0], [1.79231188E12, 275.0], [1.79231176E12, 717.0], [1.792311845E12, 1708.0], [1.792311755E12, 1011.0], [1.7923118E12, 1107.0], [1.792311885E12, 1440.0], [1.79231185E12, 334.0], [1.792311765E12, 677.0], [1.79231189E12, 300.0], [1.792311805E12, 2078.0], [1.79231177E12, 772.0], [1.792311855E12, 745.0], [1.79231181E12, 2491.0], [1.79231186E12, 200.0], [1.792311775E12, 987.0], [1.792311815E12, 1158.0], [1.79231178E12, 1119.0], [1.792311865E12, 940.0], [1.79231182E12, 3705.0], [1.79231187E12, 816.0], [1.792311785E12, 633.0], [1.792311825E12, 1076.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.79231179E12, 113.0], [1.792311875E12, 119.0], [1.79231183E12, 121.0], [1.792311745E12, 144.0], [1.792311795E12, 119.0], [1.79231184E12, 116.0], [1.79231175E12, 128.0], [1.792311835E12, 119.0], [1.79231188E12, 119.0], [1.79231176E12, 127.0], [1.792311845E12, 115.0], [1.792311755E12, 133.0], [1.7923118E12, 121.0], [1.792311885E12, 118.0], [1.79231185E12, 119.0], [1.792311765E12, 118.0], [1.79231189E12, 127.0], [1.792311805E12, 144.0], [1.79231177E12, 121.0], [1.792311855E12, 119.0], [1.79231181E12, 122.0], [1.79231186E12, 115.0], [1.792311775E12, 122.0], [1.792311815E12, 131.0], [1.79231178E12, 128.0], [1.792311865E12, 126.0], [1.79231182E12, 120.0], [1.79231187E12, 121.0], [1.792311785E12, 122.0], [1.792311825E12, 120.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.79231179E12, 272.00000000000017], [1.792311875E12, 227.99999999999997], [1.79231183E12, 377.0], [1.792311745E12, 773.8], [1.792311795E12, 174.40000000000003], [1.79231184E12, 356.4], [1.79231175E12, 255.0], [1.792311835E12, 728.0], [1.79231188E12, 176.20000000000002], [1.79231176E12, 492.1], [1.792311845E12, 329.0], [1.792311755E12, 277.9], [1.7923118E12, 733.5], [1.792311885E12, 373.5000000000001], [1.79231185E12, 178.0], [1.792311765E12, 367.49999999999994], [1.79231189E12, 240.9], [1.792311805E12, 1838.6], [1.79231177E12, 218.0], [1.792311855E12, 275.4000000000001], [1.79231181E12, 1627.8999999999999], [1.79231186E12, 172.0], [1.792311775E12, 420.6], [1.792311815E12, 681.8000000000001], [1.79231178E12, 410.1], [1.792311865E12, 429.0], [1.79231182E12, 2719.5], [1.79231187E12, 243.8], [1.792311785E12, 294.0], [1.792311825E12, 362.80000000000007]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.79231179E12, 1077.6800000000003], [1.792311875E12, 1486.6900000000005], [1.79231183E12, 426.0], [1.792311745E12, 1258.0], [1.792311795E12, 238.55999999999995], [1.79231184E12, 726.9599999999987], [1.79231175E12, 1475.1999999999982], [1.792311835E12, 2554.0000000000064], [1.79231188E12, 264.5599999999996], [1.79231176E12, 684.5100000000004], [1.792311845E12, 1707.1], [1.792311755E12, 990.6299999999992], [1.7923118E12, 1106.4], [1.792311885E12, 1337.099999999996], [1.79231185E12, 297.0999999999986], [1.792311765E12, 668.6300000000001], [1.79231189E12, 300.0], [1.792311805E12, 2078.0], [1.79231177E12, 596.6500000000028], [1.792311855E12, 716.6800000000006], [1.79231181E12, 2486.4499999999994], [1.79231186E12, 199.72], [1.792311775E12, 980.3399999999997], [1.792311815E12, 1158.0], [1.79231178E12, 1107.0399999999997], [1.792311865E12, 896.5999999999995], [1.79231182E12, 3705.0], [1.79231187E12, 786.6199999999994], [1.792311785E12, 626.1800000000001], [1.792311825E12, 1012.5500000000002]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.79231179E12, 163.0], [1.792311875E12, 161.5], [1.79231183E12, 159.0], [1.792311745E12, 363.0], [1.792311795E12, 148.0], [1.79231184E12, 148.5], [1.79231175E12, 187.0], [1.792311835E12, 158.0], [1.79231188E12, 147.0], [1.79231176E12, 195.0], [1.792311845E12, 159.0], [1.792311755E12, 181.0], [1.7923118E12, 170.0], [1.792311885E12, 183.0], [1.79231185E12, 149.0], [1.792311765E12, 164.5], [1.79231189E12, 191.0], [1.792311805E12, 362.0], [1.79231177E12, 157.5], [1.792311855E12, 161.0], [1.79231181E12, 214.0], [1.79231186E12, 148.0], [1.792311775E12, 172.0], [1.792311815E12, 230.5], [1.79231178E12, 170.5], [1.792311865E12, 182.0], [1.79231182E12, 471.5], [1.79231187E12, 158.0], [1.792311785E12, 154.0], [1.792311825E12, 180.5]], "isOverall": false, "label": "Median", "isController": false}, {"data": [[1.79231179E12, 545.1999999999998], [1.792311875E12, 536.1999999999999], [1.79231183E12, 411.0], [1.792311745E12, 1239.0999999999997], [1.792311795E12, 193.09999999999997], [1.79231184E12, 379.79999999999995], [1.79231175E12, 272.2], [1.792311835E12, 980.5], [1.79231188E12, 202.59999999999997], [1.79231176E12, 531.0], [1.792311845E12, 516.0], [1.792311755E12, 447.54999999999944], [1.7923118E12, 988.5], [1.792311885E12, 600.1999999999996], [1.79231185E12, 189.5], [1.792311765E12, 431.89999999999975], [1.79231189E12, 248.40000000000003], [1.792311805E12, 1868.5], [1.79231177E12, 253.75], [1.792311855E12, 314.79999999999995], [1.79231181E12, 1660.95], [1.79231186E12, 179.6], [1.792311775E12, 554.1999999999996], [1.792311815E12, 795.0999999999998], [1.79231178E12, 738.7999999999998], [1.792311865E12, 628.0], [1.79231182E12, 3245.9499999999985], [1.79231187E12, 364.1999999999998], [1.792311785E12, 326.0], [1.792311825E12, 571.2000000000013]], "isOverall": false, "label": "95th percentile", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.79231189E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 148.0, "minX": 1.0, "maxY": 2791.0, "series": [{"data": [[2.0, 338.0], [9.0, 345.0], [11.0, 214.0], [13.0, 244.0], [14.0, 148.0], [16.0, 285.5], [4.0, 2791.0], [1.0, 154.0], [17.0, 222.0], [18.0, 160.5], [19.0, 176.5], [20.0, 191.0], [21.0, 169.0], [22.0, 165.5], [23.0, 162.0], [24.0, 164.0], [25.0, 166.0], [26.0, 159.5], [27.0, 154.0], [28.0, 191.0], [29.0, 165.5], [30.0, 169.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 30.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 142.0, "minX": 1.0, "maxY": 2532.5, "series": [{"data": [[2.0, 290.5], [9.0, 345.0], [11.0, 214.0], [13.0, 244.0], [14.0, 143.5], [16.0, 227.5], [4.0, 2532.5], [1.0, 142.0], [17.0, 209.0], [18.0, 155.0], [19.0, 172.5], [20.0, 182.0], [21.0, 164.0], [22.0, 163.0], [23.0, 159.0], [24.0, 160.5], [25.0, 163.0], [26.0, 156.0], [27.0, 151.0], [28.0, 185.5], [29.0, 159.0], [30.0, 162.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 30.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 13.6, "minX": 1.792311745E12, "maxY": 27.4, "series": [{"data": [[1.79231179E12, 23.2], [1.792311875E12, 25.6], [1.79231183E12, 24.6], [1.792311745E12, 22.4], [1.792311795E12, 27.4], [1.79231184E12, 25.0], [1.79231175E12, 24.4], [1.792311835E12, 22.6], [1.79231188E12, 25.2], [1.79231176E12, 23.0], [1.792311845E12, 24.4], [1.792311755E12, 25.4], [1.7923118E12, 23.0], [1.792311885E12, 23.8], [1.79231185E12, 25.8], [1.792311765E12, 25.2], [1.79231189E12, 13.6], [1.792311805E12, 17.6], [1.79231177E12, 25.2], [1.792311855E12, 23.8], [1.79231181E12, 20.0], [1.79231186E12, 27.0], [1.792311775E12, 24.2], [1.792311815E12, 18.2], [1.79231178E12, 24.0], [1.792311865E12, 24.2], [1.79231182E12, 17.2], [1.79231187E12, 25.0], [1.792311785E12, 25.0], [1.792311825E12, 23.6]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.79231189E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 13.2, "minX": 1.792311745E12, "maxY": 29.2, "series": [{"data": [[1.79231179E12, 24.6], [1.792311875E12, 25.2], [1.79231183E12, 23.8], [1.792311745E12, 20.2], [1.792311795E12, 26.6], [1.79231184E12, 24.4], [1.79231175E12, 25.4], [1.792311835E12, 21.8], [1.79231188E12, 27.0], [1.79231176E12, 23.6], [1.792311845E12, 25.8], [1.792311755E12, 24.0], [1.7923118E12, 20.8], [1.792311885E12, 24.0], [1.79231185E12, 25.8], [1.792311765E12, 25.2], [1.79231189E12, 14.0], [1.792311805E12, 18.6], [1.79231177E12, 26.8], [1.792311855E12, 24.6], [1.79231181E12, 21.2], [1.79231186E12, 25.4], [1.792311775E12, 23.4], [1.792311815E12, 13.2], [1.79231178E12, 24.4], [1.792311865E12, 23.8], [1.79231182E12, 17.6], [1.79231187E12, 25.0], [1.792311785E12, 24.2], [1.792311825E12, 29.2]], "isOverall": false, "label": "200", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.79231189E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 13.2, "minX": 1.792311745E12, "maxY": 29.2, "series": [{"data": [[1.79231179E12, 24.6], [1.792311875E12, 25.2], [1.79231183E12, 23.8], [1.792311745E12, 20.2], [1.792311795E12, 26.6], [1.79231184E12, 24.4], [1.79231175E12, 25.4], [1.792311835E12, 21.8], [1.79231188E12, 27.0], [1.79231176E12, 23.6], [1.792311845E12, 25.8], [1.792311755E12, 24.0], [1.7923118E12, 20.8], [1.792311885E12, 24.0], [1.79231185E12, 25.8], [1.792311765E12, 25.2], [1.79231189E12, 14.0], [1.792311805E12, 18.6], [1.79231177E12, 26.8], [1.792311855E12, 24.6], [1.79231181E12, 21.2], [1.79231186E12, 25.4], [1.792311775E12, 23.4], [1.792311815E12, 13.2], [1.79231178E12, 24.4], [1.792311865E12, 23.8], [1.79231182E12, 17.6], [1.79231187E12, 25.0], [1.792311785E12, 24.2], [1.792311825E12, 29.2]], "isOverall": false, "label": "GET - List Orders Direct Azure-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.79231189E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 13.2, "minX": 1.792311745E12, "maxY": 29.2, "series": [{"data": [[1.79231179E12, 24.6], [1.792311875E12, 25.2], [1.79231183E12, 23.8], [1.792311745E12, 20.2], [1.792311795E12, 26.6], [1.79231184E12, 24.4], [1.79231175E12, 25.4], [1.792311835E12, 21.8], [1.79231188E12, 27.0], [1.79231176E12, 23.6], [1.792311845E12, 25.8], [1.792311755E12, 24.0], [1.7923118E12, 20.8], [1.792311885E12, 24.0], [1.79231185E12, 25.8], [1.792311765E12, 25.2], [1.79231189E12, 14.0], [1.792311805E12, 18.6], [1.79231177E12, 26.8], [1.792311855E12, 24.6], [1.79231181E12, 21.2], [1.79231186E12, 25.4], [1.792311775E12, 23.4], [1.792311815E12, 13.2], [1.79231178E12, 24.4], [1.792311865E12, 23.8], [1.79231182E12, 17.6], [1.79231187E12, 25.0], [1.792311785E12, 24.2], [1.792311825E12, 29.2]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.79231189E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

