/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 460.0, "minX": 0.0, "maxY": 24492.0, "series": [{"data": [[0.0, 460.0], [0.1, 460.0], [0.2, 460.0], [0.3, 463.0], [0.4, 463.0], [0.5, 463.0], [0.6, 463.0], [0.7, 463.0], [0.8, 464.0], [0.9, 464.0], [1.0, 464.0], [1.1, 465.0], [1.2, 465.0], [1.3, 467.0], [1.4, 467.0], [1.5, 467.0], [1.6, 468.0], [1.7, 468.0], [1.8, 468.0], [1.9, 468.0], [2.0, 468.0], [2.1, 469.0], [2.2, 469.0], [2.3, 469.0], [2.4, 469.0], [2.5, 469.0], [2.6, 469.0], [2.7, 469.0], [2.8, 469.0], [2.9, 470.0], [3.0, 470.0], [3.1, 471.0], [3.2, 471.0], [3.3, 471.0], [3.4, 471.0], [3.5, 471.0], [3.6, 472.0], [3.7, 472.0], [3.8, 472.0], [3.9, 473.0], [4.0, 473.0], [4.1, 473.0], [4.2, 473.0], [4.3, 473.0], [4.4, 473.0], [4.5, 473.0], [4.6, 473.0], [4.7, 474.0], [4.8, 474.0], [4.9, 474.0], [5.0, 474.0], [5.1, 474.0], [5.2, 474.0], [5.3, 474.0], [5.4, 475.0], [5.5, 475.0], [5.6, 475.0], [5.7, 475.0], [5.8, 475.0], [5.9, 475.0], [6.0, 475.0], [6.1, 475.0], [6.2, 476.0], [6.3, 476.0], [6.4, 476.0], [6.5, 476.0], [6.6, 476.0], [6.7, 476.0], [6.8, 476.0], [6.9, 476.0], [7.0, 476.0], [7.1, 476.0], [7.2, 476.0], [7.3, 476.0], [7.4, 476.0], [7.5, 476.0], [7.6, 476.0], [7.7, 476.0], [7.8, 476.0], [7.9, 476.0], [8.0, 477.0], [8.1, 477.0], [8.2, 477.0], [8.3, 477.0], [8.4, 477.0], [8.5, 477.0], [8.6, 477.0], [8.7, 477.0], [8.8, 477.0], [8.9, 477.0], [9.0, 478.0], [9.1, 478.0], [9.2, 478.0], [9.3, 478.0], [9.4, 478.0], [9.5, 479.0], [9.6, 479.0], [9.7, 479.0], [9.8, 479.0], [9.9, 479.0], [10.0, 479.0], [10.1, 479.0], [10.2, 479.0], [10.3, 479.0], [10.4, 479.0], [10.5, 479.0], [10.6, 480.0], [10.7, 480.0], [10.8, 480.0], [10.9, 480.0], [11.0, 480.0], [11.1, 480.0], [11.2, 480.0], [11.3, 480.0], [11.4, 480.0], [11.5, 480.0], [11.6, 480.0], [11.7, 480.0], [11.8, 480.0], [11.9, 480.0], [12.0, 480.0], [12.1, 480.0], [12.2, 480.0], [12.3, 480.0], [12.4, 481.0], [12.5, 481.0], [12.6, 481.0], [12.7, 481.0], [12.8, 481.0], [12.9, 481.0], [13.0, 481.0], [13.1, 482.0], [13.2, 482.0], [13.3, 482.0], [13.4, 482.0], [13.5, 482.0], [13.6, 482.0], [13.7, 482.0], [13.8, 482.0], [13.9, 482.0], [14.0, 482.0], [14.1, 482.0], [14.2, 482.0], [14.3, 482.0], [14.4, 483.0], [14.5, 483.0], [14.6, 483.0], [14.7, 483.0], [14.8, 483.0], [14.9, 483.0], [15.0, 483.0], [15.1, 483.0], [15.2, 483.0], [15.3, 483.0], [15.4, 483.0], [15.5, 483.0], [15.6, 483.0], [15.7, 483.0], [15.8, 483.0], [15.9, 484.0], [16.0, 484.0], [16.1, 484.0], [16.2, 484.0], [16.3, 484.0], [16.4, 484.0], [16.5, 484.0], [16.6, 484.0], [16.7, 484.0], [16.8, 484.0], [16.9, 484.0], [17.0, 484.0], [17.1, 484.0], [17.2, 485.0], [17.3, 485.0], [17.4, 485.0], [17.5, 485.0], [17.6, 485.0], [17.7, 485.0], [17.8, 485.0], [17.9, 485.0], [18.0, 485.0], [18.1, 485.0], [18.2, 485.0], [18.3, 485.0], [18.4, 485.0], [18.5, 486.0], [18.6, 486.0], [18.7, 486.0], [18.8, 486.0], [18.9, 486.0], [19.0, 486.0], [19.1, 486.0], [19.2, 486.0], [19.3, 486.0], [19.4, 486.0], [19.5, 486.0], [19.6, 486.0], [19.7, 486.0], [19.8, 486.0], [19.9, 486.0], [20.0, 486.0], [20.1, 487.0], [20.2, 487.0], [20.3, 487.0], [20.4, 487.0], [20.5, 487.0], [20.6, 487.0], [20.7, 487.0], [20.8, 488.0], [20.9, 488.0], [21.0, 488.0], [21.1, 488.0], [21.2, 488.0], [21.3, 488.0], [21.4, 488.0], [21.5, 488.0], [21.6, 488.0], [21.7, 488.0], [21.8, 489.0], [21.9, 489.0], [22.0, 489.0], [22.1, 489.0], [22.2, 489.0], [22.3, 489.0], [22.4, 489.0], [22.5, 489.0], [22.6, 489.0], [22.7, 489.0], [22.8, 489.0], [22.9, 489.0], [23.0, 489.0], [23.1, 489.0], [23.2, 489.0], [23.3, 489.0], [23.4, 489.0], [23.5, 489.0], [23.6, 490.0], [23.7, 490.0], [23.8, 490.0], [23.9, 490.0], [24.0, 490.0], [24.1, 490.0], [24.2, 490.0], [24.3, 490.0], [24.4, 490.0], [24.5, 490.0], [24.6, 490.0], [24.7, 491.0], [24.8, 491.0], [24.9, 491.0], [25.0, 491.0], [25.1, 491.0], [25.2, 491.0], [25.3, 491.0], [25.4, 491.0], [25.5, 491.0], [25.6, 491.0], [25.7, 492.0], [25.8, 492.0], [25.9, 492.0], [26.0, 492.0], [26.1, 492.0], [26.2, 492.0], [26.3, 492.0], [26.4, 492.0], [26.5, 492.0], [26.6, 492.0], [26.7, 492.0], [26.8, 492.0], [26.9, 492.0], [27.0, 492.0], [27.1, 492.0], [27.2, 492.0], [27.3, 492.0], [27.4, 492.0], [27.5, 492.0], [27.6, 492.0], [27.7, 492.0], [27.8, 492.0], [27.9, 492.0], [28.0, 493.0], [28.1, 493.0], [28.2, 493.0], [28.3, 493.0], [28.4, 493.0], [28.5, 494.0], [28.6, 494.0], [28.7, 494.0], [28.8, 494.0], [28.9, 494.0], [29.0, 494.0], [29.1, 494.0], [29.2, 494.0], [29.3, 494.0], [29.4, 494.0], [29.5, 495.0], [29.6, 495.0], [29.7, 495.0], [29.8, 495.0], [29.9, 495.0], [30.0, 495.0], [30.1, 496.0], [30.2, 496.0], [30.3, 496.0], [30.4, 496.0], [30.5, 496.0], [30.6, 496.0], [30.7, 496.0], [30.8, 496.0], [30.9, 496.0], [31.0, 496.0], [31.1, 497.0], [31.2, 497.0], [31.3, 497.0], [31.4, 497.0], [31.5, 497.0], [31.6, 497.0], [31.7, 497.0], [31.8, 498.0], [31.9, 498.0], [32.0, 498.0], [32.1, 498.0], [32.2, 498.0], [32.3, 498.0], [32.4, 498.0], [32.5, 498.0], [32.6, 498.0], [32.7, 498.0], [32.8, 498.0], [32.9, 498.0], [33.0, 498.0], [33.1, 498.0], [33.2, 498.0], [33.3, 498.0], [33.4, 498.0], [33.5, 498.0], [33.6, 498.0], [33.7, 498.0], [33.8, 498.0], [33.9, 499.0], [34.0, 499.0], [34.1, 499.0], [34.2, 499.0], [34.3, 499.0], [34.4, 499.0], [34.5, 499.0], [34.6, 499.0], [34.7, 500.0], [34.8, 500.0], [34.9, 500.0], [35.0, 500.0], [35.1, 500.0], [35.2, 501.0], [35.3, 501.0], [35.4, 501.0], [35.5, 501.0], [35.6, 501.0], [35.7, 502.0], [35.8, 502.0], [35.9, 503.0], [36.0, 503.0], [36.1, 503.0], [36.2, 503.0], [36.3, 503.0], [36.4, 503.0], [36.5, 503.0], [36.6, 503.0], [36.7, 504.0], [36.8, 504.0], [36.9, 504.0], [37.0, 504.0], [37.1, 504.0], [37.2, 504.0], [37.3, 504.0], [37.4, 504.0], [37.5, 505.0], [37.6, 505.0], [37.7, 505.0], [37.8, 505.0], [37.9, 505.0], [38.0, 505.0], [38.1, 505.0], [38.2, 505.0], [38.3, 505.0], [38.4, 505.0], [38.5, 505.0], [38.6, 505.0], [38.7, 505.0], [38.8, 505.0], [38.9, 505.0], [39.0, 505.0], [39.1, 505.0], [39.2, 505.0], [39.3, 506.0], [39.4, 506.0], [39.5, 506.0], [39.6, 506.0], [39.7, 506.0], [39.8, 506.0], [39.9, 506.0], [40.0, 506.0], [40.1, 506.0], [40.2, 506.0], [40.3, 506.0], [40.4, 506.0], [40.5, 506.0], [40.6, 507.0], [40.7, 507.0], [40.8, 507.0], [40.9, 507.0], [41.0, 507.0], [41.1, 507.0], [41.2, 507.0], [41.3, 509.0], [41.4, 509.0], [41.5, 509.0], [41.6, 509.0], [41.7, 509.0], [41.8, 509.0], [41.9, 509.0], [42.0, 509.0], [42.1, 510.0], [42.2, 510.0], [42.3, 510.0], [42.4, 510.0], [42.5, 510.0], [42.6, 510.0], [42.7, 510.0], [42.8, 510.0], [42.9, 510.0], [43.0, 510.0], [43.1, 511.0], [43.2, 511.0], [43.3, 511.0], [43.4, 511.0], [43.5, 511.0], [43.6, 512.0], [43.7, 512.0], [43.8, 512.0], [43.9, 513.0], [44.0, 513.0], [44.1, 513.0], [44.2, 514.0], [44.3, 514.0], [44.4, 515.0], [44.5, 515.0], [44.6, 515.0], [44.7, 515.0], [44.8, 515.0], [44.9, 516.0], [45.0, 516.0], [45.1, 516.0], [45.2, 516.0], [45.3, 516.0], [45.4, 517.0], [45.5, 517.0], [45.6, 517.0], [45.7, 519.0], [45.8, 519.0], [45.9, 519.0], [46.0, 519.0], [46.1, 519.0], [46.2, 520.0], [46.3, 520.0], [46.4, 520.0], [46.5, 523.0], [46.6, 523.0], [46.7, 528.0], [46.8, 528.0], [46.9, 528.0], [47.0, 529.0], [47.1, 529.0], [47.2, 532.0], [47.3, 532.0], [47.4, 532.0], [47.5, 532.0], [47.6, 532.0], [47.7, 532.0], [47.8, 532.0], [47.9, 532.0], [48.0, 535.0], [48.1, 535.0], [48.2, 535.0], [48.3, 536.0], [48.4, 536.0], [48.5, 538.0], [48.6, 538.0], [48.7, 538.0], [48.8, 540.0], [48.9, 540.0], [49.0, 543.0], [49.1, 543.0], [49.2, 543.0], [49.3, 545.0], [49.4, 545.0], [49.5, 545.0], [49.6, 545.0], [49.7, 545.0], [49.8, 547.0], [49.9, 547.0], [50.0, 574.0], [50.1, 574.0], [50.2, 574.0], [50.3, 579.0], [50.4, 579.0], [50.5, 579.0], [50.6, 596.0], [50.7, 596.0], [50.8, 628.0], [50.9, 628.0], [51.0, 628.0], [51.1, 659.0], [51.2, 659.0], [51.3, 664.0], [51.4, 664.0], [51.5, 664.0], [51.6, 664.0], [51.7, 664.0], [51.8, 666.0], [51.9, 666.0], [52.0, 666.0], [52.1, 670.0], [52.2, 670.0], [52.3, 670.0], [52.4, 674.0], [52.5, 674.0], [52.6, 674.0], [52.7, 674.0], [52.8, 674.0], [52.9, 675.0], [53.0, 675.0], [53.1, 675.0], [53.2, 675.0], [53.3, 675.0], [53.4, 676.0], [53.5, 676.0], [53.6, 676.0], [53.7, 676.0], [53.8, 676.0], [53.9, 676.0], [54.0, 676.0], [54.1, 676.0], [54.2, 678.0], [54.3, 678.0], [54.4, 679.0], [54.5, 679.0], [54.6, 679.0], [54.7, 679.0], [54.8, 679.0], [54.9, 679.0], [55.0, 679.0], [55.1, 679.0], [55.2, 679.0], [55.3, 679.0], [55.4, 679.0], [55.5, 679.0], [55.6, 679.0], [55.7, 680.0], [55.8, 680.0], [55.9, 680.0], [56.0, 680.0], [56.1, 680.0], [56.2, 680.0], [56.3, 680.0], [56.4, 680.0], [56.5, 680.0], [56.6, 680.0], [56.7, 682.0], [56.8, 682.0], [56.9, 682.0], [57.0, 682.0], [57.1, 682.0], [57.2, 683.0], [57.3, 683.0], [57.4, 683.0], [57.5, 683.0], [57.6, 683.0], [57.7, 683.0], [57.8, 683.0], [57.9, 683.0], [58.0, 684.0], [58.1, 684.0], [58.2, 684.0], [58.3, 684.0], [58.4, 684.0], [58.5, 685.0], [58.6, 685.0], [58.7, 685.0], [58.8, 685.0], [58.9, 685.0], [59.0, 685.0], [59.1, 685.0], [59.2, 685.0], [59.3, 686.0], [59.4, 686.0], [59.5, 688.0], [59.6, 688.0], [59.7, 688.0], [59.8, 690.0], [59.9, 690.0], [60.0, 691.0], [60.1, 691.0], [60.2, 691.0], [60.3, 692.0], [60.4, 692.0], [60.5, 692.0], [60.6, 692.0], [60.7, 692.0], [60.8, 693.0], [60.9, 693.0], [61.0, 693.0], [61.1, 694.0], [61.2, 694.0], [61.3, 694.0], [61.4, 694.0], [61.5, 694.0], [61.6, 694.0], [61.7, 694.0], [61.8, 695.0], [61.9, 695.0], [62.0, 695.0], [62.1, 695.0], [62.2, 695.0], [62.3, 695.0], [62.4, 695.0], [62.5, 695.0], [62.6, 696.0], [62.7, 696.0], [62.8, 696.0], [62.9, 696.0], [63.0, 696.0], [63.1, 697.0], [63.2, 697.0], [63.3, 697.0], [63.4, 697.0], [63.5, 697.0], [63.6, 697.0], [63.7, 697.0], [63.8, 697.0], [63.9, 697.0], [64.0, 697.0], [64.1, 697.0], [64.2, 698.0], [64.3, 698.0], [64.4, 699.0], [64.5, 699.0], [64.6, 699.0], [64.7, 699.0], [64.8, 699.0], [64.9, 699.0], [65.0, 699.0], [65.1, 699.0], [65.2, 702.0], [65.3, 702.0], [65.4, 702.0], [65.5, 702.0], [65.6, 702.0], [65.7, 703.0], [65.8, 703.0], [65.9, 703.0], [66.0, 703.0], [66.1, 703.0], [66.2, 703.0], [66.3, 703.0], [66.4, 703.0], [66.5, 704.0], [66.6, 704.0], [66.7, 704.0], [66.8, 704.0], [66.9, 704.0], [67.0, 706.0], [67.1, 706.0], [67.2, 707.0], [67.3, 707.0], [67.4, 707.0], [67.5, 707.0], [67.6, 707.0], [67.7, 708.0], [67.8, 708.0], [67.9, 708.0], [68.0, 709.0], [68.1, 709.0], [68.2, 709.0], [68.3, 709.0], [68.4, 709.0], [68.5, 709.0], [68.6, 709.0], [68.7, 709.0], [68.8, 711.0], [68.9, 711.0], [69.0, 712.0], [69.1, 712.0], [69.2, 712.0], [69.3, 713.0], [69.4, 713.0], [69.5, 713.0], [69.6, 713.0], [69.7, 713.0], [69.8, 716.0], [69.9, 716.0], [70.0, 716.0], [70.1, 716.0], [70.2, 716.0], [70.3, 717.0], [70.4, 717.0], [70.5, 717.0], [70.6, 718.0], [70.7, 718.0], [70.8, 719.0], [70.9, 719.0], [71.0, 719.0], [71.1, 719.0], [71.2, 719.0], [71.3, 720.0], [71.4, 720.0], [71.5, 720.0], [71.6, 722.0], [71.7, 722.0], [71.8, 723.0], [71.9, 723.0], [72.0, 723.0], [72.1, 725.0], [72.2, 725.0], [72.3, 725.0], [72.4, 725.0], [72.5, 725.0], [72.6, 726.0], [72.7, 726.0], [72.8, 726.0], [72.9, 728.0], [73.0, 728.0], [73.1, 728.0], [73.2, 728.0], [73.3, 728.0], [73.4, 729.0], [73.5, 729.0], [73.6, 729.0], [73.7, 729.0], [73.8, 729.0], [73.9, 730.0], [74.0, 730.0], [74.1, 730.0], [74.2, 731.0], [74.3, 731.0], [74.4, 734.0], [74.5, 734.0], [74.6, 734.0], [74.7, 737.0], [74.8, 737.0], [74.9, 737.0], [75.0, 737.0], [75.1, 737.0], [75.2, 737.0], [75.3, 737.0], [75.4, 739.0], [75.5, 739.0], [75.6, 739.0], [75.7, 744.0], [75.8, 744.0], [75.9, 745.0], [76.0, 745.0], [76.1, 745.0], [76.2, 746.0], [76.3, 746.0], [76.4, 746.0], [76.5, 748.0], [76.6, 748.0], [76.7, 777.0], [76.8, 777.0], [76.9, 777.0], [77.0, 827.0], [77.1, 827.0], [77.2, 829.0], [77.3, 829.0], [77.4, 829.0], [77.5, 851.0], [77.6, 851.0], [77.7, 855.0], [77.8, 855.0], [77.9, 855.0], [78.0, 886.0], [78.1, 886.0], [78.2, 886.0], [78.3, 890.0], [78.4, 890.0], [78.5, 891.0], [78.6, 891.0], [78.7, 891.0], [78.8, 891.0], [78.9, 891.0], [79.0, 894.0], [79.1, 894.0], [79.2, 894.0], [79.3, 903.0], [79.4, 903.0], [79.5, 909.0], [79.6, 909.0], [79.7, 909.0], [79.8, 918.0], [79.9, 918.0], [80.0, 918.0], [80.1, 919.0], [80.2, 919.0], [80.3, 921.0], [80.4, 921.0], [80.5, 921.0], [80.6, 935.0], [80.7, 935.0], [80.8, 937.0], [80.9, 937.0], [81.0, 937.0], [81.1, 942.0], [81.2, 942.0], [81.3, 946.0], [81.4, 946.0], [81.5, 946.0], [81.6, 959.0], [81.7, 959.0], [81.8, 971.0], [81.9, 971.0], [82.0, 971.0], [82.1, 972.0], [82.2, 972.0], [82.3, 972.0], [82.4, 980.0], [82.5, 980.0], [82.6, 1030.0], [82.7, 1030.0], [82.8, 1030.0], [82.9, 1044.0], [83.0, 1044.0], [83.1, 1057.0], [83.2, 1057.0], [83.3, 1057.0], [83.4, 1063.0], [83.5, 1063.0], [83.6, 1093.0], [83.7, 1093.0], [83.8, 1093.0], [83.9, 1106.0], [84.0, 1106.0], [84.1, 1106.0], [84.2, 1153.0], [84.3, 1153.0], [84.4, 1163.0], [84.5, 1163.0], [84.6, 1163.0], [84.7, 1170.0], [84.8, 1170.0], [84.9, 1190.0], [85.0, 1190.0], [85.1, 1190.0], [85.2, 1306.0], [85.3, 1306.0], [85.4, 1425.0], [85.5, 1425.0], [85.6, 1425.0], [85.7, 1450.0], [85.8, 1450.0], [85.9, 1491.0], [86.0, 1491.0], [86.1, 1491.0], [86.2, 1513.0], [86.3, 1513.0], [86.4, 1513.0], [86.5, 1544.0], [86.6, 1544.0], [86.7, 1556.0], [86.8, 1556.0], [86.9, 1556.0], [87.0, 1561.0], [87.1, 1561.0], [87.2, 1562.0], [87.3, 1562.0], [87.4, 1562.0], [87.5, 1576.0], [87.6, 1576.0], [87.7, 1603.0], [87.8, 1603.0], [87.9, 1603.0], [88.0, 1609.0], [88.1, 1609.0], [88.2, 1609.0], [88.3, 1618.0], [88.4, 1618.0], [88.5, 1621.0], [88.6, 1621.0], [88.7, 1621.0], [88.8, 1656.0], [88.9, 1656.0], [89.0, 1675.0], [89.1, 1675.0], [89.2, 1675.0], [89.3, 1680.0], [89.4, 1680.0], [89.5, 1690.0], [89.6, 1690.0], [89.7, 1690.0], [89.8, 1713.0], [89.9, 1713.0], [90.0, 1713.0], [90.1, 1729.0], [90.2, 1729.0], [90.3, 1730.0], [90.4, 1730.0], [90.5, 1730.0], [90.6, 1761.0], [90.7, 1761.0], [90.8, 1764.0], [90.9, 1764.0], [91.0, 1764.0], [91.1, 1800.0], [91.2, 1800.0], [91.3, 1805.0], [91.4, 1805.0], [91.5, 1805.0], [91.6, 1829.0], [91.7, 1829.0], [91.8, 1833.0], [91.9, 1833.0], [92.0, 1833.0], [92.1, 1900.0], [92.2, 1900.0], [92.3, 1900.0], [92.4, 1904.0], [92.5, 1904.0], [92.6, 1954.0], [92.7, 1954.0], [92.8, 1954.0], [92.9, 1971.0], [93.0, 1971.0], [93.1, 2029.0], [93.2, 2029.0], [93.3, 2029.0], [93.4, 2031.0], [93.5, 2031.0], [93.6, 2119.0], [93.7, 2119.0], [93.8, 2119.0], [93.9, 2124.0], [94.0, 2124.0], [94.1, 2124.0], [94.2, 2202.0], [94.3, 2202.0], [94.4, 2208.0], [94.5, 2208.0], [94.6, 2208.0], [94.7, 2211.0], [94.8, 2211.0], [94.9, 2241.0], [95.0, 2241.0], [95.1, 2241.0], [95.2, 2244.0], [95.3, 2244.0], [95.4, 2278.0], [95.5, 2278.0], [95.6, 2278.0], [95.7, 2309.0], [95.8, 2309.0], [95.9, 2374.0], [96.0, 2374.0], [96.1, 2374.0], [96.2, 2377.0], [96.3, 2377.0], [96.4, 2377.0], [96.5, 2472.0], [96.6, 2472.0], [96.7, 2489.0], [96.8, 2489.0], [96.9, 2489.0], [97.0, 2528.0], [97.1, 2528.0], [97.2, 2704.0], [97.3, 2704.0], [97.4, 2704.0], [97.5, 2724.0], [97.6, 2724.0], [97.7, 2761.0], [97.8, 2761.0], [97.9, 2761.0], [98.0, 2767.0], [98.1, 2767.0], [98.2, 2767.0], [98.3, 2927.0], [98.4, 2927.0], [98.5, 3151.0], [98.6, 3151.0], [98.7, 3151.0], [98.8, 4400.0], [98.9, 4400.0], [99.0, 4459.0], [99.1, 4459.0], [99.2, 4459.0], [99.3, 4570.0], [99.4, 4570.0], [99.5, 5946.0], [99.6, 5946.0], [99.7, 5946.0], [99.8, 24492.0], [99.9, 24492.0], [100.0, 24492.0]], "isOverall": false, "label": "GET - List Orders", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 400.0, "maxY": 135.0, "series": [{"data": [[600.0, 56.0], [700.0, 46.0], [800.0, 9.0], [900.0, 13.0], [1000.0, 5.0], [1100.0, 5.0], [1300.0, 1.0], [1400.0, 3.0], [1500.0, 6.0], [24400.0, 1.0], [1600.0, 8.0], [1700.0, 5.0], [1800.0, 4.0], [1900.0, 4.0], [2000.0, 2.0], [2100.0, 2.0], [2200.0, 6.0], [2300.0, 3.0], [2400.0, 2.0], [2500.0, 1.0], [2700.0, 4.0], [2900.0, 1.0], [3100.0, 1.0], [4400.0, 2.0], [4500.0, 1.0], [5900.0, 1.0], [400.0, 135.0], [500.0, 63.0]], "isOverall": false, "label": "GET - List Orders", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 24400.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 199.0, "series": [{"data": [[0.0, 137.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 199.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [[2.0, 53.0]], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [[3.0, 1.0]], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 3.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 3.0, "minX": 1.792306035E12, "maxY": 5.0, "series": [{"data": [[1.792306065E12, 5.0], [1.79230615E12, 5.0], [1.79230611E12, 5.0], [1.79230606E12, 5.0], [1.792306145E12, 5.0], [1.792306105E12, 5.0], [1.79230614E12, 5.0], [1.792306055E12, 5.0], [1.7923061E12, 5.0], [1.792306185E12, 3.0], [1.79230605E12, 5.0], [1.792306135E12, 5.0], [1.79230618E12, 5.0], [1.792306095E12, 5.0], [1.792306045E12, 5.0], [1.79230613E12, 5.0], [1.79230609E12, 5.0], [1.792306175E12, 5.0], [1.79230604E12, 5.0], [1.792306125E12, 5.0], [1.792306085E12, 5.0], [1.79230617E12, 5.0], [1.792306075E12, 5.0], [1.79230612E12, 5.0], [1.792306035E12, 5.0], [1.79230608E12, 5.0], [1.792306165E12, 5.0], [1.79230607E12, 5.0], [1.792306155E12, 5.0], [1.792306115E12, 5.0], [1.79230616E12, 5.0]], "isOverall": false, "label": "Thread Group", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.792306185E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 706.0, "minX": 1.0, "maxY": 2767.0, "series": [{"data": [[4.0, 707.0], [2.0, 730.0], [1.0, 2767.0], [5.0, 892.7616580310878], [3.0, 706.0]], "isOverall": false, "label": "GET - List Orders", "isController": false}, {"data": [[4.974358974358974, 896.1948717948715]], "isOverall": false, "label": "GET - List Orders-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 5.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 921.6, "minX": 1.792306035E12, "maxY": 26715.6, "series": [{"data": [[1.792306065E12, 20778.8], [1.79230615E12, 14842.0], [1.79230611E12, 20778.8], [1.79230606E12, 22263.0], [1.792306145E12, 14842.0], [1.792306105E12, 26715.6], [1.79230614E12, 14842.0], [1.792306055E12, 22263.0], [1.7923061E12, 22263.0], [1.792306185E12, 7421.0], [1.79230605E12, 16326.2], [1.792306135E12, 16327.4], [1.79230618E12, 13357.8], [1.792306095E12, 19294.6], [1.792306045E12, 20780.2], [1.79230613E12, 20778.8], [1.79230609E12, 20778.8], [1.792306175E12, 20778.8], [1.79230604E12, 22263.0], [1.792306125E12, 20780.0], [1.792306085E12, 20778.8], [1.79230617E12, 21463.6], [1.792306075E12, 23747.2], [1.79230612E12, 23747.2], [1.792306035E12, 4452.6], [1.79230608E12, 20778.8], [1.792306165E12, 19294.6], [1.79230607E12, 10389.4], [1.792306155E12, 14842.0], [1.792306115E12, 23747.2], [1.79230616E12, 16326.2]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.792306065E12, 4300.8], [1.79230615E12, 3072.0], [1.79230611E12, 4300.8], [1.79230606E12, 4608.0], [1.792306145E12, 3072.0], [1.792306105E12, 5529.6], [1.79230614E12, 3072.0], [1.792306055E12, 4608.0], [1.7923061E12, 4608.0], [1.792306185E12, 1536.0], [1.79230605E12, 3379.2], [1.792306135E12, 3379.2], [1.79230618E12, 2764.8], [1.792306095E12, 3993.6], [1.792306045E12, 4300.8], [1.79230613E12, 4300.8], [1.79230609E12, 4300.8], [1.792306175E12, 4300.8], [1.79230604E12, 4608.0], [1.792306125E12, 4300.8], [1.792306085E12, 4300.8], [1.79230617E12, 4300.8], [1.792306075E12, 4915.2], [1.79230612E12, 4915.2], [1.792306035E12, 921.6], [1.79230608E12, 4300.8], [1.792306165E12, 3993.6], [1.79230607E12, 2150.4], [1.792306155E12, 3072.0], [1.792306115E12, 4915.2], [1.79230616E12, 3379.2]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.792306185E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 507.5, "minX": 1.792306035E12, "maxY": 2218.8666666666663, "series": [{"data": [[1.792306065E12, 944.4285714285716], [1.79230615E12, 926.8], [1.79230611E12, 507.5], [1.79230606E12, 568.4666666666667], [1.792306145E12, 1856.0], [1.792306105E12, 536.3333333333334], [1.79230614E12, 1140.2], [1.792306055E12, 628.0666666666666], [1.7923061E12, 635.1999999999999], [1.792306185E12, 1126.4], [1.79230605E12, 1301.5454545454543], [1.792306135E12, 1038.3636363636365], [1.79230618E12, 1276.2222222222222], [1.792306095E12, 866.2307692307693], [1.792306045E12, 684.0714285714284], [1.79230613E12, 715.5], [1.79230609E12, 843.6428571428571], [1.792306175E12, 955.0], [1.79230604E12, 925.9333333333334], [1.792306125E12, 755.5714285714286], [1.792306085E12, 697.142857142857], [1.79230617E12, 2218.8666666666663], [1.792306075E12, 1423.0625], [1.79230612E12, 554.4999999999999], [1.792306035E12, 622.6666666666666], [1.79230608E12, 712.1428571428571], [1.792306165E12, 573.6153846153845], [1.79230607E12, 857.2857142857143], [1.792306155E12, 1064.8], [1.792306115E12, 620.1874999999999], [1.79230616E12, 810.7272727272727]], "isOverall": false, "label": "GET - List Orders", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.792306185E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 507.5, "minX": 1.792306035E12, "maxY": 1856.0, "series": [{"data": [[1.792306065E12, 944.3571428571428], [1.79230615E12, 926.8], [1.79230611E12, 507.5], [1.79230606E12, 568.4666666666667], [1.792306145E12, 1856.0], [1.792306105E12, 536.2777777777776], [1.79230614E12, 1140.2], [1.792306055E12, 628.0666666666666], [1.7923061E12, 635.1999999999999], [1.792306185E12, 1126.4], [1.79230605E12, 1301.4545454545455], [1.792306135E12, 1038.2727272727273], [1.79230618E12, 1276.2222222222222], [1.792306095E12, 866.2307692307693], [1.792306045E12, 684.0714285714284], [1.79230613E12, 715.4285714285714], [1.79230609E12, 827.9285714285714], [1.792306175E12, 954.9285714285716], [1.79230604E12, 925.9333333333334], [1.792306125E12, 755.5714285714286], [1.792306085E12, 697.0714285714284], [1.79230617E12, 586.0666666666667], [1.792306075E12, 1423.0625], [1.79230612E12, 554.4999999999999], [1.792306035E12, 622.6666666666666], [1.79230608E12, 712.0714285714286], [1.792306165E12, 573.6153846153845], [1.79230607E12, 857.2857142857143], [1.792306155E12, 1064.8], [1.792306115E12, 620.125], [1.79230616E12, 810.7272727272727]], "isOverall": false, "label": "GET - List Orders", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.792306185E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 0.0, "minX": 1.792306035E12, "maxY": 361.4375, "series": [{"data": [[1.792306065E12, 33.142857142857146], [1.79230615E12, 0.0], [1.79230611E12, 0.0], [1.79230606E12, 0.0], [1.792306145E12, 0.0], [1.792306105E12, 0.0], [1.79230614E12, 0.0], [1.792306055E12, 0.0], [1.7923061E12, 0.0], [1.792306185E12, 0.0], [1.79230605E12, 0.0], [1.792306135E12, 139.90909090909088], [1.79230618E12, 0.0], [1.792306095E12, 0.0], [1.792306045E12, 0.0], [1.79230613E12, 33.07142857142857], [1.79230609E12, 0.0], [1.792306175E12, 0.0], [1.79230604E12, 0.0], [1.792306125E12, 33.0], [1.792306085E12, 0.0], [1.79230617E12, 87.73333333333335], [1.792306075E12, 361.4375], [1.79230612E12, 0.0], [1.792306035E12, 0.0], [1.79230608E12, 0.0], [1.792306165E12, 0.0], [1.79230607E12, 0.0], [1.792306155E12, 0.0], [1.792306115E12, 0.0], [1.79230616E12, 0.0]], "isOverall": false, "label": "GET - List Orders", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.792306185E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 460.0, "minX": 1.792306035E12, "maxY": 5946.0, "series": [{"data": [[1.792306065E12, 2278.0], [1.79230615E12, 1900.0], [1.79230611E12, 690.0], [1.79230606E12, 894.0], [1.792306145E12, 4570.0], [1.792306105E12, 729.0], [1.79230614E12, 2377.0], [1.792306055E12, 734.0], [1.7923061E12, 1425.0], [1.792306185E12, 2767.0], [1.79230605E12, 3151.0], [1.792306135E12, 2927.0], [1.79230618E12, 1833.0], [1.792306095E12, 2472.0], [1.792306045E12, 1057.0], [1.79230613E12, 2241.0], [1.79230609E12, 2528.0], [1.792306175E12, 2704.0], [1.79230604E12, 2211.0], [1.792306125E12, 1562.0], [1.792306085E12, 1603.0], [1.79230617E12, 1829.0], [1.792306075E12, 5946.0], [1.79230612E12, 1153.0], [1.792306035E12, 704.0], [1.79230608E12, 1764.0], [1.792306165E12, 703.0], [1.79230607E12, 1618.0], [1.792306155E12, 2244.0], [1.792306115E12, 2119.0], [1.79230616E12, 2309.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.792306065E12, 467.0], [1.79230615E12, 471.0], [1.79230611E12, 469.0], [1.79230606E12, 473.0], [1.792306145E12, 476.0], [1.792306105E12, 468.0], [1.79230614E12, 506.0], [1.792306055E12, 474.0], [1.7923061E12, 478.0], [1.792306185E12, 706.0], [1.79230605E12, 492.0], [1.792306135E12, 464.0], [1.79230618E12, 699.0], [1.792306095E12, 460.0], [1.792306045E12, 474.0], [1.79230613E12, 476.0], [1.79230609E12, 474.0], [1.792306175E12, 468.0], [1.79230604E12, 484.0], [1.792306125E12, 463.0], [1.792306085E12, 480.0], [1.79230617E12, 463.0], [1.792306075E12, 465.0], [1.79230612E12, 475.0], [1.792306035E12, 498.0], [1.79230608E12, 489.0], [1.792306165E12, 476.0], [1.79230607E12, 485.0], [1.792306155E12, 674.0], [1.792306115E12, 472.0], [1.79230616E12, 475.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.792306065E12, 2124.5], [1.79230615E12, 1870.9], [1.79230611E12, 611.0], [1.79230606E12, 765.6000000000001], [1.792306145E12, 4553.0], [1.792306105E12, 720.9], [1.79230614E12, 2342.4], [1.792306055E12, 730.4], [1.7923061E12, 1101.6000000000001], [1.792306185E12, 2767.0], [1.79230605E12, 2945.600000000001], [1.792306135E12, 2893.8], [1.79230618E12, 1833.0], [1.792306095E12, 2294.7999999999997], [1.792306045E12, 1050.5], [1.79230613E12, 1705.5], [1.79230609E12, 2101.5], [1.792306175E12, 2180.0], [1.79230604E12, 2209.2], [1.792306125E12, 1537.5], [1.792306085E12, 1247.0], [1.79230617E12, 1509.5], [1.792306075E12, 4905.100000000001], [1.79230612E12, 848.5000000000003], [1.792306035E12, 704.0], [1.79230608E12, 1722.0], [1.792306165E12, 702.6], [1.79230607E12, 1618.0], [1.792306155E12, 2239.8], [1.792306115E12, 1139.000000000001], [1.79230616E12, 2030.800000000001]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.792306065E12, 2278.0], [1.79230615E12, 1900.0], [1.79230611E12, 690.0], [1.79230606E12, 894.0], [1.792306145E12, 4570.0], [1.792306105E12, 729.0], [1.79230614E12, 2377.0], [1.792306055E12, 734.0], [1.7923061E12, 1425.0], [1.792306185E12, 2767.0], [1.79230605E12, 3151.0], [1.792306135E12, 2927.0], [1.79230618E12, 1833.0], [1.792306095E12, 2472.0], [1.792306045E12, 1057.0], [1.79230613E12, 2241.0], [1.79230609E12, 2528.0], [1.792306175E12, 2704.0], [1.79230604E12, 2211.0], [1.792306125E12, 1562.0], [1.792306085E12, 1603.0], [1.79230617E12, 1829.0], [1.792306075E12, 5946.0], [1.79230612E12, 1153.0], [1.792306035E12, 704.0], [1.79230608E12, 1764.0], [1.792306165E12, 703.0], [1.79230607E12, 1618.0], [1.792306155E12, 2244.0], [1.792306115E12, 2119.0], [1.79230616E12, 2309.0]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.792306065E12, 700.5], [1.79230615E12, 815.0], [1.79230611E12, 491.5], [1.79230606E12, 500.0], [1.792306145E12, 1226.0], [1.792306105E12, 487.5], [1.79230614E12, 854.5], [1.792306055E12, 686.0], [1.7923061E12, 500.0], [1.792306185E12, 722.0], [1.79230605E12, 1306.0], [1.792306135E12, 506.0], [1.79230618E12, 1556.0], [1.792306095E12, 664.0], [1.792306045E12, 694.5], [1.79230613E12, 490.5], [1.79230609E12, 533.5], [1.792306175E12, 679.5], [1.79230604E12, 731.0], [1.792306125E12, 679.0], [1.792306085E12, 598.5], [1.79230617E12, 481.5], [1.792306075E12, 602.0], [1.79230612E12, 507.0], [1.792306035E12, 666.0], [1.79230608E12, 504.0], [1.792306165E12, 510.0], [1.79230607E12, 674.0], [1.792306155E12, 808.0], [1.792306115E12, 495.0], [1.79230616E12, 697.0]], "isOverall": false, "label": "Median", "isController": false}, {"data": [[1.792306065E12, 2278.0], [1.79230615E12, 1900.0], [1.79230611E12, 690.0], [1.79230606E12, 894.0], [1.792306145E12, 4570.0], [1.792306105E12, 729.0], [1.79230614E12, 2377.0], [1.792306055E12, 734.0], [1.7923061E12, 1425.0], [1.792306185E12, 2767.0], [1.79230605E12, 3151.0], [1.792306135E12, 2927.0], [1.79230618E12, 1833.0], [1.792306095E12, 2472.0], [1.792306045E12, 1057.0], [1.79230613E12, 2241.0], [1.79230609E12, 2528.0], [1.792306175E12, 2704.0], [1.79230604E12, 2211.0], [1.792306125E12, 1562.0], [1.792306085E12, 1603.0], [1.79230617E12, 1829.0], [1.792306075E12, 5946.0], [1.79230612E12, 1153.0], [1.792306035E12, 704.0], [1.79230608E12, 1764.0], [1.792306165E12, 703.0], [1.79230607E12, 1618.0], [1.792306155E12, 2244.0], [1.792306115E12, 2119.0], [1.79230616E12, 2309.0]], "isOverall": false, "label": "95th percentile", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.792306185E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 527.5, "minX": 1.0, "maxY": 24492.0, "series": [{"data": [[2.0, 527.5], [1.0, 678.0], [4.0, 536.0], [5.0, 546.5], [3.0, 596.0]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[4.0, 24492.0]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 5.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 0.0, "minX": 1.0, "maxY": 666.0, "series": [{"data": [[2.0, 527.5], [1.0, 666.0], [4.0, 536.0], [5.0, 546.5], [3.0, 596.0]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[4.0, 0.0]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 5.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 0.8, "minX": 1.792306035E12, "maxY": 3.4, "series": [{"data": [[1.792306065E12, 2.6], [1.79230615E12, 2.2], [1.79230611E12, 3.2], [1.79230606E12, 2.8], [1.792306145E12, 2.0], [1.792306105E12, 3.0], [1.79230614E12, 1.4], [1.792306055E12, 3.2], [1.7923061E12, 3.4], [1.792306185E12, 0.8], [1.79230605E12, 2.6], [1.792306135E12, 2.8], [1.79230618E12, 2.0], [1.792306095E12, 2.8], [1.792306045E12, 2.8], [1.79230613E12, 2.8], [1.79230609E12, 2.6], [1.792306175E12, 2.2], [1.79230604E12, 2.4], [1.792306125E12, 2.8], [1.792306085E12, 2.8], [1.79230617E12, 3.0], [1.792306075E12, 2.6], [1.79230612E12, 3.2], [1.792306035E12, 1.4], [1.79230608E12, 2.8], [1.792306165E12, 2.6], [1.79230607E12, 1.8], [1.792306155E12, 1.8], [1.792306115E12, 3.2], [1.79230616E12, 2.4]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.792306185E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 0.2, "minX": 1.792306035E12, "maxY": 3.6, "series": [{"data": [[1.792306065E12, 2.8], [1.79230615E12, 2.0], [1.79230611E12, 2.8], [1.79230606E12, 3.0], [1.792306145E12, 2.0], [1.792306105E12, 3.6], [1.79230614E12, 2.0], [1.792306055E12, 3.0], [1.7923061E12, 3.0], [1.792306185E12, 1.0], [1.79230605E12, 2.2], [1.792306135E12, 2.2], [1.79230618E12, 1.8], [1.792306095E12, 2.6], [1.792306045E12, 2.8], [1.79230613E12, 2.8], [1.79230609E12, 2.8], [1.792306175E12, 2.8], [1.79230604E12, 3.0], [1.792306125E12, 2.8], [1.792306085E12, 2.8], [1.79230617E12, 2.8], [1.792306075E12, 3.2], [1.79230612E12, 3.2], [1.792306035E12, 0.6], [1.79230608E12, 2.8], [1.792306165E12, 2.6], [1.79230607E12, 1.4], [1.792306155E12, 2.0], [1.792306115E12, 3.2], [1.79230616E12, 2.2]], "isOverall": false, "label": "200", "isController": false}, {"data": [[1.79230617E12, 0.2]], "isOverall": false, "label": "Non HTTP response code: java.net.SocketTimeoutException", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.792306185E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 0.2, "minX": 1.792306035E12, "maxY": 3.6, "series": [{"data": [[1.792306065E12, 2.8], [1.79230615E12, 2.0], [1.79230611E12, 2.8], [1.79230606E12, 3.0], [1.792306145E12, 2.0], [1.792306105E12, 3.6], [1.79230614E12, 2.0], [1.792306055E12, 3.0], [1.7923061E12, 3.0], [1.792306185E12, 1.0], [1.79230605E12, 2.2], [1.792306135E12, 2.2], [1.79230618E12, 1.8], [1.792306095E12, 2.6], [1.792306045E12, 2.8], [1.79230613E12, 2.8], [1.79230609E12, 2.8], [1.792306175E12, 2.8], [1.79230604E12, 3.0], [1.792306125E12, 2.8], [1.792306085E12, 2.8], [1.79230617E12, 2.8], [1.792306075E12, 3.2], [1.79230612E12, 3.2], [1.792306035E12, 0.6], [1.79230608E12, 2.8], [1.792306165E12, 2.6], [1.79230607E12, 1.4], [1.792306155E12, 2.0], [1.792306115E12, 3.2], [1.79230616E12, 2.2]], "isOverall": false, "label": "GET - List Orders-success", "isController": false}, {"data": [[1.79230617E12, 0.2]], "isOverall": false, "label": "GET - List Orders-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.792306185E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 0.2, "minX": 1.792306035E12, "maxY": 3.6, "series": [{"data": [[1.792306065E12, 2.8], [1.79230615E12, 2.0], [1.79230611E12, 2.8], [1.79230606E12, 3.0], [1.792306145E12, 2.0], [1.792306105E12, 3.6], [1.79230614E12, 2.0], [1.792306055E12, 3.0], [1.7923061E12, 3.0], [1.792306185E12, 1.0], [1.79230605E12, 2.2], [1.792306135E12, 2.2], [1.79230618E12, 1.8], [1.792306095E12, 2.6], [1.792306045E12, 2.8], [1.79230613E12, 2.8], [1.79230609E12, 2.8], [1.792306175E12, 2.8], [1.79230604E12, 3.0], [1.792306125E12, 2.8], [1.792306085E12, 2.8], [1.79230617E12, 2.8], [1.792306075E12, 3.2], [1.79230612E12, 3.2], [1.792306035E12, 0.6], [1.79230608E12, 2.8], [1.792306165E12, 2.6], [1.79230607E12, 1.4], [1.792306155E12, 2.0], [1.792306115E12, 3.2], [1.79230616E12, 2.2]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [[1.79230617E12, 0.2]], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.792306185E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

