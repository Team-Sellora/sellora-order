/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 129.0, "minX": 0.0, "maxY": 17475.0, "series": [{"data": [[0.0, 129.0], [0.1, 129.0], [0.2, 129.0], [0.3, 129.0], [0.4, 129.0], [0.5, 129.0], [0.6, 129.0], [0.7, 129.0], [0.8, 129.0], [0.9, 129.0], [1.0, 132.0], [1.1, 132.0], [1.2, 132.0], [1.3, 132.0], [1.4, 132.0], [1.5, 132.0], [1.6, 132.0], [1.7, 132.0], [1.8, 132.0], [1.9, 133.0], [2.0, 133.0], [2.1, 133.0], [2.2, 133.0], [2.3, 133.0], [2.4, 133.0], [2.5, 133.0], [2.6, 133.0], [2.7, 133.0], [2.8, 133.0], [2.9, 133.0], [3.0, 133.0], [3.1, 133.0], [3.2, 133.0], [3.3, 133.0], [3.4, 133.0], [3.5, 133.0], [3.6, 133.0], [3.7, 133.0], [3.8, 134.0], [3.9, 134.0], [4.0, 134.0], [4.1, 134.0], [4.2, 134.0], [4.3, 134.0], [4.4, 134.0], [4.5, 134.0], [4.6, 134.0], [4.7, 134.0], [4.8, 135.0], [4.9, 135.0], [5.0, 135.0], [5.1, 135.0], [5.2, 135.0], [5.3, 135.0], [5.4, 135.0], [5.5, 135.0], [5.6, 135.0], [5.7, 135.0], [5.8, 135.0], [5.9, 135.0], [6.0, 135.0], [6.1, 135.0], [6.2, 135.0], [6.3, 135.0], [6.4, 135.0], [6.5, 135.0], [6.6, 135.0], [6.7, 137.0], [6.8, 137.0], [6.9, 137.0], [7.0, 137.0], [7.1, 137.0], [7.2, 137.0], [7.3, 137.0], [7.4, 137.0], [7.5, 137.0], [7.6, 138.0], [7.7, 138.0], [7.8, 138.0], [7.9, 138.0], [8.0, 138.0], [8.1, 138.0], [8.2, 138.0], [8.3, 138.0], [8.4, 138.0], [8.5, 138.0], [8.6, 138.0], [8.7, 138.0], [8.8, 138.0], [8.9, 138.0], [9.0, 138.0], [9.1, 138.0], [9.2, 138.0], [9.3, 138.0], [9.4, 138.0], [9.5, 139.0], [9.6, 139.0], [9.7, 139.0], [9.8, 139.0], [9.9, 139.0], [10.0, 139.0], [10.1, 139.0], [10.2, 139.0], [10.3, 139.0], [10.4, 140.0], [10.5, 140.0], [10.6, 140.0], [10.7, 140.0], [10.8, 140.0], [10.9, 140.0], [11.0, 140.0], [11.1, 140.0], [11.2, 140.0], [11.3, 140.0], [11.4, 140.0], [11.5, 140.0], [11.6, 140.0], [11.7, 140.0], [11.8, 140.0], [11.9, 140.0], [12.0, 140.0], [12.1, 140.0], [12.2, 140.0], [12.3, 141.0], [12.4, 141.0], [12.5, 141.0], [12.6, 141.0], [12.7, 141.0], [12.8, 141.0], [12.9, 141.0], [13.0, 141.0], [13.1, 141.0], [13.2, 141.0], [13.3, 142.0], [13.4, 142.0], [13.5, 142.0], [13.6, 142.0], [13.7, 142.0], [13.8, 142.0], [13.9, 142.0], [14.0, 142.0], [14.1, 142.0], [14.2, 142.0], [14.3, 142.0], [14.4, 142.0], [14.5, 142.0], [14.6, 142.0], [14.7, 142.0], [14.8, 142.0], [14.9, 142.0], [15.0, 142.0], [15.1, 142.0], [15.2, 142.0], [15.3, 142.0], [15.4, 142.0], [15.5, 142.0], [15.6, 142.0], [15.7, 142.0], [15.8, 142.0], [15.9, 142.0], [16.0, 142.0], [16.1, 142.0], [16.2, 142.0], [16.3, 142.0], [16.4, 142.0], [16.5, 142.0], [16.6, 142.0], [16.7, 142.0], [16.8, 142.0], [16.9, 142.0], [17.0, 143.0], [17.1, 143.0], [17.2, 143.0], [17.3, 143.0], [17.4, 143.0], [17.5, 143.0], [17.6, 143.0], [17.7, 143.0], [17.8, 143.0], [17.9, 143.0], [18.0, 143.0], [18.1, 143.0], [18.2, 143.0], [18.3, 143.0], [18.4, 143.0], [18.5, 143.0], [18.6, 143.0], [18.7, 143.0], [18.8, 143.0], [18.9, 144.0], [19.0, 144.0], [19.1, 144.0], [19.2, 144.0], [19.3, 144.0], [19.4, 144.0], [19.5, 144.0], [19.6, 144.0], [19.7, 144.0], [19.8, 144.0], [19.9, 145.0], [20.0, 145.0], [20.1, 145.0], [20.2, 145.0], [20.3, 145.0], [20.4, 145.0], [20.5, 145.0], [20.6, 145.0], [20.7, 145.0], [20.8, 145.0], [20.9, 145.0], [21.0, 145.0], [21.1, 145.0], [21.2, 145.0], [21.3, 145.0], [21.4, 145.0], [21.5, 145.0], [21.6, 145.0], [21.7, 145.0], [21.8, 145.0], [21.9, 145.0], [22.0, 145.0], [22.1, 145.0], [22.2, 145.0], [22.3, 145.0], [22.4, 145.0], [22.5, 145.0], [22.6, 145.0], [22.7, 146.0], [22.8, 146.0], [22.9, 146.0], [23.0, 146.0], [23.1, 146.0], [23.2, 146.0], [23.3, 146.0], [23.4, 146.0], [23.5, 146.0], [23.6, 146.0], [23.7, 146.0], [23.8, 146.0], [23.9, 146.0], [24.0, 146.0], [24.1, 146.0], [24.2, 146.0], [24.3, 146.0], [24.4, 146.0], [24.5, 146.0], [24.6, 146.0], [24.7, 146.0], [24.8, 146.0], [24.9, 146.0], [25.0, 146.0], [25.1, 146.0], [25.2, 146.0], [25.3, 146.0], [25.4, 146.0], [25.5, 146.0], [25.6, 146.0], [25.7, 146.0], [25.8, 146.0], [25.9, 146.0], [26.0, 146.0], [26.1, 146.0], [26.2, 146.0], [26.3, 146.0], [26.4, 146.0], [26.5, 146.0], [26.6, 146.0], [26.7, 146.0], [26.8, 146.0], [26.9, 146.0], [27.0, 146.0], [27.1, 146.0], [27.2, 146.0], [27.3, 146.0], [27.4, 147.0], [27.5, 147.0], [27.6, 147.0], [27.7, 147.0], [27.8, 147.0], [27.9, 147.0], [28.0, 147.0], [28.1, 147.0], [28.2, 147.0], [28.3, 147.0], [28.4, 147.0], [28.5, 147.0], [28.6, 147.0], [28.7, 147.0], [28.8, 147.0], [28.9, 147.0], [29.0, 147.0], [29.1, 147.0], [29.2, 147.0], [29.3, 149.0], [29.4, 149.0], [29.5, 149.0], [29.6, 149.0], [29.7, 149.0], [29.8, 149.0], [29.9, 149.0], [30.0, 149.0], [30.1, 149.0], [30.2, 149.0], [30.3, 149.0], [30.4, 149.0], [30.5, 149.0], [30.6, 149.0], [30.7, 149.0], [30.8, 149.0], [30.9, 149.0], [31.0, 149.0], [31.1, 149.0], [31.2, 150.0], [31.3, 150.0], [31.4, 150.0], [31.5, 150.0], [31.6, 150.0], [31.7, 150.0], [31.8, 150.0], [31.9, 150.0], [32.0, 150.0], [32.1, 150.0], [32.2, 150.0], [32.3, 150.0], [32.4, 150.0], [32.5, 150.0], [32.6, 150.0], [32.7, 150.0], [32.8, 150.0], [32.9, 150.0], [33.0, 150.0], [33.1, 151.0], [33.2, 151.0], [33.3, 151.0], [33.4, 151.0], [33.5, 151.0], [33.6, 151.0], [33.7, 151.0], [33.8, 151.0], [33.9, 151.0], [34.0, 151.0], [34.1, 151.0], [34.2, 151.0], [34.3, 151.0], [34.4, 151.0], [34.5, 151.0], [34.6, 151.0], [34.7, 151.0], [34.8, 151.0], [34.9, 151.0], [35.0, 152.0], [35.1, 152.0], [35.2, 152.0], [35.3, 152.0], [35.4, 152.0], [35.5, 152.0], [35.6, 152.0], [35.7, 152.0], [35.8, 152.0], [35.9, 152.0], [36.0, 152.0], [36.1, 152.0], [36.2, 152.0], [36.3, 152.0], [36.4, 152.0], [36.5, 152.0], [36.6, 152.0], [36.7, 152.0], [36.8, 153.0], [36.9, 153.0], [37.0, 153.0], [37.1, 153.0], [37.2, 153.0], [37.3, 153.0], [37.4, 153.0], [37.5, 153.0], [37.6, 153.0], [37.7, 153.0], [37.8, 154.0], [37.9, 154.0], [38.0, 154.0], [38.1, 154.0], [38.2, 154.0], [38.3, 154.0], [38.4, 154.0], [38.5, 154.0], [38.6, 154.0], [38.7, 154.0], [38.8, 154.0], [38.9, 154.0], [39.0, 154.0], [39.1, 154.0], [39.2, 154.0], [39.3, 154.0], [39.4, 154.0], [39.5, 154.0], [39.6, 154.0], [39.7, 155.0], [39.8, 155.0], [39.9, 155.0], [40.0, 155.0], [40.1, 155.0], [40.2, 155.0], [40.3, 155.0], [40.4, 155.0], [40.5, 155.0], [40.6, 155.0], [40.7, 155.0], [40.8, 155.0], [40.9, 155.0], [41.0, 155.0], [41.1, 155.0], [41.2, 155.0], [41.3, 155.0], [41.4, 155.0], [41.5, 155.0], [41.6, 155.0], [41.7, 155.0], [41.8, 155.0], [41.9, 155.0], [42.0, 155.0], [42.1, 155.0], [42.2, 155.0], [42.3, 155.0], [42.4, 155.0], [42.5, 155.0], [42.6, 155.0], [42.7, 155.0], [42.8, 155.0], [42.9, 155.0], [43.0, 155.0], [43.1, 155.0], [43.2, 155.0], [43.3, 155.0], [43.4, 156.0], [43.5, 156.0], [43.6, 156.0], [43.7, 156.0], [43.8, 156.0], [43.9, 156.0], [44.0, 156.0], [44.1, 156.0], [44.2, 156.0], [44.3, 156.0], [44.4, 156.0], [44.5, 156.0], [44.6, 156.0], [44.7, 156.0], [44.8, 156.0], [44.9, 156.0], [45.0, 156.0], [45.1, 156.0], [45.2, 156.0], [45.3, 156.0], [45.4, 156.0], [45.5, 156.0], [45.6, 156.0], [45.7, 156.0], [45.8, 156.0], [45.9, 156.0], [46.0, 156.0], [46.1, 156.0], [46.2, 156.0], [46.3, 156.0], [46.4, 156.0], [46.5, 156.0], [46.6, 156.0], [46.7, 156.0], [46.8, 156.0], [46.9, 156.0], [47.0, 156.0], [47.1, 156.0], [47.2, 157.0], [47.3, 157.0], [47.4, 157.0], [47.5, 157.0], [47.6, 157.0], [47.7, 157.0], [47.8, 157.0], [47.9, 157.0], [48.0, 157.0], [48.1, 157.0], [48.2, 158.0], [48.3, 158.0], [48.4, 158.0], [48.5, 158.0], [48.6, 158.0], [48.7, 158.0], [48.8, 158.0], [48.9, 158.0], [49.0, 158.0], [49.1, 158.0], [49.2, 158.0], [49.3, 158.0], [49.4, 158.0], [49.5, 158.0], [49.6, 158.0], [49.7, 158.0], [49.8, 158.0], [49.9, 158.0], [50.0, 159.0], [50.1, 159.0], [50.2, 159.0], [50.3, 159.0], [50.4, 159.0], [50.5, 159.0], [50.6, 159.0], [50.7, 159.0], [50.8, 159.0], [50.9, 159.0], [51.0, 160.0], [51.1, 160.0], [51.2, 160.0], [51.3, 160.0], [51.4, 160.0], [51.5, 160.0], [51.6, 160.0], [51.7, 160.0], [51.8, 160.0], [51.9, 161.0], [52.0, 161.0], [52.1, 161.0], [52.2, 161.0], [52.3, 161.0], [52.4, 161.0], [52.5, 161.0], [52.6, 161.0], [52.7, 161.0], [52.8, 161.0], [52.9, 161.0], [53.0, 161.0], [53.1, 161.0], [53.2, 161.0], [53.3, 161.0], [53.4, 161.0], [53.5, 161.0], [53.6, 161.0], [53.7, 161.0], [53.8, 161.0], [53.9, 161.0], [54.0, 161.0], [54.1, 161.0], [54.2, 161.0], [54.3, 161.0], [54.4, 161.0], [54.5, 161.0], [54.6, 161.0], [54.7, 161.0], [54.8, 161.0], [54.9, 161.0], [55.0, 161.0], [55.1, 161.0], [55.2, 161.0], [55.3, 161.0], [55.4, 161.0], [55.5, 161.0], [55.6, 161.0], [55.7, 162.0], [55.8, 162.0], [55.9, 162.0], [56.0, 162.0], [56.1, 162.0], [56.2, 162.0], [56.3, 162.0], [56.4, 162.0], [56.5, 162.0], [56.6, 162.0], [56.7, 163.0], [56.8, 163.0], [56.9, 163.0], [57.0, 163.0], [57.1, 163.0], [57.2, 163.0], [57.3, 163.0], [57.4, 163.0], [57.5, 163.0], [57.6, 164.0], [57.7, 164.0], [57.8, 164.0], [57.9, 164.0], [58.0, 164.0], [58.1, 164.0], [58.2, 164.0], [58.3, 164.0], [58.4, 164.0], [58.5, 164.0], [58.6, 164.0], [58.7, 164.0], [58.8, 164.0], [58.9, 164.0], [59.0, 164.0], [59.1, 164.0], [59.2, 164.0], [59.3, 164.0], [59.4, 164.0], [59.5, 165.0], [59.6, 165.0], [59.7, 165.0], [59.8, 165.0], [59.9, 165.0], [60.0, 165.0], [60.1, 165.0], [60.2, 165.0], [60.3, 165.0], [60.4, 166.0], [60.5, 166.0], [60.6, 166.0], [60.7, 166.0], [60.8, 166.0], [60.9, 166.0], [61.0, 166.0], [61.1, 166.0], [61.2, 166.0], [61.3, 166.0], [61.4, 166.0], [61.5, 166.0], [61.6, 166.0], [61.7, 166.0], [61.8, 166.0], [61.9, 166.0], [62.0, 166.0], [62.1, 166.0], [62.2, 166.0], [62.3, 166.0], [62.4, 166.0], [62.5, 166.0], [62.6, 166.0], [62.7, 166.0], [62.8, 166.0], [62.9, 166.0], [63.0, 166.0], [63.1, 166.0], [63.2, 166.0], [63.3, 168.0], [63.4, 168.0], [63.5, 168.0], [63.6, 168.0], [63.7, 168.0], [63.8, 168.0], [63.9, 168.0], [64.0, 168.0], [64.1, 168.0], [64.2, 168.0], [64.3, 168.0], [64.4, 168.0], [64.5, 168.0], [64.6, 168.0], [64.7, 168.0], [64.8, 168.0], [64.9, 168.0], [65.0, 168.0], [65.1, 169.0], [65.2, 169.0], [65.3, 169.0], [65.4, 169.0], [65.5, 169.0], [65.6, 169.0], [65.7, 169.0], [65.8, 169.0], [65.9, 169.0], [66.0, 169.0], [66.1, 169.0], [66.2, 169.0], [66.3, 169.0], [66.4, 169.0], [66.5, 169.0], [66.6, 169.0], [66.7, 169.0], [66.8, 169.0], [66.9, 169.0], [67.0, 169.0], [67.1, 169.0], [67.2, 169.0], [67.3, 169.0], [67.4, 169.0], [67.5, 169.0], [67.6, 169.0], [67.7, 169.0], [67.8, 169.0], [67.9, 169.0], [68.0, 169.0], [68.1, 169.0], [68.2, 169.0], [68.3, 169.0], [68.4, 169.0], [68.5, 169.0], [68.6, 169.0], [68.7, 169.0], [68.8, 169.0], [68.9, 169.0], [69.0, 169.0], [69.1, 169.0], [69.2, 169.0], [69.3, 169.0], [69.4, 169.0], [69.5, 169.0], [69.6, 169.0], [69.7, 169.0], [69.8, 169.0], [69.9, 170.0], [70.0, 170.0], [70.1, 170.0], [70.2, 170.0], [70.3, 170.0], [70.4, 170.0], [70.5, 170.0], [70.6, 170.0], [70.7, 170.0], [70.8, 170.0], [70.9, 170.0], [71.0, 170.0], [71.1, 170.0], [71.2, 170.0], [71.3, 170.0], [71.4, 170.0], [71.5, 170.0], [71.6, 170.0], [71.7, 171.0], [71.8, 171.0], [71.9, 171.0], [72.0, 171.0], [72.1, 171.0], [72.2, 171.0], [72.3, 171.0], [72.4, 171.0], [72.5, 171.0], [72.6, 171.0], [72.7, 171.0], [72.8, 171.0], [72.9, 171.0], [73.0, 171.0], [73.1, 171.0], [73.2, 171.0], [73.3, 171.0], [73.4, 171.0], [73.5, 171.0], [73.6, 173.0], [73.7, 173.0], [73.8, 173.0], [73.9, 173.0], [74.0, 173.0], [74.1, 173.0], [74.2, 173.0], [74.3, 173.0], [74.4, 173.0], [74.5, 173.0], [74.6, 174.0], [74.7, 174.0], [74.8, 174.0], [74.9, 174.0], [75.0, 174.0], [75.1, 174.0], [75.2, 174.0], [75.3, 174.0], [75.4, 174.0], [75.5, 174.0], [75.6, 174.0], [75.7, 174.0], [75.8, 174.0], [75.9, 174.0], [76.0, 174.0], [76.1, 174.0], [76.2, 174.0], [76.3, 174.0], [76.4, 174.0], [76.5, 177.0], [76.6, 177.0], [76.7, 177.0], [76.8, 177.0], [76.9, 177.0], [77.0, 177.0], [77.1, 177.0], [77.2, 177.0], [77.3, 177.0], [77.4, 180.0], [77.5, 180.0], [77.6, 180.0], [77.7, 180.0], [77.8, 180.0], [77.9, 180.0], [78.0, 180.0], [78.1, 180.0], [78.2, 180.0], [78.3, 180.0], [78.4, 180.0], [78.5, 180.0], [78.6, 180.0], [78.7, 180.0], [78.8, 180.0], [78.9, 180.0], [79.0, 180.0], [79.1, 180.0], [79.2, 180.0], [79.3, 181.0], [79.4, 181.0], [79.5, 181.0], [79.6, 181.0], [79.7, 181.0], [79.8, 181.0], [79.9, 181.0], [80.0, 181.0], [80.1, 181.0], [80.2, 184.0], [80.3, 184.0], [80.4, 184.0], [80.5, 184.0], [80.6, 184.0], [80.7, 184.0], [80.8, 184.0], [80.9, 184.0], [81.0, 184.0], [81.1, 184.0], [81.2, 185.0], [81.3, 185.0], [81.4, 185.0], [81.5, 185.0], [81.6, 185.0], [81.7, 185.0], [81.8, 185.0], [81.9, 185.0], [82.0, 185.0], [82.1, 194.0], [82.2, 194.0], [82.3, 194.0], [82.4, 194.0], [82.5, 194.0], [82.6, 194.0], [82.7, 194.0], [82.8, 194.0], [82.9, 194.0], [83.0, 194.0], [83.1, 195.0], [83.2, 195.0], [83.3, 195.0], [83.4, 195.0], [83.5, 195.0], [83.6, 195.0], [83.7, 195.0], [83.8, 195.0], [83.9, 195.0], [84.0, 231.0], [84.1, 231.0], [84.2, 231.0], [84.3, 231.0], [84.4, 231.0], [84.5, 231.0], [84.6, 231.0], [84.7, 231.0], [84.8, 231.0], [84.9, 231.0], [85.0, 248.0], [85.1, 248.0], [85.2, 248.0], [85.3, 248.0], [85.4, 248.0], [85.5, 248.0], [85.6, 248.0], [85.7, 248.0], [85.8, 248.0], [85.9, 255.0], [86.0, 255.0], [86.1, 255.0], [86.2, 255.0], [86.3, 255.0], [86.4, 255.0], [86.5, 255.0], [86.6, 255.0], [86.7, 255.0], [86.8, 259.0], [86.9, 259.0], [87.0, 259.0], [87.1, 259.0], [87.2, 259.0], [87.3, 259.0], [87.4, 259.0], [87.5, 259.0], [87.6, 259.0], [87.7, 259.0], [87.8, 506.0], [87.9, 506.0], [88.0, 506.0], [88.1, 506.0], [88.2, 506.0], [88.3, 506.0], [88.4, 506.0], [88.5, 506.0], [88.6, 506.0], [88.7, 521.0], [88.8, 521.0], [88.9, 521.0], [89.0, 521.0], [89.1, 521.0], [89.2, 521.0], [89.3, 521.0], [89.4, 521.0], [89.5, 521.0], [89.6, 521.0], [89.7, 524.0], [89.8, 524.0], [89.9, 524.0], [90.0, 524.0], [90.1, 524.0], [90.2, 524.0], [90.3, 524.0], [90.4, 524.0], [90.5, 524.0], [90.6, 553.0], [90.7, 553.0], [90.8, 553.0], [90.9, 553.0], [91.0, 553.0], [91.1, 553.0], [91.2, 553.0], [91.3, 553.0], [91.4, 553.0], [91.5, 553.0], [91.6, 579.0], [91.7, 579.0], [91.8, 579.0], [91.9, 579.0], [92.0, 579.0], [92.1, 579.0], [92.2, 579.0], [92.3, 579.0], [92.4, 579.0], [92.5, 600.0], [92.6, 600.0], [92.7, 600.0], [92.8, 600.0], [92.9, 600.0], [93.0, 600.0], [93.1, 600.0], [93.2, 600.0], [93.3, 600.0], [93.4, 655.0], [93.5, 655.0], [93.6, 655.0], [93.7, 655.0], [93.8, 655.0], [93.9, 655.0], [94.0, 655.0], [94.1, 655.0], [94.2, 655.0], [94.3, 655.0], [94.4, 659.0], [94.5, 659.0], [94.6, 659.0], [94.7, 659.0], [94.8, 659.0], [94.9, 659.0], [95.0, 659.0], [95.1, 659.0], [95.2, 659.0], [95.3, 838.0], [95.4, 838.0], [95.5, 838.0], [95.6, 838.0], [95.7, 838.0], [95.8, 838.0], [95.9, 838.0], [96.0, 838.0], [96.1, 838.0], [96.2, 838.0], [96.3, 952.0], [96.4, 952.0], [96.5, 952.0], [96.6, 952.0], [96.7, 952.0], [96.8, 952.0], [96.9, 952.0], [97.0, 952.0], [97.1, 952.0], [97.2, 954.0], [97.3, 954.0], [97.4, 954.0], [97.5, 954.0], [97.6, 954.0], [97.7, 954.0], [97.8, 954.0], [97.9, 954.0], [98.0, 954.0], [98.1, 954.0], [98.2, 1211.0], [98.3, 1211.0], [98.4, 1211.0], [98.5, 1211.0], [98.6, 1211.0], [98.7, 1211.0], [98.8, 1211.0], [98.9, 1211.0], [99.0, 1211.0], [99.1, 17475.0], [99.2, 17475.0], [99.3, 17475.0], [99.4, 17475.0], [99.5, 17475.0], [99.6, 17475.0], [99.7, 17475.0], [99.8, 17475.0], [99.9, 17475.0]], "isOverall": false, "label": "GET - List Orders Direct Azure", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 100.0, "maxY": 89.0, "series": [{"data": [[17400.0, 1.0], [1200.0, 1.0], [600.0, 3.0], [200.0, 4.0], [100.0, 89.0], [800.0, 1.0], [900.0, 2.0], [500.0, 5.0]], "isOverall": false, "label": "GET - List Orders Direct Azure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 17400.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 93.0, "series": [{"data": [[0.0, 93.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 12.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [[3.0, 1.0]], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 3.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 1.0, "minX": 1.792307375E12, "maxY": 1.0, "series": [{"data": [[1.79230743E12, 1.0], [1.792307515E12, 1.0], [1.79230739E12, 1.0], [1.792307475E12, 1.0], [1.79230752E12, 1.0], [1.79230751E12, 1.0], [1.792307425E12, 1.0], [1.79230747E12, 1.0], [1.792307385E12, 1.0], [1.79230742E12, 1.0], [1.792307505E12, 1.0], [1.79230738E12, 1.0], [1.792307465E12, 1.0], [1.7923075E12, 1.0], [1.792307415E12, 1.0], [1.79230746E12, 1.0], [1.792307375E12, 1.0], [1.792307495E12, 1.0], [1.792307455E12, 1.0], [1.79230749E12, 1.0], [1.79230745E12, 1.0], [1.792307485E12, 1.0], [1.792307445E12, 1.0], [1.792307435E12, 1.0], [1.79230748E12, 1.0], [1.792307395E12, 1.0], [1.79230744E12, 1.0]], "isOverall": false, "label": "Thread Group", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.79230752E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 385.867924528302, "minX": 1.0, "maxY": 385.867924528302, "series": [{"data": [[1.0, 385.867924528302]], "isOverall": false, "label": "GET - List Orders Direct Azure", "isController": false}, {"data": [[1.0, 385.867924528302]], "isOverall": false, "label": "GET - List Orders Direct Azure-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 1.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 313.2, "minX": 1.792307375E12, "maxY": 7338.0, "series": [{"data": [[1.79230743E12, 5870.4], [1.792307515E12, 7338.0], [1.79230739E12, 4402.8], [1.792307475E12, 4402.8], [1.79230752E12, 2935.2], [1.79230751E12, 5870.4], [1.792307425E12, 7338.0], [1.79230747E12, 5870.4], [1.792307385E12, 5870.4], [1.79230742E12, 5870.4], [1.792307505E12, 5870.4], [1.79230738E12, 5870.4], [1.792307465E12, 5870.4], [1.7923075E12, 5870.4], [1.792307415E12, 1975.4], [1.79230746E12, 7338.0], [1.792307375E12, 4402.8], [1.792307495E12, 5870.4], [1.792307455E12, 5870.4], [1.79230749E12, 5870.4], [1.79230745E12, 5870.4], [1.792307485E12, 5870.4], [1.792307445E12, 7338.0], [1.792307435E12, 5870.4], [1.79230748E12, 7338.0], [1.792307395E12, 5870.4], [1.79230744E12, 5870.4]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.79230743E12, 1252.8], [1.792307515E12, 1566.0], [1.79230739E12, 939.6], [1.792307475E12, 939.6], [1.79230752E12, 626.4], [1.79230751E12, 1252.8], [1.792307425E12, 1566.0], [1.79230747E12, 1252.8], [1.792307385E12, 1252.8], [1.79230742E12, 1252.8], [1.792307505E12, 1252.8], [1.79230738E12, 1252.8], [1.792307465E12, 1252.8], [1.7923075E12, 1252.8], [1.792307415E12, 313.2], [1.79230746E12, 1566.0], [1.792307375E12, 939.6], [1.792307495E12, 1252.8], [1.792307455E12, 1252.8], [1.79230749E12, 1252.8], [1.79230745E12, 1252.8], [1.792307485E12, 1252.8], [1.792307445E12, 1566.0], [1.792307435E12, 1252.8], [1.79230748E12, 1566.0], [1.792307395E12, 1252.8], [1.79230744E12, 1252.8]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.79230752E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 145.6, "minX": 1.792307375E12, "maxY": 9014.0, "series": [{"data": [[1.79230743E12, 161.25], [1.792307515E12, 162.2], [1.79230739E12, 406.66666666666663], [1.792307475E12, 157.0], [1.79230752E12, 168.0], [1.79230751E12, 168.75], [1.792307425E12, 157.4], [1.79230747E12, 280.25], [1.792307385E12, 368.25], [1.79230742E12, 264.75], [1.792307505E12, 260.75], [1.79230738E12, 179.5], [1.792307465E12, 248.5], [1.7923075E12, 188.25], [1.792307415E12, 9014.0], [1.79230746E12, 156.6], [1.792307375E12, 567.0], [1.792307495E12, 252.75], [1.792307455E12, 151.5], [1.79230749E12, 159.0], [1.79230745E12, 148.75], [1.792307485E12, 161.5], [1.792307445E12, 145.6], [1.792307435E12, 159.25], [1.79230748E12, 305.8], [1.792307395E12, 326.5], [1.79230744E12, 147.5]], "isOverall": false, "label": "GET - List Orders Direct Azure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.79230752E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 139.6, "minX": 1.792307375E12, "maxY": 496.66666666666663, "series": [{"data": [[1.79230743E12, 156.0], [1.792307515E12, 157.4], [1.79230739E12, 264.6666666666667], [1.792307475E12, 151.0], [1.79230752E12, 164.5], [1.79230751E12, 154.0], [1.792307425E12, 154.6], [1.79230747E12, 251.49999999999997], [1.792307385E12, 340.25], [1.79230742E12, 248.0], [1.792307505E12, 148.75], [1.79230738E12, 153.25], [1.792307465E12, 161.0], [1.7923075E12, 186.25], [1.792307415E12, 358.5], [1.79230746E12, 151.6], [1.792307375E12, 496.66666666666663], [1.792307495E12, 249.25], [1.792307455E12, 146.5], [1.79230749E12, 146.75], [1.79230745E12, 147.25], [1.792307485E12, 155.25], [1.792307445E12, 139.6], [1.792307435E12, 154.75], [1.79230748E12, 298.2], [1.792307395E12, 299.0], [1.79230744E12, 143.75]], "isOverall": false, "label": "GET - List Orders Direct Azure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.79230752E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 0.0, "minX": 1.792307375E12, "maxY": 196.5, "series": [{"data": [[1.79230743E12, 0.0], [1.792307515E12, 0.0], [1.79230739E12, 0.0], [1.792307475E12, 0.0], [1.79230752E12, 0.0], [1.79230751E12, 0.0], [1.792307425E12, 0.0], [1.79230747E12, 0.0], [1.792307385E12, 0.0], [1.79230742E12, 0.0], [1.792307505E12, 0.0], [1.79230738E12, 0.0], [1.792307465E12, 0.0], [1.7923075E12, 0.0], [1.792307415E12, 196.5], [1.79230746E12, 0.0], [1.792307375E12, 0.0], [1.792307495E12, 0.0], [1.792307455E12, 0.0], [1.79230749E12, 0.0], [1.79230745E12, 0.0], [1.792307485E12, 0.0], [1.792307445E12, 0.0], [1.792307435E12, 0.0], [1.79230748E12, 162.99999999999997], [1.792307395E12, 0.0], [1.79230744E12, 0.0]], "isOverall": false, "label": "GET - List Orders Direct Azure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.79230752E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 129.0, "minX": 1.792307375E12, "maxY": 1211.0, "series": [{"data": [[1.79230743E12, 169.0], [1.792307515E12, 185.0], [1.79230739E12, 952.0], [1.792307475E12, 163.0], [1.79230752E12, 181.0], [1.79230751E12, 194.0], [1.792307425E12, 180.0], [1.79230747E12, 655.0], [1.792307385E12, 659.0], [1.79230742E12, 600.0], [1.792307505E12, 579.0], [1.79230738E12, 255.0], [1.792307465E12, 506.0], [1.7923075E12, 248.0], [1.792307415E12, 553.0], [1.79230746E12, 168.0], [1.792307375E12, 1211.0], [1.792307495E12, 524.0], [1.792307455E12, 161.0], [1.79230749E12, 170.0], [1.79230745E12, 166.0], [1.792307485E12, 171.0], [1.792307445E12, 156.0], [1.792307435E12, 174.0], [1.79230748E12, 954.0], [1.792307395E12, 838.0], [1.79230744E12, 166.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.79230743E12, 146.0], [1.792307515E12, 138.0], [1.79230739E12, 133.0], [1.792307475E12, 154.0], [1.79230752E12, 155.0], [1.79230751E12, 155.0], [1.792307425E12, 137.0], [1.79230747E12, 145.0], [1.792307385E12, 142.0], [1.79230742E12, 141.0], [1.792307505E12, 145.0], [1.79230738E12, 142.0], [1.792307465E12, 152.0], [1.7923075E12, 146.0], [1.792307415E12, 553.0], [1.79230746E12, 140.0], [1.792307375E12, 231.0], [1.792307495E12, 147.0], [1.792307455E12, 138.0], [1.79230749E12, 146.0], [1.79230745E12, 133.0], [1.792307485E12, 142.0], [1.792307445E12, 132.0], [1.792307435E12, 146.0], [1.79230748E12, 134.0], [1.792307395E12, 146.0], [1.79230744E12, 129.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.79230743E12, 169.0], [1.792307515E12, 185.0], [1.79230739E12, 952.0], [1.792307475E12, 163.0], [1.79230752E12, 181.0], [1.79230751E12, 194.0], [1.792307425E12, 180.0], [1.79230747E12, 655.0], [1.792307385E12, 659.0], [1.79230742E12, 600.0], [1.792307505E12, 579.0], [1.79230738E12, 255.0], [1.792307465E12, 506.0], [1.7923075E12, 248.0], [1.792307415E12, 553.0], [1.79230746E12, 168.0], [1.792307375E12, 1211.0], [1.792307495E12, 524.0], [1.792307455E12, 161.0], [1.79230749E12, 170.0], [1.79230745E12, 166.0], [1.792307485E12, 171.0], [1.792307445E12, 156.0], [1.792307435E12, 174.0], [1.79230748E12, 954.0], [1.792307395E12, 838.0], [1.79230744E12, 166.0]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.79230743E12, 169.0], [1.792307515E12, 185.0], [1.79230739E12, 952.0], [1.792307475E12, 163.0], [1.79230752E12, 181.0], [1.79230751E12, 194.0], [1.792307425E12, 180.0], [1.79230747E12, 655.0], [1.792307385E12, 659.0], [1.79230742E12, 600.0], [1.792307505E12, 579.0], [1.79230738E12, 255.0], [1.792307465E12, 506.0], [1.7923075E12, 248.0], [1.792307415E12, 553.0], [1.79230746E12, 168.0], [1.792307375E12, 1211.0], [1.792307495E12, 524.0], [1.792307455E12, 161.0], [1.79230749E12, 170.0], [1.79230745E12, 166.0], [1.792307485E12, 171.0], [1.792307445E12, 156.0], [1.792307435E12, 174.0], [1.79230748E12, 954.0], [1.792307395E12, 838.0], [1.79230744E12, 166.0]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.79230743E12, 165.0], [1.792307515E12, 169.0], [1.79230739E12, 135.0], [1.792307475E12, 154.0], [1.79230752E12, 168.0], [1.79230751E12, 163.0], [1.792307425E12, 155.0], [1.79230747E12, 160.5], [1.792307385E12, 336.0], [1.79230742E12, 159.0], [1.792307505E12, 159.5], [1.79230738E12, 160.5], [1.792307465E12, 168.0], [1.7923075E12, 179.5], [1.792307415E12, 553.0], [1.79230746E12, 156.0], [1.792307375E12, 259.0], [1.792307495E12, 170.0], [1.792307455E12, 153.5], [1.79230749E12, 160.0], [1.79230745E12, 148.0], [1.792307485E12, 166.5], [1.792307445E12, 147.0], [1.792307435E12, 158.5], [1.79230748E12, 143.0], [1.792307395E12, 161.0], [1.79230744E12, 147.5]], "isOverall": false, "label": "Median", "isController": false}, {"data": [[1.79230743E12, 169.0], [1.792307515E12, 185.0], [1.79230739E12, 952.0], [1.792307475E12, 163.0], [1.79230752E12, 181.0], [1.79230751E12, 194.0], [1.792307425E12, 180.0], [1.79230747E12, 655.0], [1.792307385E12, 659.0], [1.79230742E12, 600.0], [1.792307505E12, 579.0], [1.79230738E12, 255.0], [1.792307465E12, 506.0], [1.7923075E12, 248.0], [1.792307415E12, 553.0], [1.79230746E12, 168.0], [1.792307375E12, 1211.0], [1.792307495E12, 524.0], [1.792307455E12, 161.0], [1.79230749E12, 170.0], [1.79230745E12, 166.0], [1.792307485E12, 171.0], [1.792307445E12, 156.0], [1.792307435E12, 174.0], [1.79230748E12, 954.0], [1.792307395E12, 838.0], [1.79230744E12, 166.0]], "isOverall": false, "label": "95th percentile", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.79230752E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 158.0, "minX": 1.0, "maxY": 17475.0, "series": [{"data": [[1.0, 158.0]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[1.0, 17475.0]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 152.0, "minX": 1.0, "maxY": 166.0, "series": [{"data": [[1.0, 152.0]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[1.0, 166.0]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 0.4, "minX": 1.792307375E12, "maxY": 1.0, "series": [{"data": [[1.79230743E12, 0.8], [1.792307515E12, 0.8], [1.79230739E12, 0.8], [1.792307475E12, 0.8], [1.79230752E12, 0.4], [1.79230751E12, 1.0], [1.792307425E12, 1.0], [1.79230747E12, 0.8], [1.792307385E12, 0.6], [1.79230742E12, 0.6], [1.792307505E12, 0.8], [1.79230738E12, 1.0], [1.792307465E12, 0.8], [1.7923075E12, 0.8], [1.792307415E12, 0.4], [1.79230746E12, 0.8], [1.792307375E12, 0.6], [1.792307495E12, 0.8], [1.792307455E12, 1.0], [1.79230749E12, 0.8], [1.79230745E12, 0.8], [1.792307485E12, 0.8], [1.792307445E12, 0.8], [1.792307435E12, 0.8], [1.79230748E12, 0.8], [1.792307395E12, 0.8], [1.79230744E12, 1.0]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.79230752E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 0.2, "minX": 1.792307375E12, "maxY": 1.0, "series": [{"data": [[1.79230743E12, 0.8], [1.792307515E12, 1.0], [1.79230739E12, 0.6], [1.792307475E12, 0.6], [1.79230752E12, 0.4], [1.79230751E12, 0.8], [1.792307425E12, 1.0], [1.79230747E12, 0.8], [1.792307385E12, 0.8], [1.79230742E12, 0.8], [1.792307505E12, 0.8], [1.79230738E12, 0.8], [1.792307465E12, 0.8], [1.7923075E12, 0.8], [1.792307415E12, 0.2], [1.79230746E12, 1.0], [1.792307375E12, 0.6], [1.792307495E12, 0.8], [1.792307455E12, 0.8], [1.79230749E12, 0.8], [1.79230745E12, 0.8], [1.792307485E12, 0.8], [1.792307445E12, 1.0], [1.792307435E12, 0.8], [1.79230748E12, 1.0], [1.792307395E12, 0.8], [1.79230744E12, 0.8]], "isOverall": false, "label": "200", "isController": false}, {"data": [[1.792307415E12, 0.2]], "isOverall": false, "label": "Non HTTP response code: java.net.SocketTimeoutException", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.79230752E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 0.2, "minX": 1.792307375E12, "maxY": 1.0, "series": [{"data": [[1.792307415E12, 0.2]], "isOverall": false, "label": "GET - List Orders Direct Azure-failure", "isController": false}, {"data": [[1.79230743E12, 0.8], [1.792307515E12, 1.0], [1.79230739E12, 0.6], [1.792307475E12, 0.6], [1.79230752E12, 0.4], [1.79230751E12, 0.8], [1.792307425E12, 1.0], [1.79230747E12, 0.8], [1.792307385E12, 0.8], [1.79230742E12, 0.8], [1.792307505E12, 0.8], [1.79230738E12, 0.8], [1.792307465E12, 0.8], [1.7923075E12, 0.8], [1.792307415E12, 0.2], [1.79230746E12, 1.0], [1.792307375E12, 0.6], [1.792307495E12, 0.8], [1.792307455E12, 0.8], [1.79230749E12, 0.8], [1.79230745E12, 0.8], [1.792307485E12, 0.8], [1.792307445E12, 1.0], [1.792307435E12, 0.8], [1.79230748E12, 1.0], [1.792307395E12, 0.8], [1.79230744E12, 0.8]], "isOverall": false, "label": "GET - List Orders Direct Azure-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.79230752E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 0.2, "minX": 1.792307375E12, "maxY": 1.0, "series": [{"data": [[1.79230743E12, 0.8], [1.792307515E12, 1.0], [1.79230739E12, 0.6], [1.792307475E12, 0.6], [1.79230752E12, 0.4], [1.79230751E12, 0.8], [1.792307425E12, 1.0], [1.79230747E12, 0.8], [1.792307385E12, 0.8], [1.79230742E12, 0.8], [1.792307505E12, 0.8], [1.79230738E12, 0.8], [1.792307465E12, 0.8], [1.7923075E12, 0.8], [1.792307415E12, 0.2], [1.79230746E12, 1.0], [1.792307375E12, 0.6], [1.792307495E12, 0.8], [1.792307455E12, 0.8], [1.79230749E12, 0.8], [1.79230745E12, 0.8], [1.792307485E12, 0.8], [1.792307445E12, 1.0], [1.792307435E12, 0.8], [1.79230748E12, 1.0], [1.792307395E12, 0.8], [1.79230744E12, 0.8]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [[1.792307415E12, 0.2]], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.79230752E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

