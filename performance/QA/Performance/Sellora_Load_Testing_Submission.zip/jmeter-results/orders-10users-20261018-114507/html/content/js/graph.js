/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 470.0, "minX": 0.0, "maxY": 15357.0, "series": [{"data": [[0.0, 470.0], [0.1, 470.0], [0.2, 470.0], [0.3, 470.0], [0.4, 473.0], [0.5, 473.0], [0.6, 473.0], [0.7, 473.0], [0.8, 475.0], [0.9, 475.0], [1.0, 475.0], [1.1, 475.0], [1.2, 475.0], [1.3, 475.0], [1.4, 475.0], [1.5, 475.0], [1.6, 476.0], [1.7, 476.0], [1.8, 476.0], [1.9, 476.0], [2.0, 478.0], [2.1, 478.0], [2.2, 478.0], [2.3, 478.0], [2.4, 480.0], [2.5, 480.0], [2.6, 480.0], [2.7, 480.0], [2.8, 480.0], [2.9, 480.0], [3.0, 480.0], [3.1, 480.0], [3.2, 481.0], [3.3, 481.0], [3.4, 481.0], [3.5, 481.0], [3.6, 484.0], [3.7, 484.0], [3.8, 484.0], [3.9, 484.0], [4.0, 484.0], [4.1, 484.0], [4.2, 484.0], [4.3, 486.0], [4.4, 486.0], [4.5, 486.0], [4.6, 486.0], [4.7, 486.0], [4.8, 486.0], [4.9, 486.0], [5.0, 486.0], [5.1, 486.0], [5.2, 486.0], [5.3, 486.0], [5.4, 486.0], [5.5, 489.0], [5.6, 489.0], [5.7, 489.0], [5.8, 489.0], [5.9, 490.0], [6.0, 490.0], [6.1, 490.0], [6.2, 490.0], [6.3, 490.0], [6.4, 490.0], [6.5, 490.0], [6.6, 490.0], [6.7, 491.0], [6.8, 491.0], [6.9, 491.0], [7.0, 491.0], [7.1, 492.0], [7.2, 492.0], [7.3, 492.0], [7.4, 494.0], [7.5, 494.0], [7.6, 494.0], [7.7, 494.0], [7.8, 494.0], [7.9, 494.0], [8.0, 494.0], [8.1, 494.0], [8.2, 496.0], [8.3, 496.0], [8.4, 496.0], [8.5, 496.0], [8.6, 497.0], [8.7, 497.0], [8.8, 497.0], [8.9, 497.0], [9.0, 498.0], [9.1, 498.0], [9.2, 498.0], [9.3, 498.0], [9.4, 498.0], [9.5, 498.0], [9.6, 498.0], [9.7, 498.0], [9.8, 498.0], [9.9, 498.0], [10.0, 498.0], [10.1, 498.0], [10.2, 499.0], [10.3, 499.0], [10.4, 499.0], [10.5, 499.0], [10.6, 499.0], [10.7, 499.0], [10.8, 499.0], [10.9, 500.0], [11.0, 500.0], [11.1, 500.0], [11.2, 500.0], [11.3, 500.0], [11.4, 500.0], [11.5, 500.0], [11.6, 500.0], [11.7, 501.0], [11.8, 501.0], [11.9, 501.0], [12.0, 501.0], [12.1, 501.0], [12.2, 501.0], [12.3, 501.0], [12.4, 501.0], [12.5, 502.0], [12.6, 502.0], [12.7, 502.0], [12.8, 502.0], [12.9, 504.0], [13.0, 504.0], [13.1, 504.0], [13.2, 504.0], [13.3, 505.0], [13.4, 505.0], [13.5, 505.0], [13.6, 505.0], [13.7, 505.0], [13.8, 505.0], [13.9, 505.0], [14.0, 505.0], [14.1, 507.0], [14.2, 507.0], [14.3, 507.0], [14.4, 509.0], [14.5, 509.0], [14.6, 509.0], [14.7, 509.0], [14.8, 510.0], [14.9, 510.0], [15.0, 510.0], [15.1, 510.0], [15.2, 512.0], [15.3, 512.0], [15.4, 512.0], [15.5, 512.0], [15.6, 513.0], [15.7, 513.0], [15.8, 513.0], [15.9, 513.0], [16.0, 513.0], [16.1, 513.0], [16.2, 513.0], [16.3, 513.0], [16.4, 514.0], [16.5, 514.0], [16.6, 514.0], [16.7, 514.0], [16.8, 514.0], [16.9, 514.0], [17.0, 514.0], [17.1, 514.0], [17.2, 515.0], [17.3, 515.0], [17.4, 515.0], [17.5, 515.0], [17.6, 515.0], [17.7, 515.0], [17.8, 515.0], [17.9, 516.0], [18.0, 516.0], [18.1, 516.0], [18.2, 516.0], [18.3, 516.0], [18.4, 516.0], [18.5, 516.0], [18.6, 516.0], [18.7, 516.0], [18.8, 516.0], [18.9, 516.0], [19.0, 516.0], [19.1, 517.0], [19.2, 517.0], [19.3, 517.0], [19.4, 517.0], [19.5, 523.0], [19.6, 523.0], [19.7, 523.0], [19.8, 523.0], [19.9, 524.0], [20.0, 524.0], [20.1, 524.0], [20.2, 524.0], [20.3, 524.0], [20.4, 524.0], [20.5, 524.0], [20.6, 524.0], [20.7, 527.0], [20.8, 527.0], [20.9, 527.0], [21.0, 527.0], [21.1, 527.0], [21.2, 527.0], [21.3, 527.0], [21.4, 527.0], [21.5, 527.0], [21.6, 527.0], [21.7, 527.0], [21.8, 528.0], [21.9, 528.0], [22.0, 528.0], [22.1, 528.0], [22.2, 528.0], [22.3, 528.0], [22.4, 528.0], [22.5, 528.0], [22.6, 529.0], [22.7, 529.0], [22.8, 529.0], [22.9, 529.0], [23.0, 532.0], [23.1, 532.0], [23.2, 532.0], [23.3, 532.0], [23.4, 533.0], [23.5, 533.0], [23.6, 533.0], [23.7, 533.0], [23.8, 533.0], [23.9, 533.0], [24.0, 533.0], [24.1, 533.0], [24.2, 535.0], [24.3, 535.0], [24.4, 535.0], [24.5, 535.0], [24.6, 544.0], [24.7, 544.0], [24.8, 544.0], [24.9, 544.0], [25.0, 550.0], [25.1, 550.0], [25.2, 550.0], [25.3, 550.0], [25.4, 550.0], [25.5, 550.0], [25.6, 550.0], [25.7, 553.0], [25.8, 553.0], [25.9, 553.0], [26.0, 553.0], [26.1, 564.0], [26.2, 564.0], [26.3, 564.0], [26.4, 564.0], [26.5, 564.0], [26.6, 564.0], [26.7, 564.0], [26.8, 564.0], [26.9, 566.0], [27.0, 566.0], [27.1, 566.0], [27.2, 566.0], [27.3, 566.0], [27.4, 566.0], [27.5, 566.0], [27.6, 566.0], [27.7, 567.0], [27.8, 567.0], [27.9, 567.0], [28.0, 567.0], [28.1, 568.0], [28.2, 568.0], [28.3, 568.0], [28.4, 568.0], [28.5, 570.0], [28.6, 570.0], [28.7, 570.0], [28.8, 571.0], [28.9, 571.0], [29.0, 571.0], [29.1, 571.0], [29.2, 587.0], [29.3, 587.0], [29.4, 587.0], [29.5, 587.0], [29.6, 591.0], [29.7, 591.0], [29.8, 591.0], [29.9, 591.0], [30.0, 607.0], [30.1, 607.0], [30.2, 607.0], [30.3, 607.0], [30.4, 612.0], [30.5, 612.0], [30.6, 612.0], [30.7, 612.0], [30.8, 612.0], [30.9, 612.0], [31.0, 612.0], [31.1, 612.0], [31.2, 618.0], [31.3, 618.0], [31.4, 618.0], [31.5, 618.0], [31.6, 622.0], [31.7, 622.0], [31.8, 622.0], [31.9, 622.0], [32.0, 622.0], [32.1, 622.0], [32.2, 622.0], [32.3, 629.0], [32.4, 629.0], [32.5, 629.0], [32.6, 629.0], [32.7, 636.0], [32.8, 636.0], [32.9, 636.0], [33.0, 636.0], [33.1, 654.0], [33.2, 654.0], [33.3, 654.0], [33.4, 654.0], [33.5, 658.0], [33.6, 658.0], [33.7, 658.0], [33.8, 658.0], [33.9, 661.0], [34.0, 661.0], [34.1, 661.0], [34.2, 661.0], [34.3, 670.0], [34.4, 670.0], [34.5, 670.0], [34.6, 670.0], [34.7, 672.0], [34.8, 672.0], [34.9, 672.0], [35.0, 672.0], [35.1, 674.0], [35.2, 674.0], [35.3, 674.0], [35.4, 674.0], [35.5, 674.0], [35.6, 674.0], [35.7, 674.0], [35.8, 675.0], [35.9, 675.0], [36.0, 675.0], [36.1, 675.0], [36.2, 676.0], [36.3, 676.0], [36.4, 676.0], [36.5, 676.0], [36.6, 677.0], [36.7, 677.0], [36.8, 677.0], [36.9, 677.0], [37.0, 678.0], [37.1, 678.0], [37.2, 678.0], [37.3, 678.0], [37.4, 679.0], [37.5, 679.0], [37.6, 679.0], [37.7, 679.0], [37.8, 679.0], [37.9, 679.0], [38.0, 679.0], [38.1, 679.0], [38.2, 681.0], [38.3, 681.0], [38.4, 681.0], [38.5, 681.0], [38.6, 681.0], [38.7, 681.0], [38.8, 681.0], [38.9, 681.0], [39.0, 682.0], [39.1, 682.0], [39.2, 682.0], [39.3, 682.0], [39.4, 682.0], [39.5, 682.0], [39.6, 682.0], [39.7, 683.0], [39.8, 683.0], [39.9, 683.0], [40.0, 683.0], [40.1, 687.0], [40.2, 687.0], [40.3, 687.0], [40.4, 687.0], [40.5, 687.0], [40.6, 687.0], [40.7, 687.0], [40.8, 687.0], [40.9, 687.0], [41.0, 687.0], [41.1, 687.0], [41.2, 687.0], [41.3, 688.0], [41.4, 688.0], [41.5, 688.0], [41.6, 688.0], [41.7, 689.0], [41.8, 689.0], [41.9, 689.0], [42.0, 689.0], [42.1, 689.0], [42.2, 689.0], [42.3, 689.0], [42.4, 689.0], [42.5, 689.0], [42.6, 689.0], [42.7, 689.0], [42.8, 689.0], [42.9, 690.0], [43.0, 690.0], [43.1, 690.0], [43.2, 691.0], [43.3, 691.0], [43.4, 691.0], [43.5, 691.0], [43.6, 691.0], [43.7, 691.0], [43.8, 691.0], [43.9, 691.0], [44.0, 693.0], [44.1, 693.0], [44.2, 693.0], [44.3, 693.0], [44.4, 697.0], [44.5, 697.0], [44.6, 697.0], [44.7, 697.0], [44.8, 697.0], [44.9, 697.0], [45.0, 697.0], [45.1, 697.0], [45.2, 697.0], [45.3, 697.0], [45.4, 697.0], [45.5, 697.0], [45.6, 697.0], [45.7, 697.0], [45.8, 697.0], [45.9, 697.0], [46.0, 700.0], [46.1, 700.0], [46.2, 700.0], [46.3, 700.0], [46.4, 700.0], [46.5, 700.0], [46.6, 700.0], [46.7, 700.0], [46.8, 700.0], [46.9, 700.0], [47.0, 700.0], [47.1, 704.0], [47.2, 704.0], [47.3, 704.0], [47.4, 704.0], [47.5, 704.0], [47.6, 704.0], [47.7, 704.0], [47.8, 704.0], [47.9, 705.0], [48.0, 705.0], [48.1, 705.0], [48.2, 705.0], [48.3, 705.0], [48.4, 705.0], [48.5, 705.0], [48.6, 705.0], [48.7, 708.0], [48.8, 708.0], [48.9, 708.0], [49.0, 708.0], [49.1, 708.0], [49.2, 708.0], [49.3, 708.0], [49.4, 708.0], [49.5, 708.0], [49.6, 708.0], [49.7, 708.0], [49.8, 708.0], [49.9, 709.0], [50.0, 709.0], [50.1, 709.0], [50.2, 710.0], [50.3, 710.0], [50.4, 710.0], [50.5, 710.0], [50.6, 710.0], [50.7, 710.0], [50.8, 710.0], [50.9, 710.0], [51.0, 710.0], [51.1, 710.0], [51.2, 710.0], [51.3, 710.0], [51.4, 713.0], [51.5, 713.0], [51.6, 713.0], [51.7, 713.0], [51.8, 713.0], [51.9, 713.0], [52.0, 713.0], [52.1, 713.0], [52.2, 714.0], [52.3, 714.0], [52.4, 714.0], [52.5, 714.0], [52.6, 714.0], [52.7, 714.0], [52.8, 714.0], [52.9, 714.0], [53.0, 715.0], [53.1, 715.0], [53.2, 715.0], [53.3, 715.0], [53.4, 717.0], [53.5, 717.0], [53.6, 717.0], [53.7, 717.0], [53.8, 717.0], [53.9, 717.0], [54.0, 717.0], [54.1, 717.0], [54.2, 717.0], [54.3, 717.0], [54.4, 717.0], [54.5, 718.0], [54.6, 718.0], [54.7, 718.0], [54.8, 718.0], [54.9, 721.0], [55.0, 721.0], [55.1, 721.0], [55.2, 721.0], [55.3, 724.0], [55.4, 724.0], [55.5, 724.0], [55.6, 724.0], [55.7, 725.0], [55.8, 725.0], [55.9, 725.0], [56.0, 725.0], [56.1, 725.0], [56.2, 725.0], [56.3, 725.0], [56.4, 725.0], [56.5, 725.0], [56.6, 725.0], [56.7, 725.0], [56.8, 725.0], [56.9, 725.0], [57.0, 725.0], [57.1, 725.0], [57.2, 726.0], [57.3, 726.0], [57.4, 726.0], [57.5, 726.0], [57.6, 728.0], [57.7, 728.0], [57.8, 728.0], [57.9, 728.0], [58.0, 729.0], [58.1, 729.0], [58.2, 729.0], [58.3, 729.0], [58.4, 734.0], [58.5, 734.0], [58.6, 734.0], [58.7, 734.0], [58.8, 735.0], [58.9, 735.0], [59.0, 735.0], [59.1, 735.0], [59.2, 738.0], [59.3, 738.0], [59.4, 738.0], [59.5, 738.0], [59.6, 747.0], [59.7, 747.0], [59.8, 747.0], [59.9, 747.0], [60.0, 749.0], [60.1, 749.0], [60.2, 749.0], [60.3, 749.0], [60.4, 751.0], [60.5, 751.0], [60.6, 751.0], [60.7, 751.0], [60.8, 752.0], [60.9, 752.0], [61.0, 752.0], [61.1, 752.0], [61.2, 752.0], [61.3, 752.0], [61.4, 752.0], [61.5, 763.0], [61.6, 763.0], [61.7, 763.0], [61.8, 763.0], [61.9, 764.0], [62.0, 764.0], [62.1, 764.0], [62.2, 764.0], [62.3, 765.0], [62.4, 765.0], [62.5, 765.0], [62.6, 765.0], [62.7, 781.0], [62.8, 781.0], [62.9, 781.0], [63.0, 781.0], [63.1, 809.0], [63.2, 809.0], [63.3, 809.0], [63.4, 809.0], [63.5, 815.0], [63.6, 815.0], [63.7, 815.0], [63.8, 815.0], [63.9, 832.0], [64.0, 832.0], [64.1, 832.0], [64.2, 832.0], [64.3, 842.0], [64.4, 842.0], [64.5, 842.0], [64.6, 866.0], [64.7, 866.0], [64.8, 866.0], [64.9, 866.0], [65.0, 882.0], [65.1, 882.0], [65.2, 882.0], [65.3, 882.0], [65.4, 889.0], [65.5, 889.0], [65.6, 889.0], [65.7, 889.0], [65.8, 889.0], [65.9, 889.0], [66.0, 889.0], [66.1, 889.0], [66.2, 894.0], [66.3, 894.0], [66.4, 894.0], [66.5, 894.0], [66.6, 898.0], [66.7, 898.0], [66.8, 898.0], [66.9, 898.0], [67.0, 905.0], [67.1, 905.0], [67.2, 905.0], [67.3, 905.0], [67.4, 915.0], [67.5, 915.0], [67.6, 915.0], [67.7, 915.0], [67.8, 927.0], [67.9, 927.0], [68.0, 927.0], [68.1, 929.0], [68.2, 929.0], [68.3, 929.0], [68.4, 929.0], [68.5, 932.0], [68.6, 932.0], [68.7, 932.0], [68.8, 932.0], [68.9, 939.0], [69.0, 939.0], [69.1, 939.0], [69.2, 939.0], [69.3, 940.0], [69.4, 940.0], [69.5, 940.0], [69.6, 940.0], [69.7, 945.0], [69.8, 945.0], [69.9, 945.0], [70.0, 945.0], [70.1, 949.0], [70.2, 949.0], [70.3, 949.0], [70.4, 949.0], [70.5, 977.0], [70.6, 977.0], [70.7, 977.0], [70.8, 977.0], [70.9, 978.0], [71.0, 978.0], [71.1, 978.0], [71.2, 978.0], [71.3, 993.0], [71.4, 993.0], [71.5, 993.0], [71.6, 1008.0], [71.7, 1008.0], [71.8, 1008.0], [71.9, 1008.0], [72.0, 1025.0], [72.1, 1025.0], [72.2, 1025.0], [72.3, 1025.0], [72.4, 1042.0], [72.5, 1042.0], [72.6, 1042.0], [72.7, 1042.0], [72.8, 1094.0], [72.9, 1094.0], [73.0, 1094.0], [73.1, 1094.0], [73.2, 1101.0], [73.3, 1101.0], [73.4, 1101.0], [73.5, 1101.0], [73.6, 1134.0], [73.7, 1134.0], [73.8, 1134.0], [73.9, 1134.0], [74.0, 1138.0], [74.1, 1138.0], [74.2, 1138.0], [74.3, 1138.0], [74.4, 1147.0], [74.5, 1147.0], [74.6, 1147.0], [74.7, 1147.0], [74.8, 1212.0], [74.9, 1212.0], [75.0, 1212.0], [75.1, 1254.0], [75.2, 1254.0], [75.3, 1254.0], [75.4, 1254.0], [75.5, 1304.0], [75.6, 1304.0], [75.7, 1304.0], [75.8, 1304.0], [75.9, 1342.0], [76.0, 1342.0], [76.1, 1342.0], [76.2, 1342.0], [76.3, 1398.0], [76.4, 1398.0], [76.5, 1398.0], [76.6, 1398.0], [76.7, 1471.0], [76.8, 1471.0], [76.9, 1471.0], [77.0, 1471.0], [77.1, 1474.0], [77.2, 1474.0], [77.3, 1474.0], [77.4, 1474.0], [77.5, 1523.0], [77.6, 1523.0], [77.7, 1523.0], [77.8, 1523.0], [77.9, 1589.0], [78.0, 1589.0], [78.1, 1589.0], [78.2, 1589.0], [78.3, 1598.0], [78.4, 1598.0], [78.5, 1598.0], [78.6, 1631.0], [78.7, 1631.0], [78.8, 1631.0], [78.9, 1631.0], [79.0, 1655.0], [79.1, 1655.0], [79.2, 1655.0], [79.3, 1655.0], [79.4, 1696.0], [79.5, 1696.0], [79.6, 1696.0], [79.7, 1696.0], [79.8, 1706.0], [79.9, 1706.0], [80.0, 1706.0], [80.1, 1706.0], [80.2, 1759.0], [80.3, 1759.0], [80.4, 1759.0], [80.5, 1759.0], [80.6, 1808.0], [80.7, 1808.0], [80.8, 1808.0], [80.9, 1808.0], [81.0, 1841.0], [81.1, 1841.0], [81.2, 1841.0], [81.3, 1841.0], [81.4, 1872.0], [81.5, 1872.0], [81.6, 1872.0], [81.7, 1872.0], [81.8, 1873.0], [81.9, 1873.0], [82.0, 1873.0], [82.1, 1873.0], [82.2, 1891.0], [82.3, 1891.0], [82.4, 1891.0], [82.5, 1924.0], [82.6, 1924.0], [82.7, 1924.0], [82.8, 1924.0], [82.9, 1967.0], [83.0, 1967.0], [83.1, 1967.0], [83.2, 1967.0], [83.3, 1978.0], [83.4, 1978.0], [83.5, 1978.0], [83.6, 1978.0], [83.7, 2010.0], [83.8, 2010.0], [83.9, 2010.0], [84.0, 2010.0], [84.1, 2032.0], [84.2, 2032.0], [84.3, 2032.0], [84.4, 2032.0], [84.5, 2034.0], [84.6, 2034.0], [84.7, 2034.0], [84.8, 2034.0], [84.9, 2042.0], [85.0, 2042.0], [85.1, 2042.0], [85.2, 2042.0], [85.3, 2045.0], [85.4, 2045.0], [85.5, 2045.0], [85.6, 2045.0], [85.7, 2047.0], [85.8, 2047.0], [85.9, 2047.0], [86.0, 2113.0], [86.1, 2113.0], [86.2, 2113.0], [86.3, 2113.0], [86.4, 2137.0], [86.5, 2137.0], [86.6, 2137.0], [86.7, 2137.0], [86.8, 2144.0], [86.9, 2144.0], [87.0, 2144.0], [87.1, 2144.0], [87.2, 2152.0], [87.3, 2152.0], [87.4, 2152.0], [87.5, 2152.0], [87.6, 2156.0], [87.7, 2156.0], [87.8, 2156.0], [87.9, 2156.0], [88.0, 2166.0], [88.1, 2166.0], [88.2, 2166.0], [88.3, 2166.0], [88.4, 2189.0], [88.5, 2189.0], [88.6, 2189.0], [88.7, 2189.0], [88.8, 2207.0], [88.9, 2207.0], [89.0, 2207.0], [89.1, 2207.0], [89.2, 2229.0], [89.3, 2229.0], [89.4, 2229.0], [89.5, 2302.0], [89.6, 2302.0], [89.7, 2302.0], [89.8, 2302.0], [89.9, 2363.0], [90.0, 2363.0], [90.1, 2363.0], [90.2, 2363.0], [90.3, 2420.0], [90.4, 2420.0], [90.5, 2420.0], [90.6, 2420.0], [90.7, 2430.0], [90.8, 2430.0], [90.9, 2430.0], [91.0, 2430.0], [91.1, 2441.0], [91.2, 2441.0], [91.3, 2441.0], [91.4, 2441.0], [91.5, 2447.0], [91.6, 2447.0], [91.7, 2447.0], [91.8, 2447.0], [91.9, 2480.0], [92.0, 2480.0], [92.1, 2480.0], [92.2, 2480.0], [92.3, 2592.0], [92.4, 2592.0], [92.5, 2592.0], [92.6, 2592.0], [92.7, 2822.0], [92.8, 2822.0], [92.9, 2822.0], [93.0, 2856.0], [93.1, 2856.0], [93.2, 2856.0], [93.3, 2856.0], [93.4, 3123.0], [93.5, 3123.0], [93.6, 3123.0], [93.7, 3123.0], [93.8, 3216.0], [93.9, 3216.0], [94.0, 3216.0], [94.1, 3216.0], [94.2, 3229.0], [94.3, 3229.0], [94.4, 3229.0], [94.5, 3229.0], [94.6, 3321.0], [94.7, 3321.0], [94.8, 3321.0], [94.9, 3321.0], [95.0, 3525.0], [95.1, 3525.0], [95.2, 3525.0], [95.3, 3525.0], [95.4, 3906.0], [95.5, 3906.0], [95.6, 3906.0], [95.7, 3906.0], [95.8, 3993.0], [95.9, 3993.0], [96.0, 3993.0], [96.1, 3993.0], [96.2, 4471.0], [96.3, 4471.0], [96.4, 4471.0], [96.5, 4599.0], [96.6, 4599.0], [96.7, 4599.0], [96.8, 4599.0], [96.9, 5312.0], [97.0, 5312.0], [97.1, 5312.0], [97.2, 5312.0], [97.3, 5529.0], [97.4, 5529.0], [97.5, 5529.0], [97.6, 5529.0], [97.7, 6786.0], [97.8, 6786.0], [97.9, 6786.0], [98.0, 6786.0], [98.1, 7024.0], [98.2, 7024.0], [98.3, 7024.0], [98.4, 7024.0], [98.5, 7363.0], [98.6, 7363.0], [98.7, 7363.0], [98.8, 7363.0], [98.9, 11672.0], [99.0, 11672.0], [99.1, 11672.0], [99.2, 11672.0], [99.3, 14935.0], [99.4, 14935.0], [99.5, 14935.0], [99.6, 14935.0], [99.7, 15357.0], [99.8, 15357.0], [99.9, 15357.0]], "isOverall": false, "label": "GET - List Orders", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 400.0, "maxY": 49.0, "series": [{"data": [[600.0, 41.0], [700.0, 44.0], [11600.0, 1.0], [800.0, 10.0], [900.0, 12.0], [14900.0, 1.0], [15300.0, 1.0], [1000.0, 4.0], [1100.0, 4.0], [1200.0, 2.0], [1300.0, 3.0], [1400.0, 2.0], [1500.0, 3.0], [1600.0, 3.0], [1700.0, 2.0], [1800.0, 5.0], [1900.0, 3.0], [2000.0, 6.0], [2100.0, 7.0], [2200.0, 2.0], [2300.0, 2.0], [2400.0, 5.0], [2500.0, 1.0], [2800.0, 2.0], [3100.0, 1.0], [3300.0, 1.0], [3200.0, 2.0], [3500.0, 1.0], [3900.0, 2.0], [4500.0, 1.0], [4400.0, 1.0], [5300.0, 1.0], [5500.0, 1.0], [400.0, 28.0], [6700.0, 1.0], [7000.0, 1.0], [7300.0, 1.0], [500.0, 49.0]], "isOverall": false, "label": "GET - List Orders", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 15300.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 30.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 169.0, "series": [{"data": [[0.0, 30.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 169.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [[2.0, 58.0]], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 2.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 1.0, "minX": 1.79230411E12, "maxY": 10.0, "series": [{"data": [[1.79230417E12, 2.0], [1.792304125E12, 10.0], [1.792304145E12, 10.0], [1.792304165E12, 9.19047619047619], [1.79230412E12, 10.0], [1.79230414E12, 10.0], [1.79230416E12, 10.0], [1.792304115E12, 10.0], [1.792304135E12, 10.0], [1.792304155E12, 10.0], [1.792304175E12, 1.0], [1.79230411E12, 10.0], [1.79230413E12, 10.0], [1.79230415E12, 10.0]], "isOverall": false, "label": "Thread Group", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.792304175E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 1235.3055555555559, "minX": 1.0, "maxY": 7363.0, "series": [{"data": [[2.0, 5312.0], [1.0, 7363.0], [10.0, 1235.3055555555559], [5.0, 1727.5], [3.0, 2156.0]], "isOverall": false, "label": "GET - List Orders", "isController": false}, {"data": [[9.867704280155642, 1282.4241245136188]], "isOverall": false, "label": "GET - List Orders-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 10.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 307.2, "minX": 1.79230411E12, "maxY": 44527.2, "series": [{"data": [[1.79230417E12, 1484.2], [1.792304125E12, 35622.2], [1.792304145E12, 44527.2], [1.792304165E12, 31168.2], [1.79230412E12, 29684.0], [1.79230414E12, 25231.4], [1.79230416E12, 41557.6], [1.792304115E12, 26716.8], [1.792304135E12, 19294.6], [1.792304155E12, 43041.8], [1.792304175E12, 1484.2], [1.79230411E12, 1484.2], [1.79230413E12, 35620.8], [1.79230415E12, 44526.0]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.79230417E12, 307.2], [1.792304125E12, 7372.8], [1.792304145E12, 9216.0], [1.792304165E12, 6451.2], [1.79230412E12, 6144.0], [1.79230414E12, 5222.4], [1.79230416E12, 8601.6], [1.792304115E12, 5529.6], [1.792304135E12, 3993.6], [1.792304155E12, 8908.8], [1.792304175E12, 307.2], [1.79230411E12, 307.2], [1.79230413E12, 7372.8], [1.79230415E12, 9216.0]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.792304175E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 629.9333333333332, "minX": 1.79230411E12, "maxY": 7363.0, "series": [{"data": [[1.79230417E12, 5312.0], [1.792304125E12, 1780.208333333333], [1.792304145E12, 1430.8], [1.792304165E12, 1361.666666666667], [1.79230412E12, 1273.1999999999998], [1.79230414E12, 1786.235294117647], [1.79230416E12, 847.8214285714286], [1.792304115E12, 2214.6666666666665], [1.792304135E12, 1412.076923076923], [1.792304155E12, 630.4482758620691], [1.792304175E12, 7363.0], [1.79230411E12, 2137.0], [1.79230413E12, 1064.8333333333333], [1.79230415E12, 629.9333333333332]], "isOverall": false, "label": "GET - List Orders", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.792304175E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 622.1724137931034, "minX": 1.79230411E12, "maxY": 7363.0, "series": [{"data": [[1.79230417E12, 5311.0], [1.792304125E12, 1780.125], [1.792304145E12, 1423.6999999999998], [1.792304165E12, 1361.5714285714284], [1.79230412E12, 1273.0000000000002], [1.79230414E12, 1786.235294117647], [1.79230416E12, 847.7142857142857], [1.792304115E12, 2214.6111111111113], [1.792304135E12, 1394.5384615384614], [1.792304155E12, 622.1724137931034], [1.792304175E12, 7363.0], [1.79230411E12, 2134.0], [1.79230413E12, 1064.6666666666665], [1.79230415E12, 629.9]], "isOverall": false, "label": "GET - List Orders", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.792304175E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 0.0, "minX": 1.79230411E12, "maxY": 1460.0, "series": [{"data": [[1.79230417E12, 0.0], [1.792304125E12, 577.125], [1.792304145E12, 0.0], [1.792304165E12, 0.0], [1.79230412E12, 0.0], [1.79230414E12, 0.0], [1.79230416E12, 0.0], [1.792304115E12, 1172.6666666666665], [1.792304135E12, 0.0], [1.792304155E12, 0.0], [1.792304175E12, 0.0], [1.79230411E12, 1460.0], [1.79230413E12, 0.0], [1.79230415E12, 0.0]], "isOverall": false, "label": "GET - List Orders", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.792304175E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 470.0, "minX": 1.79230411E12, "maxY": 15357.0, "series": [{"data": [[1.79230417E12, 5312.0], [1.792304125E12, 14935.0], [1.792304145E12, 15357.0], [1.792304165E12, 2302.0], [1.79230412E12, 3321.0], [1.79230414E12, 5529.0], [1.79230416E12, 2480.0], [1.792304115E12, 7024.0], [1.792304135E12, 2152.0], [1.792304155E12, 1706.0], [1.792304175E12, 7363.0], [1.79230411E12, 2137.0], [1.79230413E12, 3906.0], [1.79230415E12, 725.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.79230417E12, 5312.0], [1.792304125E12, 486.0], [1.792304145E12, 490.0], [1.792304165E12, 484.0], [1.79230412E12, 494.0], [1.79230414E12, 689.0], [1.79230416E12, 484.0], [1.792304115E12, 490.0], [1.792304135E12, 763.0], [1.792304155E12, 470.0], [1.792304175E12, 7363.0], [1.79230411E12, 2137.0], [1.79230413E12, 497.0], [1.79230415E12, 475.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.79230417E12, 5312.0], [1.792304125E12, 6857.0], [1.792304145E12, 1912.4000000000003], [1.792304165E12, 2214.4], [1.79230412E12, 3218.4], [1.79230414E12, 4682.599999999999], [1.79230416E12, 2421.0], [1.792304115E12, 6809.8], [1.792304135E12, 2148.8], [1.792304155E12, 815.0], [1.792304175E12, 7363.0], [1.79230411E12, 2137.0], [1.79230413E12, 3036.0], [1.79230415E12, 717.0]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.79230417E12, 5312.0], [1.792304125E12, 14935.0], [1.792304145E12, 15357.0], [1.792304165E12, 2302.0], [1.79230412E12, 3321.0], [1.79230414E12, 5529.0], [1.79230416E12, 2480.0], [1.792304115E12, 7024.0], [1.792304135E12, 2152.0], [1.792304155E12, 1706.0], [1.792304175E12, 7363.0], [1.79230411E12, 2137.0], [1.79230413E12, 3906.0], [1.79230415E12, 725.0]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.79230417E12, 5312.0], [1.792304125E12, 639.5], [1.792304145E12, 807.5], [1.792304165E12, 1474.0], [1.79230412E12, 731.0], [1.79230414E12, 1398.0], [1.79230416E12, 528.0], [1.792304115E12, 957.5], [1.792304135E12, 1101.0], [1.792304155E12, 527.0], [1.792304175E12, 7363.0], [1.79230411E12, 2137.0], [1.79230413E12, 714.5], [1.79230415E12, 687.5]], "isOverall": false, "label": "Median", "isController": false}, {"data": [[1.79230417E12, 5312.0], [1.792304125E12, 14119.25], [1.792304145E12, 8256.49999999999], [1.792304165E12, 2294.7], [1.79230412E12, 3316.4], [1.79230414E12, 5529.0], [1.79230416E12, 2457.5], [1.792304115E12, 7024.0], [1.792304135E12, 2152.0], [1.792304155E12, 1349.5], [1.792304175E12, 7363.0], [1.79230411E12, 2137.0], [1.79230413E12, 3733.5], [1.79230415E12, 721.15]], "isOverall": false, "label": "95th percentile", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.792304175E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 557.0, "minX": 1.0, "maxY": 1631.0, "series": [{"data": [[1.0, 1631.0], [2.0, 664.5], [4.0, 702.5], [8.0, 1000.5], [9.0, 852.0], [5.0, 725.0], [10.0, 688.5], [3.0, 882.0], [6.0, 682.5], [7.0, 557.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 10.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 538.5, "minX": 1.0, "maxY": 1630.0, "series": [{"data": [[1.0, 1630.0], [2.0, 664.5], [4.0, 700.0], [8.0, 1000.5], [9.0, 777.5], [5.0, 725.0], [10.0, 688.5], [3.0, 882.0], [6.0, 682.5], [7.0, 538.5]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 10.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 2.2, "minX": 1.79230411E12, "maxY": 6.4, "series": [{"data": [[1.79230416E12, 5.4], [1.792304115E12, 3.0], [1.792304125E12, 4.6], [1.792304135E12, 3.6], [1.792304145E12, 4.8], [1.792304155E12, 6.4], [1.792304165E12, 3.4], [1.79230411E12, 2.2], [1.79230412E12, 3.4], [1.79230413E12, 5.0], [1.79230414E12, 3.6], [1.79230415E12, 6.0]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.792304165E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 0.2, "minX": 1.79230411E12, "maxY": 6.0, "series": [{"data": [[1.79230417E12, 0.2], [1.792304125E12, 4.8], [1.792304145E12, 6.0], [1.792304165E12, 4.2], [1.79230412E12, 4.0], [1.79230414E12, 3.4], [1.79230416E12, 5.6], [1.792304115E12, 3.6], [1.792304135E12, 2.6], [1.792304155E12, 5.8], [1.792304175E12, 0.2], [1.79230411E12, 0.2], [1.79230413E12, 4.8], [1.79230415E12, 6.0]], "isOverall": false, "label": "200", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.792304175E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 0.2, "minX": 1.79230411E12, "maxY": 6.0, "series": [{"data": [[1.79230417E12, 0.2], [1.792304125E12, 4.8], [1.792304145E12, 6.0], [1.792304165E12, 4.2], [1.79230412E12, 4.0], [1.79230414E12, 3.4], [1.79230416E12, 5.6], [1.792304115E12, 3.6], [1.792304135E12, 2.6], [1.792304155E12, 5.8], [1.792304175E12, 0.2], [1.79230411E12, 0.2], [1.79230413E12, 4.8], [1.79230415E12, 6.0]], "isOverall": false, "label": "GET - List Orders-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.792304175E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 0.2, "minX": 1.79230411E12, "maxY": 6.0, "series": [{"data": [[1.79230417E12, 0.2], [1.792304125E12, 4.8], [1.792304145E12, 6.0], [1.792304165E12, 4.2], [1.79230412E12, 4.0], [1.79230414E12, 3.4], [1.79230416E12, 5.6], [1.792304115E12, 3.6], [1.792304135E12, 2.6], [1.792304155E12, 5.8], [1.792304175E12, 0.2], [1.79230411E12, 0.2], [1.79230413E12, 4.8], [1.79230415E12, 6.0]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.792304175E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

