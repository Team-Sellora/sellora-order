/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 466.0, "minX": 0.0, "maxY": 17311.0, "series": [{"data": [[0.0, 466.0], [0.1, 466.0], [0.2, 466.0], [0.3, 466.0], [0.4, 466.0], [0.5, 466.0], [0.6, 466.0], [0.7, 466.0], [0.8, 466.0], [0.9, 466.0], [1.0, 466.0], [1.1, 466.0], [1.2, 466.0], [1.3, 466.0], [1.4, 466.0], [1.5, 466.0], [1.6, 466.0], [1.7, 466.0], [1.8, 466.0], [1.9, 466.0], [2.0, 466.0], [2.1, 466.0], [2.2, 466.0], [2.3, 466.0], [2.4, 466.0], [2.5, 466.0], [2.6, 466.0], [2.7, 466.0], [2.8, 466.0], [2.9, 466.0], [3.0, 466.0], [3.1, 469.0], [3.2, 469.0], [3.3, 469.0], [3.4, 469.0], [3.5, 469.0], [3.6, 469.0], [3.7, 469.0], [3.8, 469.0], [3.9, 469.0], [4.0, 469.0], [4.1, 469.0], [4.2, 469.0], [4.3, 469.0], [4.4, 469.0], [4.5, 469.0], [4.6, 469.0], [4.7, 472.0], [4.8, 472.0], [4.9, 472.0], [5.0, 472.0], [5.1, 472.0], [5.2, 472.0], [5.3, 472.0], [5.4, 472.0], [5.5, 472.0], [5.6, 472.0], [5.7, 472.0], [5.8, 472.0], [5.9, 472.0], [6.0, 472.0], [6.1, 472.0], [6.2, 475.0], [6.3, 475.0], [6.4, 475.0], [6.5, 475.0], [6.6, 475.0], [6.7, 475.0], [6.8, 475.0], [6.9, 475.0], [7.0, 475.0], [7.1, 475.0], [7.2, 475.0], [7.3, 475.0], [7.4, 475.0], [7.5, 475.0], [7.6, 475.0], [7.7, 475.0], [7.8, 475.0], [7.9, 475.0], [8.0, 475.0], [8.1, 475.0], [8.2, 475.0], [8.3, 475.0], [8.4, 475.0], [8.5, 475.0], [8.6, 475.0], [8.7, 475.0], [8.8, 475.0], [8.9, 475.0], [9.0, 475.0], [9.1, 475.0], [9.2, 475.0], [9.3, 476.0], [9.4, 476.0], [9.5, 476.0], [9.6, 476.0], [9.7, 476.0], [9.8, 476.0], [9.9, 476.0], [10.0, 476.0], [10.1, 476.0], [10.2, 476.0], [10.3, 476.0], [10.4, 476.0], [10.5, 476.0], [10.6, 476.0], [10.7, 476.0], [10.8, 477.0], [10.9, 477.0], [11.0, 477.0], [11.1, 477.0], [11.2, 477.0], [11.3, 477.0], [11.4, 477.0], [11.5, 477.0], [11.6, 477.0], [11.7, 477.0], [11.8, 477.0], [11.9, 477.0], [12.0, 477.0], [12.1, 477.0], [12.2, 477.0], [12.3, 477.0], [12.4, 478.0], [12.5, 478.0], [12.6, 478.0], [12.7, 478.0], [12.8, 478.0], [12.9, 478.0], [13.0, 478.0], [13.1, 478.0], [13.2, 478.0], [13.3, 478.0], [13.4, 478.0], [13.5, 478.0], [13.6, 478.0], [13.7, 478.0], [13.8, 478.0], [13.9, 480.0], [14.0, 480.0], [14.1, 480.0], [14.2, 480.0], [14.3, 480.0], [14.4, 480.0], [14.5, 480.0], [14.6, 480.0], [14.7, 480.0], [14.8, 480.0], [14.9, 480.0], [15.0, 480.0], [15.1, 480.0], [15.2, 480.0], [15.3, 480.0], [15.4, 481.0], [15.5, 481.0], [15.6, 481.0], [15.7, 481.0], [15.8, 481.0], [15.9, 481.0], [16.0, 481.0], [16.1, 481.0], [16.2, 481.0], [16.3, 481.0], [16.4, 481.0], [16.5, 481.0], [16.6, 481.0], [16.7, 481.0], [16.8, 481.0], [16.9, 481.0], [17.0, 483.0], [17.1, 483.0], [17.2, 483.0], [17.3, 483.0], [17.4, 483.0], [17.5, 483.0], [17.6, 483.0], [17.7, 483.0], [17.8, 483.0], [17.9, 483.0], [18.0, 483.0], [18.1, 483.0], [18.2, 483.0], [18.3, 483.0], [18.4, 483.0], [18.5, 484.0], [18.6, 484.0], [18.7, 484.0], [18.8, 484.0], [18.9, 484.0], [19.0, 484.0], [19.1, 484.0], [19.2, 484.0], [19.3, 484.0], [19.4, 484.0], [19.5, 484.0], [19.6, 484.0], [19.7, 484.0], [19.8, 484.0], [19.9, 484.0], [20.0, 484.0], [20.1, 486.0], [20.2, 486.0], [20.3, 486.0], [20.4, 486.0], [20.5, 486.0], [20.6, 486.0], [20.7, 486.0], [20.8, 486.0], [20.9, 486.0], [21.0, 486.0], [21.1, 486.0], [21.2, 486.0], [21.3, 486.0], [21.4, 486.0], [21.5, 486.0], [21.6, 489.0], [21.7, 489.0], [21.8, 489.0], [21.9, 489.0], [22.0, 489.0], [22.1, 489.0], [22.2, 489.0], [22.3, 489.0], [22.4, 489.0], [22.5, 489.0], [22.6, 489.0], [22.7, 489.0], [22.8, 489.0], [22.9, 489.0], [23.0, 489.0], [23.1, 490.0], [23.2, 490.0], [23.3, 490.0], [23.4, 490.0], [23.5, 490.0], [23.6, 490.0], [23.7, 490.0], [23.8, 490.0], [23.9, 490.0], [24.0, 490.0], [24.1, 490.0], [24.2, 490.0], [24.3, 490.0], [24.4, 490.0], [24.5, 490.0], [24.6, 490.0], [24.7, 493.0], [24.8, 493.0], [24.9, 493.0], [25.0, 493.0], [25.1, 493.0], [25.2, 493.0], [25.3, 493.0], [25.4, 493.0], [25.5, 493.0], [25.6, 493.0], [25.7, 493.0], [25.8, 493.0], [25.9, 493.0], [26.0, 493.0], [26.1, 493.0], [26.2, 495.0], [26.3, 495.0], [26.4, 495.0], [26.5, 495.0], [26.6, 495.0], [26.7, 495.0], [26.8, 495.0], [26.9, 495.0], [27.0, 495.0], [27.1, 495.0], [27.2, 495.0], [27.3, 495.0], [27.4, 495.0], [27.5, 495.0], [27.6, 495.0], [27.7, 499.0], [27.8, 499.0], [27.9, 499.0], [28.0, 499.0], [28.1, 499.0], [28.2, 499.0], [28.3, 499.0], [28.4, 499.0], [28.5, 499.0], [28.6, 499.0], [28.7, 499.0], [28.8, 499.0], [28.9, 499.0], [29.0, 499.0], [29.1, 499.0], [29.2, 499.0], [29.3, 500.0], [29.4, 500.0], [29.5, 500.0], [29.6, 500.0], [29.7, 500.0], [29.8, 500.0], [29.9, 500.0], [30.0, 500.0], [30.1, 500.0], [30.2, 500.0], [30.3, 500.0], [30.4, 500.0], [30.5, 500.0], [30.6, 500.0], [30.7, 500.0], [30.8, 505.0], [30.9, 505.0], [31.0, 505.0], [31.1, 505.0], [31.2, 505.0], [31.3, 505.0], [31.4, 505.0], [31.5, 505.0], [31.6, 505.0], [31.7, 505.0], [31.8, 505.0], [31.9, 505.0], [32.0, 505.0], [32.1, 505.0], [32.2, 505.0], [32.3, 505.0], [32.4, 508.0], [32.5, 508.0], [32.6, 508.0], [32.7, 508.0], [32.8, 508.0], [32.9, 508.0], [33.0, 508.0], [33.1, 508.0], [33.2, 508.0], [33.3, 508.0], [33.4, 508.0], [33.5, 508.0], [33.6, 508.0], [33.7, 508.0], [33.8, 508.0], [33.9, 509.0], [34.0, 509.0], [34.1, 509.0], [34.2, 509.0], [34.3, 509.0], [34.4, 509.0], [34.5, 509.0], [34.6, 509.0], [34.7, 509.0], [34.8, 509.0], [34.9, 509.0], [35.0, 509.0], [35.1, 509.0], [35.2, 509.0], [35.3, 509.0], [35.4, 509.0], [35.5, 509.0], [35.6, 509.0], [35.7, 509.0], [35.8, 509.0], [35.9, 509.0], [36.0, 509.0], [36.1, 509.0], [36.2, 509.0], [36.3, 509.0], [36.4, 509.0], [36.5, 509.0], [36.6, 509.0], [36.7, 509.0], [36.8, 509.0], [36.9, 509.0], [37.0, 512.0], [37.1, 512.0], [37.2, 512.0], [37.3, 512.0], [37.4, 512.0], [37.5, 512.0], [37.6, 512.0], [37.7, 512.0], [37.8, 512.0], [37.9, 512.0], [38.0, 512.0], [38.1, 512.0], [38.2, 512.0], [38.3, 512.0], [38.4, 512.0], [38.5, 513.0], [38.6, 513.0], [38.7, 513.0], [38.8, 513.0], [38.9, 513.0], [39.0, 513.0], [39.1, 513.0], [39.2, 513.0], [39.3, 513.0], [39.4, 513.0], [39.5, 513.0], [39.6, 513.0], [39.7, 513.0], [39.8, 513.0], [39.9, 513.0], [40.0, 513.0], [40.1, 515.0], [40.2, 515.0], [40.3, 515.0], [40.4, 515.0], [40.5, 515.0], [40.6, 515.0], [40.7, 515.0], [40.8, 515.0], [40.9, 515.0], [41.0, 515.0], [41.1, 515.0], [41.2, 515.0], [41.3, 515.0], [41.4, 515.0], [41.5, 515.0], [41.6, 516.0], [41.7, 516.0], [41.8, 516.0], [41.9, 516.0], [42.0, 516.0], [42.1, 516.0], [42.2, 516.0], [42.3, 516.0], [42.4, 516.0], [42.5, 516.0], [42.6, 516.0], [42.7, 516.0], [42.8, 516.0], [42.9, 516.0], [43.0, 516.0], [43.1, 516.0], [43.2, 516.0], [43.3, 516.0], [43.4, 516.0], [43.5, 516.0], [43.6, 516.0], [43.7, 516.0], [43.8, 516.0], [43.9, 516.0], [44.0, 516.0], [44.1, 516.0], [44.2, 516.0], [44.3, 516.0], [44.4, 516.0], [44.5, 516.0], [44.6, 516.0], [44.7, 518.0], [44.8, 518.0], [44.9, 518.0], [45.0, 518.0], [45.1, 518.0], [45.2, 518.0], [45.3, 518.0], [45.4, 518.0], [45.5, 518.0], [45.6, 518.0], [45.7, 518.0], [45.8, 518.0], [45.9, 518.0], [46.0, 518.0], [46.1, 518.0], [46.2, 519.0], [46.3, 519.0], [46.4, 519.0], [46.5, 519.0], [46.6, 519.0], [46.7, 519.0], [46.8, 519.0], [46.9, 519.0], [47.0, 519.0], [47.1, 519.0], [47.2, 519.0], [47.3, 519.0], [47.4, 519.0], [47.5, 519.0], [47.6, 519.0], [47.7, 523.0], [47.8, 523.0], [47.9, 523.0], [48.0, 523.0], [48.1, 523.0], [48.2, 523.0], [48.3, 523.0], [48.4, 523.0], [48.5, 523.0], [48.6, 523.0], [48.7, 523.0], [48.8, 523.0], [48.9, 523.0], [49.0, 523.0], [49.1, 523.0], [49.2, 523.0], [49.3, 524.0], [49.4, 524.0], [49.5, 524.0], [49.6, 524.0], [49.7, 524.0], [49.8, 524.0], [49.9, 524.0], [50.0, 524.0], [50.1, 524.0], [50.2, 524.0], [50.3, 524.0], [50.4, 524.0], [50.5, 524.0], [50.6, 524.0], [50.7, 524.0], [50.8, 526.0], [50.9, 526.0], [51.0, 526.0], [51.1, 526.0], [51.2, 526.0], [51.3, 526.0], [51.4, 526.0], [51.5, 526.0], [51.6, 526.0], [51.7, 526.0], [51.8, 526.0], [51.9, 526.0], [52.0, 526.0], [52.1, 526.0], [52.2, 526.0], [52.3, 526.0], [52.4, 528.0], [52.5, 528.0], [52.6, 528.0], [52.7, 528.0], [52.8, 528.0], [52.9, 528.0], [53.0, 528.0], [53.1, 528.0], [53.2, 528.0], [53.3, 528.0], [53.4, 528.0], [53.5, 528.0], [53.6, 528.0], [53.7, 528.0], [53.8, 528.0], [53.9, 553.0], [54.0, 553.0], [54.1, 553.0], [54.2, 553.0], [54.3, 553.0], [54.4, 553.0], [54.5, 553.0], [54.6, 553.0], [54.7, 553.0], [54.8, 553.0], [54.9, 553.0], [55.0, 553.0], [55.1, 553.0], [55.2, 553.0], [55.3, 553.0], [55.4, 564.0], [55.5, 564.0], [55.6, 564.0], [55.7, 564.0], [55.8, 564.0], [55.9, 564.0], [56.0, 564.0], [56.1, 564.0], [56.2, 564.0], [56.3, 564.0], [56.4, 564.0], [56.5, 564.0], [56.6, 564.0], [56.7, 564.0], [56.8, 564.0], [56.9, 564.0], [57.0, 624.0], [57.1, 624.0], [57.2, 624.0], [57.3, 624.0], [57.4, 624.0], [57.5, 624.0], [57.6, 624.0], [57.7, 624.0], [57.8, 624.0], [57.9, 624.0], [58.0, 624.0], [58.1, 624.0], [58.2, 624.0], [58.3, 624.0], [58.4, 624.0], [58.5, 679.0], [58.6, 679.0], [58.7, 679.0], [58.8, 679.0], [58.9, 679.0], [59.0, 679.0], [59.1, 679.0], [59.2, 679.0], [59.3, 679.0], [59.4, 679.0], [59.5, 679.0], [59.6, 679.0], [59.7, 679.0], [59.8, 679.0], [59.9, 679.0], [60.0, 679.0], [60.1, 682.0], [60.2, 682.0], [60.3, 682.0], [60.4, 682.0], [60.5, 682.0], [60.6, 682.0], [60.7, 682.0], [60.8, 682.0], [60.9, 682.0], [61.0, 682.0], [61.1, 682.0], [61.2, 682.0], [61.3, 682.0], [61.4, 682.0], [61.5, 682.0], [61.6, 711.0], [61.7, 711.0], [61.8, 711.0], [61.9, 711.0], [62.0, 711.0], [62.1, 711.0], [62.2, 711.0], [62.3, 711.0], [62.4, 711.0], [62.5, 711.0], [62.6, 711.0], [62.7, 711.0], [62.8, 711.0], [62.9, 711.0], [63.0, 711.0], [63.1, 714.0], [63.2, 714.0], [63.3, 714.0], [63.4, 714.0], [63.5, 714.0], [63.6, 714.0], [63.7, 714.0], [63.8, 714.0], [63.9, 714.0], [64.0, 714.0], [64.1, 714.0], [64.2, 714.0], [64.3, 714.0], [64.4, 714.0], [64.5, 714.0], [64.6, 714.0], [64.7, 715.0], [64.8, 715.0], [64.9, 715.0], [65.0, 715.0], [65.1, 715.0], [65.2, 715.0], [65.3, 715.0], [65.4, 715.0], [65.5, 715.0], [65.6, 715.0], [65.7, 715.0], [65.8, 715.0], [65.9, 715.0], [66.0, 715.0], [66.1, 715.0], [66.2, 725.0], [66.3, 725.0], [66.4, 725.0], [66.5, 725.0], [66.6, 725.0], [66.7, 725.0], [66.8, 725.0], [66.9, 725.0], [67.0, 725.0], [67.1, 725.0], [67.2, 725.0], [67.3, 725.0], [67.4, 725.0], [67.5, 725.0], [67.6, 725.0], [67.7, 729.0], [67.8, 729.0], [67.9, 729.0], [68.0, 729.0], [68.1, 729.0], [68.2, 729.0], [68.3, 729.0], [68.4, 729.0], [68.5, 729.0], [68.6, 729.0], [68.7, 729.0], [68.8, 729.0], [68.9, 729.0], [69.0, 729.0], [69.1, 729.0], [69.2, 729.0], [69.3, 732.0], [69.4, 732.0], [69.5, 732.0], [69.6, 732.0], [69.7, 732.0], [69.8, 732.0], [69.9, 732.0], [70.0, 732.0], [70.1, 732.0], [70.2, 732.0], [70.3, 732.0], [70.4, 732.0], [70.5, 732.0], [70.6, 732.0], [70.7, 732.0], [70.8, 735.0], [70.9, 735.0], [71.0, 735.0], [71.1, 735.0], [71.2, 735.0], [71.3, 735.0], [71.4, 735.0], [71.5, 735.0], [71.6, 735.0], [71.7, 735.0], [71.8, 735.0], [71.9, 735.0], [72.0, 735.0], [72.1, 735.0], [72.2, 735.0], [72.3, 735.0], [72.4, 739.0], [72.5, 739.0], [72.6, 739.0], [72.7, 739.0], [72.8, 739.0], [72.9, 739.0], [73.0, 739.0], [73.1, 739.0], [73.2, 739.0], [73.3, 739.0], [73.4, 739.0], [73.5, 739.0], [73.6, 739.0], [73.7, 739.0], [73.8, 739.0], [73.9, 752.0], [74.0, 752.0], [74.1, 752.0], [74.2, 752.0], [74.3, 752.0], [74.4, 752.0], [74.5, 752.0], [74.6, 752.0], [74.7, 752.0], [74.8, 752.0], [74.9, 752.0], [75.0, 752.0], [75.1, 752.0], [75.2, 752.0], [75.3, 752.0], [75.4, 903.0], [75.5, 903.0], [75.6, 903.0], [75.7, 903.0], [75.8, 903.0], [75.9, 903.0], [76.0, 903.0], [76.1, 903.0], [76.2, 903.0], [76.3, 903.0], [76.4, 903.0], [76.5, 903.0], [76.6, 903.0], [76.7, 903.0], [76.8, 903.0], [76.9, 903.0], [77.0, 920.0], [77.1, 920.0], [77.2, 920.0], [77.3, 920.0], [77.4, 920.0], [77.5, 920.0], [77.6, 920.0], [77.7, 920.0], [77.8, 920.0], [77.9, 920.0], [78.0, 920.0], [78.1, 920.0], [78.2, 920.0], [78.3, 920.0], [78.4, 920.0], [78.5, 928.0], [78.6, 928.0], [78.7, 928.0], [78.8, 928.0], [78.9, 928.0], [79.0, 928.0], [79.1, 928.0], [79.2, 928.0], [79.3, 928.0], [79.4, 928.0], [79.5, 928.0], [79.6, 928.0], [79.7, 928.0], [79.8, 928.0], [79.9, 928.0], [80.0, 954.0], [80.1, 954.0], [80.2, 954.0], [80.3, 954.0], [80.4, 954.0], [80.5, 954.0], [80.6, 954.0], [80.7, 954.0], [80.8, 954.0], [80.9, 954.0], [81.0, 954.0], [81.1, 954.0], [81.2, 954.0], [81.3, 954.0], [81.4, 954.0], [81.5, 954.0], [81.6, 993.0], [81.7, 993.0], [81.8, 993.0], [81.9, 993.0], [82.0, 993.0], [82.1, 993.0], [82.2, 993.0], [82.3, 993.0], [82.4, 993.0], [82.5, 993.0], [82.6, 993.0], [82.7, 993.0], [82.8, 993.0], [82.9, 993.0], [83.0, 993.0], [83.1, 1401.0], [83.2, 1401.0], [83.3, 1401.0], [83.4, 1401.0], [83.5, 1401.0], [83.6, 1401.0], [83.7, 1401.0], [83.8, 1401.0], [83.9, 1401.0], [84.0, 1401.0], [84.1, 1401.0], [84.2, 1401.0], [84.3, 1401.0], [84.4, 1401.0], [84.5, 1401.0], [84.6, 1401.0], [84.7, 1537.0], [84.8, 1537.0], [84.9, 1537.0], [85.0, 1537.0], [85.1, 1537.0], [85.2, 1537.0], [85.3, 1537.0], [85.4, 1537.0], [85.5, 1537.0], [85.6, 1537.0], [85.7, 1537.0], [85.8, 1537.0], [85.9, 1537.0], [86.0, 1537.0], [86.1, 1537.0], [86.2, 1570.0], [86.3, 1570.0], [86.4, 1570.0], [86.5, 1570.0], [86.6, 1570.0], [86.7, 1570.0], [86.8, 1570.0], [86.9, 1570.0], [87.0, 1570.0], [87.1, 1570.0], [87.2, 1570.0], [87.3, 1570.0], [87.4, 1570.0], [87.5, 1570.0], [87.6, 1570.0], [87.7, 1769.0], [87.8, 1769.0], [87.9, 1769.0], [88.0, 1769.0], [88.1, 1769.0], [88.2, 1769.0], [88.3, 1769.0], [88.4, 1769.0], [88.5, 1769.0], [88.6, 1769.0], [88.7, 1769.0], [88.8, 1769.0], [88.9, 1769.0], [89.0, 1769.0], [89.1, 1769.0], [89.2, 1769.0], [89.3, 1771.0], [89.4, 1771.0], [89.5, 1771.0], [89.6, 1771.0], [89.7, 1771.0], [89.8, 1771.0], [89.9, 1771.0], [90.0, 1771.0], [90.1, 1771.0], [90.2, 1771.0], [90.3, 1771.0], [90.4, 1771.0], [90.5, 1771.0], [90.6, 1771.0], [90.7, 1771.0], [90.8, 2632.0], [90.9, 2632.0], [91.0, 2632.0], [91.1, 2632.0], [91.2, 2632.0], [91.3, 2632.0], [91.4, 2632.0], [91.5, 2632.0], [91.6, 2632.0], [91.7, 2632.0], [91.8, 2632.0], [91.9, 2632.0], [92.0, 2632.0], [92.1, 2632.0], [92.2, 2632.0], [92.3, 2632.0], [92.4, 3906.0], [92.5, 3906.0], [92.6, 3906.0], [92.7, 3906.0], [92.8, 3906.0], [92.9, 3906.0], [93.0, 3906.0], [93.1, 3906.0], [93.2, 3906.0], [93.3, 3906.0], [93.4, 3906.0], [93.5, 3906.0], [93.6, 3906.0], [93.7, 3906.0], [93.8, 3906.0], [93.9, 5647.0], [94.0, 5647.0], [94.1, 5647.0], [94.2, 5647.0], [94.3, 5647.0], [94.4, 5647.0], [94.5, 5647.0], [94.6, 5647.0], [94.7, 5647.0], [94.8, 5647.0], [94.9, 5647.0], [95.0, 5647.0], [95.1, 5647.0], [95.2, 5647.0], [95.3, 5647.0], [95.4, 5847.0], [95.5, 5847.0], [95.6, 5847.0], [95.7, 5847.0], [95.8, 5847.0], [95.9, 5847.0], [96.0, 5847.0], [96.1, 5847.0], [96.2, 5847.0], [96.3, 5847.0], [96.4, 5847.0], [96.5, 5847.0], [96.6, 5847.0], [96.7, 5847.0], [96.8, 5847.0], [96.9, 5847.0], [97.0, 14827.0], [97.1, 14827.0], [97.2, 14827.0], [97.3, 14827.0], [97.4, 14827.0], [97.5, 14827.0], [97.6, 14827.0], [97.7, 14827.0], [97.8, 14827.0], [97.9, 14827.0], [98.0, 14827.0], [98.1, 14827.0], [98.2, 14827.0], [98.3, 14827.0], [98.4, 14827.0], [98.5, 17311.0], [98.6, 17311.0], [98.7, 17311.0], [98.8, 17311.0], [98.9, 17311.0], [99.0, 17311.0], [99.1, 17311.0], [99.2, 17311.0], [99.3, 17311.0], [99.4, 17311.0], [99.5, 17311.0], [99.6, 17311.0], [99.7, 17311.0], [99.8, 17311.0], [99.9, 17311.0]], "isOverall": false, "label": "GET - List Orders", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 400.0, "maxY": 19.0, "series": [{"data": [[600.0, 3.0], [2600.0, 1.0], [700.0, 9.0], [900.0, 5.0], [14800.0, 1.0], [3900.0, 1.0], [17300.0, 1.0], [5600.0, 1.0], [1400.0, 1.0], [5800.0, 1.0], [1500.0, 2.0], [400.0, 19.0], [1700.0, 2.0], [500.0, 18.0]], "isOverall": false, "label": "GET - List Orders", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 17300.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 2.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 35.0, "series": [{"data": [[0.0, 20.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 35.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [[2.0, 8.0]], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [[3.0, 2.0]], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 3.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 1.0, "minX": 1.792306875E12, "maxY": 1.0, "series": [{"data": [[1.792306875E12, 1.0], [1.79230692E12, 1.0], [1.792307005E12, 1.0], [1.79230688E12, 1.0], [1.792306965E12, 1.0], [1.792306955E12, 1.0], [1.792307E12, 1.0], [1.792306915E12, 1.0], [1.79230696E12, 1.0], [1.79230695E12, 1.0], [1.79230691E12, 1.0], [1.792306995E12, 1.0], [1.79230703E12, 1.0], [1.792306945E12, 1.0], [1.79230694E12, 1.0], [1.7923069E12, 1.0], [1.792306935E12, 1.0], [1.792306895E12, 1.0], [1.79230693E12, 1.0], [1.792307015E12, 1.0], [1.792306975E12, 1.0], [1.79230701E12, 1.0], [1.792306925E12, 1.0], [1.79230697E12, 1.0], [1.792306885E12, 1.0]], "isOverall": false, "label": "Thread Group", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.79230703E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 1383.7692307692307, "minX": 1.0, "maxY": 1383.7692307692307, "series": [{"data": [[1.0, 1383.7692307692307]], "isOverall": false, "label": "GET - List Orders", "isController": false}, {"data": [[1.0, 1383.7692307692307]], "isOverall": false, "label": "GET - List Orders-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 1.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 0.0, "minX": 1.792306875E12, "maxY": 5936.8, "series": [{"data": [[1.792306875E12, 1484.2], [1.79230692E12, 4452.6], [1.792307005E12, 4452.6], [1.79230688E12, 1484.2], [1.792306965E12, 4452.6], [1.792306955E12, 4452.6], [1.792307E12, 5936.8], [1.792306915E12, 4452.6], [1.79230696E12, 5936.8], [1.79230695E12, 4452.6], [1.79230691E12, 2968.4], [1.792306995E12, 3605.2], [1.79230703E12, 636.8], [1.792306945E12, 5936.8], [1.79230694E12, 4452.6], [1.7923069E12, 4452.6], [1.792306935E12, 2968.4], [1.792306895E12, 4452.6], [1.79230693E12, 2968.4], [1.792307015E12, 2968.4], [1.792306975E12, 2968.4], [1.79230701E12, 4452.6], [1.792306925E12, 4452.6], [1.79230697E12, 2968.4], [1.792306885E12, 2968.4]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.792306875E12, 307.2], [1.79230692E12, 921.6], [1.792307005E12, 921.6], [1.79230688E12, 307.2], [1.792306965E12, 921.6], [1.792306955E12, 921.6], [1.792307E12, 1228.8], [1.792306915E12, 921.6], [1.79230696E12, 1228.8], [1.79230695E12, 921.6], [1.79230691E12, 614.4], [1.792306995E12, 614.4], [1.79230703E12, 0.0], [1.792306945E12, 1228.8], [1.79230694E12, 921.6], [1.7923069E12, 921.6], [1.792306935E12, 614.4], [1.792306895E12, 921.6], [1.79230693E12, 614.4], [1.792307015E12, 614.4], [1.792306975E12, 614.4], [1.79230701E12, 921.6], [1.792306925E12, 921.6], [1.79230697E12, 614.4], [1.792306885E12, 614.4]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.79230703E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 469.0, "minX": 1.792306875E12, "maxY": 14827.0, "series": [{"data": [[1.792306875E12, 928.0], [1.79230692E12, 507.0], [1.792307005E12, 524.6666666666666], [1.79230688E12, 3906.0], [1.792306965E12, 502.6666666666667], [1.792306955E12, 469.0], [1.792307E12, 496.0], [1.792306915E12, 911.0], [1.79230696E12, 506.25], [1.79230695E12, 489.6666666666667], [1.79230691E12, 3320.0], [1.792306995E12, 6235.666666666666], [1.79230703E12, 14827.0], [1.792306945E12, 640.0], [1.79230694E12, 653.3333333333334], [1.7923069E12, 702.6666666666666], [1.792306935E12, 738.5], [1.792306895E12, 2493.6666666666665], [1.79230693E12, 1578.0], [1.792307015E12, 489.0], [1.792306975E12, 518.5], [1.79230701E12, 494.3333333333333], [1.792306925E12, 881.3333333333334], [1.79230697E12, 1245.5], [1.792306885E12, 1670.5]], "isOverall": false, "label": "GET - List Orders", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.79230703E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 0.0, "minX": 1.792306875E12, "maxY": 3906.0, "series": [{"data": [[1.792306875E12, 928.0], [1.79230692E12, 506.6666666666667], [1.792307005E12, 524.3333333333334], [1.79230688E12, 3906.0], [1.792306965E12, 502.6666666666667], [1.792306955E12, 469.0], [1.792307E12, 496.0], [1.792306915E12, 911.0], [1.79230696E12, 506.25], [1.79230695E12, 489.6666666666667], [1.79230691E12, 3319.5], [1.792306995E12, 465.0], [1.79230703E12, 0.0], [1.792306945E12, 589.0], [1.79230694E12, 653.3333333333334], [1.7923069E12, 702.6666666666666], [1.792306935E12, 738.5], [1.792306895E12, 2493.6666666666665], [1.79230693E12, 1578.0], [1.792307015E12, 489.0], [1.792306975E12, 518.5], [1.79230701E12, 494.0], [1.792306925E12, 881.3333333333334], [1.79230697E12, 1245.5], [1.792306885E12, 1670.5]], "isOverall": false, "label": "GET - List Orders", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.79230703E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 0.0, "minX": 1.792306875E12, "maxY": 237.0, "series": [{"data": [[1.792306875E12, 0.0], [1.79230692E12, 0.0], [1.792307005E12, 0.0], [1.79230688E12, 0.0], [1.792306965E12, 0.0], [1.792306955E12, 0.0], [1.792307E12, 0.0], [1.792306915E12, 0.0], [1.79230696E12, 0.0], [1.79230695E12, 0.0], [1.79230691E12, 237.0], [1.792306995E12, 143.0], [1.79230703E12, 0.0], [1.792306945E12, 0.0], [1.79230694E12, 0.0], [1.7923069E12, 0.0], [1.792306935E12, 0.0], [1.792306895E12, 0.0], [1.79230693E12, 0.0], [1.792307015E12, 0.0], [1.792306975E12, 0.0], [1.79230701E12, 0.0], [1.792306925E12, 0.0], [1.79230697E12, 235.0], [1.792306885E12, 0.0]], "isOverall": false, "label": "GET - List Orders", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.79230703E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 466.0, "minX": 1.792306875E12, "maxY": 5847.0, "series": [{"data": [[1.792306875E12, 928.0], [1.79230694E12, 732.0], [1.79230692E12, 526.0], [1.792307005E12, 553.0], [1.7923069E12, 715.0], [1.79230688E12, 3906.0], [1.792306965E12, 516.0], [1.792306955E12, 472.0], [1.792306935E12, 752.0], [1.792307E12, 516.0], [1.792306915E12, 1769.0], [1.792306895E12, 5847.0], [1.79230696E12, 564.0], [1.79230695E12, 523.0], [1.79230693E12, 2632.0], [1.792307015E12, 495.0], [1.79230691E12, 5647.0], [1.792306995E12, 903.0], [1.792306975E12, 528.0], [1.792306945E12, 739.0], [1.79230701E12, 513.0], [1.792306925E12, 1401.0], [1.79230697E12, 1537.0], [1.792306885E12, 1771.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.792306875E12, 928.0], [1.79230694E12, 499.0], [1.79230692E12, 476.0], [1.792307005E12, 509.0], [1.7923069E12, 682.0], [1.79230688E12, 3906.0], [1.792306965E12, 477.0], [1.792306955E12, 466.0], [1.792306935E12, 725.0], [1.792307E12, 478.0], [1.792306915E12, 475.0], [1.792306895E12, 714.0], [1.79230696E12, 475.0], [1.79230695E12, 466.0], [1.79230693E12, 524.0], [1.792307015E12, 483.0], [1.79230691E12, 993.0], [1.792306995E12, 493.0], [1.792306975E12, 509.0], [1.792306945E12, 518.0], [1.79230701E12, 484.0], [1.792306925E12, 508.0], [1.79230697E12, 954.0], [1.792306885E12, 1570.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.792306875E12, 928.0], [1.79230694E12, 732.0], [1.79230692E12, 526.0], [1.792307005E12, 553.0], [1.7923069E12, 715.0], [1.79230688E12, 3906.0], [1.792306965E12, 516.0], [1.792306955E12, 472.0], [1.792306935E12, 752.0], [1.792307E12, 516.0], [1.792306915E12, 1769.0], [1.792306895E12, 5847.0], [1.79230696E12, 564.0], [1.79230695E12, 523.0], [1.79230693E12, 2632.0], [1.792307015E12, 495.0], [1.79230691E12, 5647.0], [1.792306995E12, 903.0], [1.792306975E12, 528.0], [1.792306945E12, 739.0], [1.79230701E12, 513.0], [1.792306925E12, 1401.0], [1.79230697E12, 1537.0], [1.792306885E12, 1771.0]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.792306875E12, 928.0], [1.79230694E12, 732.0], [1.79230692E12, 526.0], [1.792307005E12, 553.0], [1.7923069E12, 715.0], [1.79230688E12, 3906.0], [1.792306965E12, 516.0], [1.792306955E12, 472.0], [1.792306935E12, 752.0], [1.792307E12, 516.0], [1.792306915E12, 1769.0], [1.792306895E12, 5847.0], [1.79230696E12, 564.0], [1.79230695E12, 523.0], [1.79230693E12, 2632.0], [1.792307015E12, 495.0], [1.79230691E12, 5647.0], [1.792306995E12, 903.0], [1.792306975E12, 528.0], [1.792306945E12, 739.0], [1.79230701E12, 513.0], [1.792306925E12, 1401.0], [1.79230697E12, 1537.0], [1.792306885E12, 1771.0]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.792306875E12, 928.0], [1.79230694E12, 729.0], [1.79230692E12, 519.0], [1.792307005E12, 512.0], [1.7923069E12, 711.0], [1.79230688E12, 3906.0], [1.792306965E12, 515.0], [1.792306955E12, 469.0], [1.792306935E12, 738.5], [1.792307E12, 495.0], [1.792306915E12, 489.0], [1.792306895E12, 920.0], [1.79230696E12, 493.0], [1.79230695E12, 480.0], [1.79230693E12, 1578.0], [1.792307015E12, 489.0], [1.79230691E12, 3320.0], [1.792306995E12, 698.0], [1.792306975E12, 518.5], [1.792306945E12, 651.5], [1.79230701E12, 486.0], [1.792306925E12, 735.0], [1.79230697E12, 1245.5], [1.792306885E12, 1670.5]], "isOverall": false, "label": "Median", "isController": false}, {"data": [[1.792306875E12, 928.0], [1.79230694E12, 732.0], [1.79230692E12, 526.0], [1.792307005E12, 553.0], [1.7923069E12, 715.0], [1.79230688E12, 3906.0], [1.792306965E12, 516.0], [1.792306955E12, 472.0], [1.792306935E12, 752.0], [1.792307E12, 516.0], [1.792306915E12, 1769.0], [1.792306895E12, 5847.0], [1.79230696E12, 564.0], [1.79230695E12, 523.0], [1.79230693E12, 2632.0], [1.792307015E12, 495.0], [1.79230691E12, 5647.0], [1.792306995E12, 903.0], [1.792306975E12, 528.0], [1.792306945E12, 739.0], [1.79230701E12, 513.0], [1.792306925E12, 1401.0], [1.79230697E12, 1537.0], [1.792306885E12, 1771.0]], "isOverall": false, "label": "95th percentile", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.792307015E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 523.0, "minX": 1.0, "maxY": 16069.0, "series": [{"data": [[1.0, 523.0]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[1.0, 16069.0]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 0.0, "minX": 1.0, "maxY": 523.0, "series": [{"data": [[1.0, 523.0]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[1.0, 0.0]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 0.2, "minX": 1.792306875E12, "maxY": 0.8, "series": [{"data": [[1.792306875E12, 0.2], [1.79230692E12, 0.8], [1.792307005E12, 0.6], [1.79230688E12, 0.2], [1.792306965E12, 0.6], [1.792306955E12, 0.8], [1.792307E12, 0.6], [1.792306915E12, 0.4], [1.79230696E12, 0.6], [1.79230695E12, 0.6], [1.79230691E12, 0.4], [1.792306995E12, 0.6], [1.792306945E12, 0.6], [1.792306905E12, 0.2], [1.79230694E12, 0.6], [1.7923069E12, 0.6], [1.792306935E12, 0.6], [1.792306895E12, 0.4], [1.79230693E12, 0.4], [1.792307015E12, 0.4], [1.79230689E12, 0.2], [1.792306975E12, 0.4], [1.79230701E12, 0.8], [1.792306925E12, 0.4], [1.79230697E12, 0.6], [1.792306885E12, 0.4]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.792307015E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 0.2, "minX": 1.792306875E12, "maxY": 0.8, "series": [{"data": [[1.792306875E12, 0.2], [1.79230694E12, 0.6], [1.79230692E12, 0.6], [1.792307005E12, 0.6], [1.7923069E12, 0.6], [1.79230688E12, 0.2], [1.792306965E12, 0.6], [1.792306955E12, 0.6], [1.792306935E12, 0.4], [1.792307E12, 0.8], [1.792306915E12, 0.6], [1.792306895E12, 0.6], [1.79230696E12, 0.8], [1.79230695E12, 0.6], [1.79230693E12, 0.4], [1.792307015E12, 0.4], [1.79230691E12, 0.4], [1.792306995E12, 0.4], [1.792306975E12, 0.4], [1.792306945E12, 0.8], [1.79230701E12, 0.6], [1.792306925E12, 0.6], [1.79230697E12, 0.4], [1.792306885E12, 0.4]], "isOverall": false, "label": "200", "isController": false}, {"data": [[1.792306995E12, 0.2], [1.79230703E12, 0.2]], "isOverall": false, "label": "Non HTTP response code: java.net.SocketTimeoutException", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.79230703E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 0.2, "minX": 1.792306875E12, "maxY": 0.8, "series": [{"data": [[1.792306875E12, 0.2], [1.79230694E12, 0.6], [1.79230692E12, 0.6], [1.792307005E12, 0.6], [1.7923069E12, 0.6], [1.79230688E12, 0.2], [1.792306965E12, 0.6], [1.792306955E12, 0.6], [1.792306935E12, 0.4], [1.792307E12, 0.8], [1.792306915E12, 0.6], [1.792306895E12, 0.6], [1.79230696E12, 0.8], [1.79230695E12, 0.6], [1.79230693E12, 0.4], [1.792307015E12, 0.4], [1.79230691E12, 0.4], [1.792306995E12, 0.4], [1.792306975E12, 0.4], [1.792306945E12, 0.8], [1.79230701E12, 0.6], [1.792306925E12, 0.6], [1.79230697E12, 0.4], [1.792306885E12, 0.4]], "isOverall": false, "label": "GET - List Orders-success", "isController": false}, {"data": [[1.792306995E12, 0.2], [1.79230703E12, 0.2]], "isOverall": false, "label": "GET - List Orders-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.79230703E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 0.2, "minX": 1.792306875E12, "maxY": 0.8, "series": [{"data": [[1.792306875E12, 0.2], [1.79230694E12, 0.6], [1.79230692E12, 0.6], [1.792307005E12, 0.6], [1.7923069E12, 0.6], [1.79230688E12, 0.2], [1.792306965E12, 0.6], [1.792306955E12, 0.6], [1.792306935E12, 0.4], [1.792307E12, 0.8], [1.792306915E12, 0.6], [1.792306895E12, 0.6], [1.79230696E12, 0.8], [1.79230695E12, 0.6], [1.79230693E12, 0.4], [1.792307015E12, 0.4], [1.79230691E12, 0.4], [1.792306995E12, 0.4], [1.792306975E12, 0.4], [1.792306945E12, 0.8], [1.79230701E12, 0.6], [1.792306925E12, 0.6], [1.79230697E12, 0.4], [1.792306885E12, 0.4]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [[1.792306995E12, 0.2], [1.79230703E12, 0.2]], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.79230703E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

