/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 111.0, "minX": 0.0, "maxY": 7092.0, "series": [{"data": [[0.0, 111.0], [0.1, 115.0], [0.2, 116.0], [0.3, 117.0], [0.4, 118.0], [0.5, 119.0], [0.6, 120.0], [0.7, 120.0], [0.8, 121.0], [0.9, 121.0], [1.0, 122.0], [1.1, 122.0], [1.2, 123.0], [1.3, 123.0], [1.4, 124.0], [1.5, 124.0], [1.6, 125.0], [1.7, 125.0], [1.8, 125.0], [1.9, 126.0], [2.0, 126.0], [2.1, 126.0], [2.2, 126.0], [2.3, 126.0], [2.4, 126.0], [2.5, 127.0], [2.6, 127.0], [2.7, 127.0], [2.8, 127.0], [2.9, 128.0], [3.0, 128.0], [3.1, 128.0], [3.2, 128.0], [3.3, 128.0], [3.4, 129.0], [3.5, 129.0], [3.6, 129.0], [3.7, 129.0], [3.8, 130.0], [3.9, 130.0], [4.0, 130.0], [4.1, 130.0], [4.2, 130.0], [4.3, 130.0], [4.4, 131.0], [4.5, 131.0], [4.6, 131.0], [4.7, 131.0], [4.8, 131.0], [4.9, 132.0], [5.0, 132.0], [5.1, 132.0], [5.2, 132.0], [5.3, 132.0], [5.4, 132.0], [5.5, 132.0], [5.6, 133.0], [5.7, 133.0], [5.8, 133.0], [5.9, 133.0], [6.0, 133.0], [6.1, 133.0], [6.2, 133.0], [6.3, 134.0], [6.4, 134.0], [6.5, 134.0], [6.6, 134.0], [6.7, 134.0], [6.8, 134.0], [6.9, 135.0], [7.0, 135.0], [7.1, 135.0], [7.2, 135.0], [7.3, 135.0], [7.4, 135.0], [7.5, 135.0], [7.6, 135.0], [7.7, 135.0], [7.8, 136.0], [7.9, 136.0], [8.0, 136.0], [8.1, 136.0], [8.2, 136.0], [8.3, 136.0], [8.4, 136.0], [8.5, 136.0], [8.6, 136.0], [8.7, 137.0], [8.8, 137.0], [8.9, 137.0], [9.0, 137.0], [9.1, 137.0], [9.2, 137.0], [9.3, 137.0], [9.4, 137.0], [9.5, 137.0], [9.6, 137.0], [9.7, 137.0], [9.8, 138.0], [9.9, 138.0], [10.0, 138.0], [10.1, 138.0], [10.2, 138.0], [10.3, 138.0], [10.4, 138.0], [10.5, 138.0], [10.6, 138.0], [10.7, 139.0], [10.8, 139.0], [10.9, 139.0], [11.0, 139.0], [11.1, 139.0], [11.2, 139.0], [11.3, 139.0], [11.4, 139.0], [11.5, 139.0], [11.6, 139.0], [11.7, 139.0], [11.8, 140.0], [11.9, 140.0], [12.0, 140.0], [12.1, 140.0], [12.2, 140.0], [12.3, 140.0], [12.4, 140.0], [12.5, 140.0], [12.6, 140.0], [12.7, 141.0], [12.8, 141.0], [12.9, 141.0], [13.0, 141.0], [13.1, 141.0], [13.2, 141.0], [13.3, 141.0], [13.4, 141.0], [13.5, 142.0], [13.6, 142.0], [13.7, 142.0], [13.8, 142.0], [13.9, 142.0], [14.0, 142.0], [14.1, 142.0], [14.2, 142.0], [14.3, 142.0], [14.4, 143.0], [14.5, 143.0], [14.6, 143.0], [14.7, 143.0], [14.8, 143.0], [14.9, 143.0], [15.0, 143.0], [15.1, 143.0], [15.2, 143.0], [15.3, 144.0], [15.4, 144.0], [15.5, 144.0], [15.6, 144.0], [15.7, 144.0], [15.8, 144.0], [15.9, 144.0], [16.0, 144.0], [16.1, 144.0], [16.2, 144.0], [16.3, 144.0], [16.4, 145.0], [16.5, 145.0], [16.6, 145.0], [16.7, 145.0], [16.8, 145.0], [16.9, 145.0], [17.0, 145.0], [17.1, 145.0], [17.2, 145.0], [17.3, 146.0], [17.4, 146.0], [17.5, 146.0], [17.6, 146.0], [17.7, 146.0], [17.8, 146.0], [17.9, 146.0], [18.0, 146.0], [18.1, 146.0], [18.2, 147.0], [18.3, 147.0], [18.4, 147.0], [18.5, 147.0], [18.6, 147.0], [18.7, 147.0], [18.8, 147.0], [18.9, 147.0], [19.0, 147.0], [19.1, 147.0], [19.2, 147.0], [19.3, 148.0], [19.4, 148.0], [19.5, 148.0], [19.6, 148.0], [19.7, 148.0], [19.8, 148.0], [19.9, 148.0], [20.0, 148.0], [20.1, 148.0], [20.2, 149.0], [20.3, 149.0], [20.4, 149.0], [20.5, 149.0], [20.6, 149.0], [20.7, 149.0], [20.8, 149.0], [20.9, 149.0], [21.0, 149.0], [21.1, 149.0], [21.2, 149.0], [21.3, 149.0], [21.4, 150.0], [21.5, 150.0], [21.6, 150.0], [21.7, 150.0], [21.8, 150.0], [21.9, 150.0], [22.0, 150.0], [22.1, 150.0], [22.2, 150.0], [22.3, 150.0], [22.4, 150.0], [22.5, 151.0], [22.6, 151.0], [22.7, 151.0], [22.8, 151.0], [22.9, 151.0], [23.0, 151.0], [23.1, 151.0], [23.2, 151.0], [23.3, 151.0], [23.4, 152.0], [23.5, 152.0], [23.6, 152.0], [23.7, 152.0], [23.8, 152.0], [23.9, 152.0], [24.0, 152.0], [24.1, 152.0], [24.2, 152.0], [24.3, 152.0], [24.4, 152.0], [24.5, 152.0], [24.6, 153.0], [24.7, 153.0], [24.8, 153.0], [24.9, 153.0], [25.0, 153.0], [25.1, 153.0], [25.2, 153.0], [25.3, 153.0], [25.4, 153.0], [25.5, 153.0], [25.6, 154.0], [25.7, 154.0], [25.8, 154.0], [25.9, 154.0], [26.0, 154.0], [26.1, 154.0], [26.2, 154.0], [26.3, 154.0], [26.4, 154.0], [26.5, 154.0], [26.6, 155.0], [26.7, 155.0], [26.8, 155.0], [26.9, 155.0], [27.0, 155.0], [27.1, 155.0], [27.2, 155.0], [27.3, 155.0], [27.4, 155.0], [27.5, 155.0], [27.6, 155.0], [27.7, 155.0], [27.8, 155.0], [27.9, 155.0], [28.0, 156.0], [28.1, 156.0], [28.2, 156.0], [28.3, 156.0], [28.4, 156.0], [28.5, 156.0], [28.6, 156.0], [28.7, 156.0], [28.8, 156.0], [28.9, 156.0], [29.0, 156.0], [29.1, 156.0], [29.2, 157.0], [29.3, 157.0], [29.4, 157.0], [29.5, 157.0], [29.6, 157.0], [29.7, 157.0], [29.8, 157.0], [29.9, 157.0], [30.0, 157.0], [30.1, 158.0], [30.2, 158.0], [30.3, 158.0], [30.4, 158.0], [30.5, 158.0], [30.6, 158.0], [30.7, 158.0], [30.8, 158.0], [30.9, 158.0], [31.0, 158.0], [31.1, 158.0], [31.2, 159.0], [31.3, 159.0], [31.4, 159.0], [31.5, 159.0], [31.6, 159.0], [31.7, 159.0], [31.8, 159.0], [31.9, 159.0], [32.0, 159.0], [32.1, 159.0], [32.2, 160.0], [32.3, 160.0], [32.4, 160.0], [32.5, 160.0], [32.6, 160.0], [32.7, 160.0], [32.8, 160.0], [32.9, 160.0], [33.0, 160.0], [33.1, 161.0], [33.2, 161.0], [33.3, 161.0], [33.4, 161.0], [33.5, 161.0], [33.6, 161.0], [33.7, 161.0], [33.8, 161.0], [33.9, 162.0], [34.0, 162.0], [34.1, 162.0], [34.2, 162.0], [34.3, 162.0], [34.4, 162.0], [34.5, 162.0], [34.6, 162.0], [34.7, 162.0], [34.8, 162.0], [34.9, 163.0], [35.0, 163.0], [35.1, 163.0], [35.2, 163.0], [35.3, 163.0], [35.4, 163.0], [35.5, 163.0], [35.6, 163.0], [35.7, 164.0], [35.8, 164.0], [35.9, 164.0], [36.0, 164.0], [36.1, 164.0], [36.2, 164.0], [36.3, 165.0], [36.4, 165.0], [36.5, 165.0], [36.6, 165.0], [36.7, 165.0], [36.8, 165.0], [36.9, 165.0], [37.0, 165.0], [37.1, 165.0], [37.2, 166.0], [37.3, 166.0], [37.4, 166.0], [37.5, 166.0], [37.6, 166.0], [37.7, 166.0], [37.8, 166.0], [37.9, 166.0], [38.0, 167.0], [38.1, 167.0], [38.2, 167.0], [38.3, 167.0], [38.4, 167.0], [38.5, 167.0], [38.6, 167.0], [38.7, 167.0], [38.8, 167.0], [38.9, 168.0], [39.0, 168.0], [39.1, 168.0], [39.2, 168.0], [39.3, 168.0], [39.4, 168.0], [39.5, 168.0], [39.6, 168.0], [39.7, 168.0], [39.8, 168.0], [39.9, 169.0], [40.0, 169.0], [40.1, 169.0], [40.2, 169.0], [40.3, 169.0], [40.4, 169.0], [40.5, 169.0], [40.6, 170.0], [40.7, 170.0], [40.8, 170.0], [40.9, 170.0], [41.0, 170.0], [41.1, 170.0], [41.2, 170.0], [41.3, 171.0], [41.4, 171.0], [41.5, 171.0], [41.6, 171.0], [41.7, 171.0], [41.8, 171.0], [41.9, 171.0], [42.0, 171.0], [42.1, 171.0], [42.2, 171.0], [42.3, 171.0], [42.4, 172.0], [42.5, 172.0], [42.6, 172.0], [42.7, 172.0], [42.8, 172.0], [42.9, 172.0], [43.0, 172.0], [43.1, 172.0], [43.2, 173.0], [43.3, 173.0], [43.4, 173.0], [43.5, 173.0], [43.6, 173.0], [43.7, 173.0], [43.8, 173.0], [43.9, 173.0], [44.0, 173.0], [44.1, 174.0], [44.2, 174.0], [44.3, 174.0], [44.4, 174.0], [44.5, 174.0], [44.6, 174.0], [44.7, 174.0], [44.8, 174.0], [44.9, 175.0], [45.0, 175.0], [45.1, 175.0], [45.2, 175.0], [45.3, 175.0], [45.4, 175.0], [45.5, 175.0], [45.6, 175.0], [45.7, 176.0], [45.8, 176.0], [45.9, 176.0], [46.0, 176.0], [46.1, 176.0], [46.2, 176.0], [46.3, 176.0], [46.4, 176.0], [46.5, 177.0], [46.6, 177.0], [46.7, 177.0], [46.8, 177.0], [46.9, 177.0], [47.0, 177.0], [47.1, 177.0], [47.2, 178.0], [47.3, 178.0], [47.4, 178.0], [47.5, 178.0], [47.6, 178.0], [47.7, 178.0], [47.8, 178.0], [47.9, 178.0], [48.0, 178.0], [48.1, 179.0], [48.2, 179.0], [48.3, 179.0], [48.4, 179.0], [48.5, 179.0], [48.6, 179.0], [48.7, 180.0], [48.8, 180.0], [48.9, 180.0], [49.0, 180.0], [49.1, 180.0], [49.2, 180.0], [49.3, 181.0], [49.4, 181.0], [49.5, 181.0], [49.6, 181.0], [49.7, 181.0], [49.8, 181.0], [49.9, 181.0], [50.0, 182.0], [50.1, 182.0], [50.2, 182.0], [50.3, 182.0], [50.4, 182.0], [50.5, 182.0], [50.6, 183.0], [50.7, 183.0], [50.8, 183.0], [50.9, 183.0], [51.0, 183.0], [51.1, 183.0], [51.2, 183.0], [51.3, 183.0], [51.4, 183.0], [51.5, 184.0], [51.6, 184.0], [51.7, 184.0], [51.8, 184.0], [51.9, 184.0], [52.0, 185.0], [52.1, 185.0], [52.2, 185.0], [52.3, 185.0], [52.4, 185.0], [52.5, 185.0], [52.6, 185.0], [52.7, 186.0], [52.8, 186.0], [52.9, 186.0], [53.0, 186.0], [53.1, 186.0], [53.2, 187.0], [53.3, 187.0], [53.4, 187.0], [53.5, 187.0], [53.6, 187.0], [53.7, 187.0], [53.8, 187.0], [53.9, 187.0], [54.0, 188.0], [54.1, 188.0], [54.2, 188.0], [54.3, 188.0], [54.4, 189.0], [54.5, 189.0], [54.6, 189.0], [54.7, 189.0], [54.8, 189.0], [54.9, 190.0], [55.0, 190.0], [55.1, 190.0], [55.2, 190.0], [55.3, 190.0], [55.4, 191.0], [55.5, 191.0], [55.6, 191.0], [55.7, 191.0], [55.8, 192.0], [55.9, 192.0], [56.0, 192.0], [56.1, 192.0], [56.2, 192.0], [56.3, 192.0], [56.4, 193.0], [56.5, 193.0], [56.6, 193.0], [56.7, 194.0], [56.8, 194.0], [56.9, 194.0], [57.0, 194.0], [57.1, 194.0], [57.2, 195.0], [57.3, 195.0], [57.4, 195.0], [57.5, 195.0], [57.6, 195.0], [57.7, 196.0], [57.8, 196.0], [57.9, 196.0], [58.0, 196.0], [58.1, 196.0], [58.2, 196.0], [58.3, 197.0], [58.4, 197.0], [58.5, 197.0], [58.6, 198.0], [58.7, 198.0], [58.8, 198.0], [58.9, 198.0], [59.0, 199.0], [59.1, 199.0], [59.2, 199.0], [59.3, 199.0], [59.4, 200.0], [59.5, 200.0], [59.6, 200.0], [59.7, 200.0], [59.8, 201.0], [59.9, 201.0], [60.0, 201.0], [60.1, 202.0], [60.2, 202.0], [60.3, 202.0], [60.4, 202.0], [60.5, 202.0], [60.6, 203.0], [60.7, 203.0], [60.8, 203.0], [60.9, 203.0], [61.0, 203.0], [61.1, 204.0], [61.2, 204.0], [61.3, 204.0], [61.4, 204.0], [61.5, 204.0], [61.6, 205.0], [61.7, 205.0], [61.8, 205.0], [61.9, 206.0], [62.0, 206.0], [62.1, 206.0], [62.2, 206.0], [62.3, 206.0], [62.4, 207.0], [62.5, 207.0], [62.6, 207.0], [62.7, 208.0], [62.8, 208.0], [62.9, 208.0], [63.0, 208.0], [63.1, 208.0], [63.2, 208.0], [63.3, 209.0], [63.4, 209.0], [63.5, 209.0], [63.6, 210.0], [63.7, 210.0], [63.8, 210.0], [63.9, 210.0], [64.0, 211.0], [64.1, 211.0], [64.2, 212.0], [64.3, 212.0], [64.4, 212.0], [64.5, 213.0], [64.6, 213.0], [64.7, 213.0], [64.8, 213.0], [64.9, 214.0], [65.0, 214.0], [65.1, 215.0], [65.2, 215.0], [65.3, 215.0], [65.4, 215.0], [65.5, 215.0], [65.6, 215.0], [65.7, 215.0], [65.8, 216.0], [65.9, 216.0], [66.0, 216.0], [66.1, 216.0], [66.2, 217.0], [66.3, 217.0], [66.4, 217.0], [66.5, 218.0], [66.6, 218.0], [66.7, 218.0], [66.8, 218.0], [66.9, 218.0], [67.0, 219.0], [67.1, 219.0], [67.2, 219.0], [67.3, 219.0], [67.4, 220.0], [67.5, 220.0], [67.6, 220.0], [67.7, 221.0], [67.8, 221.0], [67.9, 221.0], [68.0, 222.0], [68.1, 222.0], [68.2, 222.0], [68.3, 223.0], [68.4, 223.0], [68.5, 223.0], [68.6, 223.0], [68.7, 224.0], [68.8, 225.0], [68.9, 225.0], [69.0, 226.0], [69.1, 226.0], [69.2, 227.0], [69.3, 228.0], [69.4, 228.0], [69.5, 228.0], [69.6, 229.0], [69.7, 229.0], [69.8, 230.0], [69.9, 230.0], [70.0, 231.0], [70.1, 231.0], [70.2, 231.0], [70.3, 232.0], [70.4, 233.0], [70.5, 233.0], [70.6, 234.0], [70.7, 234.0], [70.8, 234.0], [70.9, 234.0], [71.0, 235.0], [71.1, 235.0], [71.2, 235.0], [71.3, 236.0], [71.4, 237.0], [71.5, 237.0], [71.6, 238.0], [71.7, 239.0], [71.8, 239.0], [71.9, 240.0], [72.0, 240.0], [72.1, 241.0], [72.2, 241.0], [72.3, 241.0], [72.4, 242.0], [72.5, 243.0], [72.6, 243.0], [72.7, 244.0], [72.8, 244.0], [72.9, 244.0], [73.0, 245.0], [73.1, 245.0], [73.2, 245.0], [73.3, 245.0], [73.4, 246.0], [73.5, 247.0], [73.6, 248.0], [73.7, 248.0], [73.8, 249.0], [73.9, 249.0], [74.0, 249.0], [74.1, 249.0], [74.2, 250.0], [74.3, 250.0], [74.4, 251.0], [74.5, 251.0], [74.6, 252.0], [74.7, 252.0], [74.8, 253.0], [74.9, 253.0], [75.0, 254.0], [75.1, 254.0], [75.2, 256.0], [75.3, 257.0], [75.4, 257.0], [75.5, 257.0], [75.6, 258.0], [75.7, 259.0], [75.8, 260.0], [75.9, 261.0], [76.0, 261.0], [76.1, 262.0], [76.2, 263.0], [76.3, 264.0], [76.4, 264.0], [76.5, 265.0], [76.6, 266.0], [76.7, 266.0], [76.8, 267.0], [76.9, 267.0], [77.0, 268.0], [77.1, 269.0], [77.2, 270.0], [77.3, 270.0], [77.4, 272.0], [77.5, 272.0], [77.6, 274.0], [77.7, 275.0], [77.8, 275.0], [77.9, 276.0], [78.0, 278.0], [78.1, 279.0], [78.2, 280.0], [78.3, 281.0], [78.4, 282.0], [78.5, 283.0], [78.6, 284.0], [78.7, 286.0], [78.8, 286.0], [78.9, 287.0], [79.0, 288.0], [79.1, 289.0], [79.2, 290.0], [79.3, 292.0], [79.4, 292.0], [79.5, 293.0], [79.6, 295.0], [79.7, 296.0], [79.8, 297.0], [79.9, 299.0], [80.0, 300.0], [80.1, 301.0], [80.2, 303.0], [80.3, 305.0], [80.4, 306.0], [80.5, 306.0], [80.6, 309.0], [80.7, 311.0], [80.8, 315.0], [80.9, 316.0], [81.0, 317.0], [81.1, 319.0], [81.2, 322.0], [81.3, 324.0], [81.4, 325.0], [81.5, 327.0], [81.6, 329.0], [81.7, 330.0], [81.8, 331.0], [81.9, 332.0], [82.0, 335.0], [82.1, 337.0], [82.2, 341.0], [82.3, 343.0], [82.4, 344.0], [82.5, 349.0], [82.6, 353.0], [82.7, 355.0], [82.8, 356.0], [82.9, 357.0], [83.0, 359.0], [83.1, 361.0], [83.2, 362.0], [83.3, 363.0], [83.4, 365.0], [83.5, 367.0], [83.6, 371.0], [83.7, 373.0], [83.8, 375.0], [83.9, 378.0], [84.0, 381.0], [84.1, 383.0], [84.2, 388.0], [84.3, 390.0], [84.4, 395.0], [84.5, 398.0], [84.6, 401.0], [84.7, 404.0], [84.8, 410.0], [84.9, 413.0], [85.0, 416.0], [85.1, 418.0], [85.2, 419.0], [85.3, 426.0], [85.4, 427.0], [85.5, 429.0], [85.6, 432.0], [85.7, 436.0], [85.8, 440.0], [85.9, 443.0], [86.0, 444.0], [86.1, 448.0], [86.2, 450.0], [86.3, 454.0], [86.4, 458.0], [86.5, 458.0], [86.6, 460.0], [86.7, 464.0], [86.8, 465.0], [86.9, 468.0], [87.0, 468.0], [87.1, 472.0], [87.2, 474.0], [87.3, 478.0], [87.4, 486.0], [87.5, 489.0], [87.6, 497.0], [87.7, 504.0], [87.8, 514.0], [87.9, 516.0], [88.0, 519.0], [88.1, 523.0], [88.2, 528.0], [88.3, 531.0], [88.4, 535.0], [88.5, 541.0], [88.6, 546.0], [88.7, 549.0], [88.8, 553.0], [88.9, 560.0], [89.0, 563.0], [89.1, 569.0], [89.2, 576.0], [89.3, 584.0], [89.4, 589.0], [89.5, 596.0], [89.6, 600.0], [89.7, 602.0], [89.8, 612.0], [89.9, 619.0], [90.0, 625.0], [90.1, 627.0], [90.2, 631.0], [90.3, 639.0], [90.4, 653.0], [90.5, 659.0], [90.6, 665.0], [90.7, 674.0], [90.8, 679.0], [90.9, 690.0], [91.0, 703.0], [91.1, 718.0], [91.2, 732.0], [91.3, 750.0], [91.4, 763.0], [91.5, 776.0], [91.6, 793.0], [91.7, 796.0], [91.8, 801.0], [91.9, 810.0], [92.0, 818.0], [92.1, 834.0], [92.2, 842.0], [92.3, 853.0], [92.4, 892.0], [92.5, 921.0], [92.6, 922.0], [92.7, 948.0], [92.8, 1002.0], [92.9, 1039.0], [93.0, 1090.0], [93.1, 1136.0], [93.2, 1171.0], [93.3, 1202.0], [93.4, 1220.0], [93.5, 1229.0], [93.6, 1300.0], [93.7, 1318.0], [93.8, 1376.0], [93.9, 1395.0], [94.0, 1480.0], [94.1, 1550.0], [94.2, 1595.0], [94.3, 1638.0], [94.4, 1714.0], [94.5, 1759.0], [94.6, 1803.0], [94.7, 1842.0], [94.8, 1866.0], [94.9, 1899.0], [95.0, 1999.0], [95.1, 2095.0], [95.2, 2167.0], [95.3, 2293.0], [95.4, 2475.0], [95.5, 2644.0], [95.6, 2688.0], [95.7, 2749.0], [95.8, 2782.0], [95.9, 2791.0], [96.0, 2808.0], [96.1, 2835.0], [96.2, 2876.0], [96.3, 2909.0], [96.4, 2945.0], [96.5, 3000.0], [96.6, 3029.0], [96.7, 3087.0], [96.8, 3102.0], [96.9, 3116.0], [97.0, 3173.0], [97.1, 3209.0], [97.2, 3260.0], [97.3, 3298.0], [97.4, 3336.0], [97.5, 3369.0], [97.6, 3409.0], [97.7, 3455.0], [97.8, 3475.0], [97.9, 3495.0], [98.0, 3515.0], [98.1, 3542.0], [98.2, 3555.0], [98.3, 3582.0], [98.4, 3636.0], [98.5, 3684.0], [98.6, 3758.0], [98.7, 3825.0], [98.8, 3875.0], [98.9, 3974.0], [99.0, 4017.0], [99.1, 4117.0], [99.2, 4270.0], [99.3, 4889.0], [99.4, 5186.0], [99.5, 5268.0], [99.6, 5748.0], [99.7, 6131.0], [99.8, 6626.0], [99.9, 6995.0]], "isOverall": false, "label": "GET - List Orders Direct Azure", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 100.0, "maxY": 3072.0, "series": [{"data": [[600.0, 73.0], [700.0, 41.0], [800.0, 34.0], [900.0, 18.0], [1000.0, 12.0], [1100.0, 15.0], [1200.0, 15.0], [1300.0, 18.0], [1400.0, 5.0], [1500.0, 9.0], [1600.0, 9.0], [1700.0, 11.0], [1800.0, 16.0], [1900.0, 6.0], [2000.0, 5.0], [2100.0, 5.0], [2200.0, 5.0], [2300.0, 3.0], [2400.0, 2.0], [2500.0, 5.0], [2600.0, 6.0], [2700.0, 18.0], [2800.0, 15.0], [2900.0, 12.0], [3000.0, 15.0], [3100.0, 15.0], [3300.0, 14.0], [3200.0, 13.0], [3400.0, 19.0], [3500.0, 20.0], [3600.0, 9.0], [3700.0, 8.0], [3800.0, 10.0], [3900.0, 7.0], [4000.0, 5.0], [4100.0, 4.0], [4200.0, 2.0], [4300.0, 3.0], [4600.0, 1.0], [4800.0, 1.0], [4900.0, 2.0], [5000.0, 2.0], [5100.0, 2.0], [5200.0, 8.0], [5500.0, 1.0], [5700.0, 2.0], [6000.0, 2.0], [6100.0, 2.0], [6300.0, 1.0], [6400.0, 1.0], [6500.0, 1.0], [6600.0, 3.0], [6700.0, 1.0], [6800.0, 2.0], [6900.0, 1.0], [7000.0, 5.0], [100.0, 3072.0], [200.0, 1066.0], [300.0, 241.0], [400.0, 159.0], [500.0, 99.0]], "isOverall": false, "label": "GET - List Orders Direct Azure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 7000.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 71.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 4539.0, "series": [{"data": [[0.0, 4539.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 328.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [[2.0, 239.0]], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [[3.0, 71.0]], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 3.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 28.59649122807017, "minX": 1.792312005E12, "maxY": 50.0, "series": [{"data": [[1.79231209E12, 50.0], [1.792312005E12, 50.0], [1.79231213E12, 50.0], [1.792312045E12, 50.0], [1.792312095E12, 50.0], [1.79231201E12, 50.0], [1.792312135E12, 50.0], [1.79231205E12, 50.0], [1.792312015E12, 50.0], [1.7923121E12, 50.0], [1.792312055E12, 50.0], [1.79231214E12, 50.0], [1.79231202E12, 50.0], [1.792312105E12, 50.0], [1.79231206E12, 50.0], [1.792312145E12, 50.0], [1.792312025E12, 50.0], [1.79231211E12, 50.0], [1.792312065E12, 50.0], [1.79231215E12, 50.0], [1.79231203E12, 50.0], [1.792312115E12, 50.0], [1.79231207E12, 50.0], [1.792312155E12, 28.59649122807017], [1.792312035E12, 50.0], [1.79231208E12, 50.0], [1.792312075E12, 50.0], [1.79231212E12, 50.0], [1.792312085E12, 50.0], [1.792312125E12, 50.0], [1.79231204E12, 50.0]], "isOverall": false, "label": "Thread Group", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.792312155E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 124.0, "minX": 1.0, "maxY": 421.8439937597502, "series": [{"data": [[33.0, 159.0], [32.0, 177.0], [2.0, 157.0], [35.0, 129.0], [34.0, 135.0], [37.0, 159.0], [36.0, 160.0], [41.0, 186.0], [40.0, 160.0], [43.0, 177.0], [42.0, 182.0], [45.0, 166.0], [44.0, 151.0], [47.0, 176.0], [46.0, 162.0], [49.0, 161.0], [48.0, 171.0], [3.0, 157.0], [50.0, 421.8439937597502], [4.0, 136.0], [5.0, 133.0], [6.0, 124.0], [7.0, 136.0], [8.0, 154.0], [9.0, 145.0], [10.0, 139.0], [11.0, 150.0], [12.0, 174.0], [13.0, 165.0], [14.0, 167.0], [15.0, 156.0], [16.0, 174.0], [1.0, 162.0], [17.0, 141.0], [18.0, 149.0], [19.0, 140.0], [20.0, 143.0], [21.0, 165.0], [22.0, 160.0], [23.0, 151.0], [24.0, 166.0], [25.0, 138.0], [26.0, 141.0], [28.0, 163.5], [29.0, 139.0], [30.0, 196.0]], "isOverall": false, "label": "GET - List Orders Direct Azure", "isController": false}, {"data": [[49.764342283175594, 419.3372609619469]], "isOverall": false, "label": "GET - List Orders Direct Azure-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 50.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 14720.4, "minX": 1.792312005E12, "maxY": 324339.6, "series": [{"data": [[1.79231209E12, 277377.8], [1.792312005E12, 96861.6], [1.79231213E12, 311132.6], [1.792312045E12, 245090.6], [1.792312095E12, 104199.6], [1.79231201E12, 324339.6], [1.792312135E12, 308196.0], [1.79231205E12, 294989.0], [1.792312015E12, 157033.2], [1.7923121E12, 294987.6], [1.792312055E12, 303793.2], [1.79231214E12, 293521.4], [1.79231202E12, 20643.6], [1.792312105E12, 286182.0], [1.79231206E12, 271507.4], [1.792312145E12, 300858.0], [1.792312025E12, 70158.0], [1.79231211E12, 308200.2], [1.792312065E12, 299394.6], [1.79231215E12, 297925.6], [1.79231203E12, 103323.8], [1.792312115E12, 270038.4], [1.79231207E12, 312600.2], [1.792312155E12, 83653.2], [1.792312035E12, 87180.2], [1.79231208E12, 308198.8], [1.792312075E12, 305260.8], [1.79231212E12, 278844.0], [1.792312085E12, 318469.2], [1.792312125E12, 311132.6], [1.79231204E12, 254191.4]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.79231209E12, 59194.8], [1.792312005E12, 20671.2], [1.79231213E12, 66398.4], [1.792312045E12, 52304.4], [1.792312095E12, 22237.2], [1.79231201E12, 69217.2], [1.792312135E12, 65772.0], [1.79231205E12, 62953.2], [1.792312015E12, 33512.4], [1.7923121E12, 62953.2], [1.792312055E12, 64832.4], [1.79231214E12, 62640.0], [1.79231202E12, 14720.4], [1.792312105E12, 61074.0], [1.79231206E12, 57942.0], [1.792312145E12, 64206.0], [1.792312025E12, 19731.6], [1.79231211E12, 65772.0], [1.792312065E12, 63892.8], [1.79231215E12, 63579.6], [1.79231203E12, 24429.6], [1.792312115E12, 57628.8], [1.79231207E12, 66711.6], [1.792312155E12, 17852.4], [1.792312035E12, 20984.4], [1.79231208E12, 65772.0], [1.792312075E12, 65145.6], [1.79231212E12, 59508.0], [1.792312085E12, 67964.4], [1.792312125E12, 66398.4], [1.79231204E12, 55436.4]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.792312155E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 145.2878787878788, "minX": 1.792312005E12, "maxY": 4501.666666666665, "series": [{"data": [[1.79231209E12, 278.5185185185185], [1.792312005E12, 145.2878787878788], [1.79231213E12, 225.8349056603773], [1.792312045E12, 456.40119760479035], [1.792312095E12, 1826.9154929577464], [1.79231201E12, 172.6651583710406], [1.792312135E12, 174.3142857142856], [1.79231205E12, 258.97512437810934], [1.792312015E12, 288.5700934579438], [1.7923121E12, 534.8358208955229], [1.792312055E12, 230.85024154589385], [1.79231214E12, 218.87499999999991], [1.79231202E12, 3262.574468085106], [1.792312105E12, 230.36923076923065], [1.79231206E12, 333.6594594594594], [1.792312145E12, 169.55121951219516], [1.792312025E12, 4501.666666666665], [1.79231211E12, 210.44761904761904], [1.792312065E12, 199.21568627450984], [1.79231215E12, 219.48768472906406], [1.79231203E12, 2204.4102564102554], [1.792312115E12, 300.461956521739], [1.79231207E12, 199.85446009389676], [1.792312155E12, 156.70175438596485], [1.792312035E12, 2500.597014925373], [1.79231208E12, 171.4952380952381], [1.792312075E12, 161.71634615384608], [1.79231212E12, 263.5894736842105], [1.792312085E12, 162.1935483870967], [1.792312125E12, 229.16981132075463], [1.79231204E12, 794.2824858757059]], "isOverall": false, "label": "GET - List Orders Direct Azure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.792312155E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 141.40909090909088, "minX": 1.792312005E12, "maxY": 4497.3650793650795, "series": [{"data": [[1.79231209E12, 249.00529100529116], [1.792312005E12, 141.40909090909088], [1.79231213E12, 210.0377358490565], [1.792312045E12, 446.5149700598802], [1.792312095E12, 1662.5915492957754], [1.79231201E12, 166.1538461538461], [1.792312135E12, 168.48095238095232], [1.79231205E12, 253.6815920398011], [1.792312015E12, 285.03738317757006], [1.7923121E12, 473.89054726368175], [1.792312055E12, 226.7681159420289], [1.79231214E12, 212.82999999999998], [1.79231202E12, 3240.2765957446813], [1.792312105E12, 223.08205128205128], [1.79231206E12, 322.0810810810813], [1.792312145E12, 162.30243902439028], [1.792312025E12, 4497.3650793650795], [1.79231211E12, 198.76666666666654], [1.792312065E12, 193.36764705882348], [1.79231215E12, 206.4137931034481], [1.79231203E12, 2186.8461538461534], [1.792312115E12, 267.8749999999999], [1.79231207E12, 193.52582159624416], [1.792312155E12, 152.78947368421052], [1.792312035E12, 2497.3283582089553], [1.79231208E12, 160.67142857142858], [1.792312075E12, 158.31730769230776], [1.79231212E12, 250.4421052631579], [1.792312085E12, 157.14746543778807], [1.792312125E12, 215.3632075471698], [1.79231204E12, 789.5480225988701]], "isOverall": false, "label": "GET - List Orders Direct Azure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.792312155E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 0.0, "minX": 1.792312005E12, "maxY": 50.23728813559324, "series": [{"data": [[1.79231209E12, 0.0], [1.792312005E12, 0.0], [1.79231213E12, 0.0], [1.792312045E12, 25.61077844311377], [1.792312095E12, 0.0], [1.79231201E12, 0.0], [1.792312135E12, 0.0], [1.79231205E12, 0.0], [1.792312015E12, 0.0], [1.7923121E12, 47.48756218905472], [1.792312055E12, 0.0], [1.79231214E12, 0.0], [1.79231202E12, 0.0], [1.792312105E12, 27.651282051282045], [1.79231206E12, 0.0], [1.792312145E12, 0.0], [1.792312025E12, 0.0], [1.79231211E12, 0.0], [1.792312065E12, 0.0], [1.79231215E12, 0.0], [1.79231203E12, 0.0], [1.792312115E12, 0.0], [1.79231207E12, 0.0], [1.792312155E12, 0.0], [1.792312035E12, 0.0], [1.79231208E12, 0.0], [1.792312075E12, 0.0], [1.79231212E12, 0.0], [1.792312085E12, 0.0], [1.792312125E12, 0.0], [1.79231204E12, 50.23728813559324]], "isOverall": false, "label": "GET - List Orders Direct Azure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.792312155E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 111.0, "minX": 1.792312005E12, "maxY": 7054.0, "series": [{"data": [[1.79231209E12, 2644.0], [1.792312005E12, 190.0], [1.79231213E12, 2713.0], [1.792312045E12, 2167.0], [1.792312095E12, 3317.0], [1.79231201E12, 720.0], [1.792312135E12, 331.0], [1.79231205E12, 631.0], [1.792312015E12, 1714.0], [1.7923121E12, 5293.0], [1.792312055E12, 673.0], [1.79231214E12, 1485.0], [1.79231202E12, 3244.0], [1.792312105E12, 848.0], [1.79231206E12, 1187.0], [1.792312145E12, 521.0], [1.792312025E12, 7054.0], [1.79231211E12, 1538.0], [1.792312065E12, 859.0], [1.79231215E12, 1394.0], [1.79231203E12, 4310.0], [1.792312115E12, 1666.0], [1.79231207E12, 639.0], [1.792312155E12, 196.0], [1.792312035E12, 4622.0], [1.79231208E12, 1081.0], [1.792312075E12, 587.0], [1.79231212E12, 1395.0], [1.792312085E12, 1010.0], [1.792312125E12, 1813.0], [1.79231204E12, 4128.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.79231209E12, 121.0], [1.792312005E12, 118.0], [1.79231213E12, 118.0], [1.792312045E12, 139.0], [1.792312095E12, 308.0], [1.79231201E12, 115.0], [1.792312135E12, 116.0], [1.79231205E12, 125.0], [1.792312015E12, 117.0], [1.7923121E12, 122.0], [1.792312055E12, 129.0], [1.79231214E12, 116.0], [1.79231202E12, 1550.0], [1.792312105E12, 115.0], [1.79231206E12, 131.0], [1.792312145E12, 119.0], [1.792312025E12, 443.0], [1.79231211E12, 119.0], [1.792312065E12, 130.0], [1.79231215E12, 118.0], [1.79231203E12, 291.0], [1.792312115E12, 121.0], [1.79231207E12, 117.0], [1.792312155E12, 124.0], [1.792312035E12, 286.0], [1.79231208E12, 115.0], [1.792312075E12, 118.0], [1.79231212E12, 117.0], [1.792312085E12, 119.0], [1.792312125E12, 111.0], [1.79231204E12, 126.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.79231209E12, 464.0], [1.792312005E12, 166.3], [1.79231213E12, 251.80000000000007], [1.792312045E12, 806.0], [1.792312095E12, 3116.0], [1.79231201E12, 200.0], [1.792312135E12, 225.8], [1.79231205E12, 390.40000000000003], [1.792312015E12, 531.4000000000001], [1.7923121E12, 497.8000000000001], [1.792312055E12, 321.6], [1.79231214E12, 287.5], [1.79231202E12, 3031.000000000001], [1.792312105E12, 448.4], [1.79231206E12, 611.2], [1.792312145E12, 199.0], [1.792312025E12, 6883.200000000001], [1.79231211E12, 260.70000000000005], [1.792312065E12, 263.5], [1.79231215E12, 235.0], [1.79231203E12, 3536.4], [1.792312115E12, 806.5], [1.79231207E12, 296.0], [1.792312155E12, 177.0], [1.792312035E12, 3994.0], [1.79231208E12, 217.8], [1.792312075E12, 194.2], [1.79231212E12, 398.0], [1.792312085E12, 194.20000000000002], [1.792312125E12, 248.70000000000002], [1.79231204E12, 2768.0]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.79231209E12, 2149.899999999997], [1.792312005E12, 190.0], [1.79231213E12, 1313.7], [1.792312045E12, 2161.56], [1.792312095E12, 3317.0], [1.79231201E12, 631.94], [1.792312135E12, 314.40999999999906], [1.79231205E12, 613.8199999999999], [1.792312015E12, 1705.8400000000001], [1.7923121E12, 5289.9], [1.792312055E12, 617.7199999999985], [1.79231214E12, 1297.7200000000048], [1.79231202E12, 3244.0], [1.792312105E12, 708.7999999999988], [1.79231206E12, 1165.4999999999995], [1.792312145E12, 497.19999999999993], [1.792312025E12, 7054.0], [1.79231211E12, 1358.4799999999914], [1.792312065E12, 366.4499999999999], [1.79231215E12, 1031.8000000000009], [1.79231203E12, 4310.0], [1.792312115E12, 1564.8500000000006], [1.79231207E12, 627.5799999999999], [1.792312155E12, 196.0], [1.792312035E12, 4622.0], [1.79231208E12, 517.4799999999996], [1.792312075E12, 282.73], [1.79231212E12, 1005.5200000000015], [1.792312085E12, 582.5799999999981], [1.792312125E12, 1707.3300000000027], [1.79231204E12, 3437.5799999999917]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.79231209E12, 168.0], [1.792312005E12, 142.0], [1.79231213E12, 164.5], [1.792312045E12, 382.0], [1.792312095E12, 1803.0], [1.79231201E12, 158.0], [1.792312135E12, 163.0], [1.79231205E12, 235.0], [1.792312015E12, 165.0], [1.7923121E12, 273.0], [1.792312055E12, 206.0], [1.79231214E12, 199.0], [1.79231202E12, 1899.5], [1.792312105E12, 175.0], [1.79231206E12, 245.0], [1.792312145E12, 161.0], [1.792312025E12, 3990.0], [1.79231211E12, 179.0], [1.792312065E12, 183.0], [1.79231215E12, 174.0], [1.79231203E12, 2077.5], [1.792312115E12, 183.5], [1.79231207E12, 171.0], [1.792312155E12, 157.0], [1.792312035E12, 2439.0], [1.79231208E12, 155.0], [1.792312075E12, 153.0], [1.79231212E12, 219.0], [1.792312085E12, 150.0], [1.792312125E12, 174.0], [1.79231204E12, 351.0]], "isOverall": false, "label": "Median", "isController": false}, {"data": [[1.79231209E12, 922.0], [1.792312005E12, 172.65], [1.79231213E12, 467.5499999999971], [1.792312045E12, 1015.9999999999993], [1.792312095E12, 3184.5999999999995], [1.79231201E12, 254.89999999999975], [1.792312135E12, 233.0], [1.79231205E12, 456.9], [1.792312015E12, 1323.799999999999], [1.7923121E12, 4855.299999999925], [1.792312055E12, 439.6], [1.79231214E12, 349.29999999999984], [1.79231202E12, 3244.0], [1.792312105E12, 622.7999999999998], [1.79231206E12, 751.299999999999], [1.792312145E12, 230.49999999999983], [1.792312025E12, 7040.8], [1.79231211E12, 347.34999999999974], [1.792312065E12, 289.5], [1.79231215E12, 745.1999999999995], [1.79231203E12, 3714.6000000000004], [1.792312115E12, 934.0], [1.79231207E12, 376.99999999999915], [1.792312155E12, 186.89999999999995], [1.792312035E12, 4077.0], [1.79231208E12, 263.24999999999994], [1.792312075E12, 240.09999999999997], [1.79231212E12, 499.09999999999934], [1.792312085E12, 204.1], [1.792312125E12, 416.9999999999977], [1.79231204E12, 2939.2]], "isOverall": false, "label": "95th percentile", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.792312155E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 151.0, "minX": 4.0, "maxY": 5572.5, "series": [{"data": [[33.0, 156.0], [32.0, 177.0], [34.0, 199.0], [35.0, 191.0], [37.0, 174.0], [36.0, 1720.0], [39.0, 156.5], [38.0, 304.0], [41.0, 174.5], [40.0, 187.5], [42.0, 183.0], [43.0, 192.5], [44.0, 173.0], [45.0, 159.0], [47.0, 153.0], [46.0, 171.0], [49.0, 180.0], [48.0, 160.5], [50.0, 197.0], [4.0, 3096.0], [5.0, 662.0], [9.0, 3520.0], [10.0, 400.0], [11.0, 1726.5], [12.0, 2856.5], [13.0, 3433.0], [14.0, 3218.0], [15.0, 5572.5], [16.0, 1393.0], [18.0, 1014.5], [19.0, 254.5], [20.0, 3273.5], [23.0, 1947.0], [24.0, 550.5], [25.0, 304.5], [26.0, 589.0], [27.0, 151.0], [29.0, 157.0], [30.0, 264.0], [31.0, 221.0]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[36.0, 3546.0], [9.0, 3114.0], [11.0, 2390.0], [13.0, 3560.0], [14.0, 1670.0], [15.0, 4098.0], [4.0, 4919.0], [16.0, 3351.0], [5.0, 4186.0], [20.0, 3612.0], [23.0, 2057.0], [7.0, 3409.0], [30.0, 852.0]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 50.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 148.0, "minX": 4.0, "maxY": 5544.0, "series": [{"data": [[33.0, 152.0], [32.0, 176.5], [34.0, 183.0], [35.0, 188.0], [37.0, 168.0], [36.0, 1599.0], [39.0, 154.0], [38.0, 249.5], [41.0, 170.0], [40.0, 185.0], [42.0, 179.5], [43.0, 191.0], [44.0, 168.0], [45.0, 155.0], [47.0, 149.0], [46.0, 167.0], [49.0, 177.0], [48.0, 155.5], [50.0, 193.0], [4.0, 3061.0], [5.0, 662.0], [9.0, 3516.0], [10.0, 397.5], [11.0, 1726.0], [12.0, 2856.0], [13.0, 3431.5], [14.0, 3216.0], [15.0, 5544.0], [16.0, 1347.0], [18.0, 990.0], [19.0, 245.5], [20.0, 3272.0], [23.0, 1945.5], [24.0, 549.0], [25.0, 301.0], [26.0, 436.0], [27.0, 148.0], [29.0, 156.0], [30.0, 254.0], [31.0, 216.0]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[36.0, 3546.0], [9.0, 3114.0], [11.0, 2390.0], [13.0, 3560.0], [14.0, 1670.0], [15.0, 4098.0], [4.0, 4919.0], [16.0, 3351.0], [5.0, 4186.0], [20.0, 3612.0], [23.0, 2057.0], [7.0, 3408.0], [30.0, 852.0]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 50.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 8.6, "minX": 1.792312005E12, "maxY": 44.4, "series": [{"data": [[1.79231209E12, 38.6], [1.792312005E12, 15.4], [1.79231213E12, 40.8], [1.792312045E12, 35.0], [1.792312095E12, 16.4], [1.79231201E12, 42.6], [1.792312135E12, 43.0], [1.79231205E12, 38.2], [1.792312015E12, 30.8], [1.7923121E12, 36.2], [1.792312055E12, 40.2], [1.79231214E12, 39.8], [1.79231202E12, 8.6], [1.792312105E12, 41.4], [1.79231206E12, 37.2], [1.792312145E12, 40.4], [1.792312025E12, 9.4], [1.79231211E12, 40.4], [1.792312065E12, 42.6], [1.79231215E12, 42.8], [1.79231203E12, 15.6], [1.792312115E12, 37.2], [1.79231207E12, 40.8], [1.792312155E12, 8.8], [1.792312035E12, 15.2], [1.79231208E12, 42.0], [1.792312075E12, 42.2], [1.79231212E12, 39.8], [1.792312085E12, 44.4], [1.792312125E12, 40.4], [1.79231204E12, 29.2]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.792312155E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 0.6, "minX": 1.792312005E12, "maxY": 44.2, "series": [{"data": [[1.79231209E12, 37.8], [1.792312005E12, 13.2], [1.79231213E12, 42.4], [1.792312045E12, 33.4], [1.792312095E12, 14.2], [1.79231201E12, 44.2], [1.792312135E12, 42.0], [1.79231205E12, 40.2], [1.792312015E12, 21.4], [1.7923121E12, 40.2], [1.792312055E12, 41.4], [1.79231214E12, 40.0], [1.79231202E12, 2.4], [1.792312105E12, 39.0], [1.79231206E12, 37.0], [1.792312145E12, 41.0], [1.792312025E12, 9.4], [1.79231211E12, 42.0], [1.792312065E12, 40.8], [1.79231215E12, 40.6], [1.79231203E12, 14.0], [1.792312115E12, 36.8], [1.79231207E12, 42.6], [1.792312155E12, 11.4], [1.792312035E12, 11.8], [1.79231208E12, 42.0], [1.792312075E12, 41.6], [1.79231212E12, 38.0], [1.792312085E12, 43.4], [1.792312125E12, 42.4], [1.79231204E12, 34.6]], "isOverall": false, "label": "200", "isController": false}, {"data": [[1.792312035E12, 1.6], [1.792312025E12, 3.2], [1.79231203E12, 1.6], [1.79231202E12, 0.6], [1.79231204E12, 0.8]], "isOverall": false, "label": "500", "isController": false}, {"data": [[1.79231202E12, 6.4]], "isOverall": false, "label": "503", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.792312155E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 0.8, "minX": 1.792312005E12, "maxY": 44.2, "series": [{"data": [[1.792312035E12, 1.6], [1.792312025E12, 3.2], [1.79231203E12, 1.6], [1.79231202E12, 7.0], [1.79231204E12, 0.8]], "isOverall": false, "label": "GET - List Orders Direct Azure-failure", "isController": false}, {"data": [[1.79231209E12, 37.8], [1.792312005E12, 13.2], [1.79231213E12, 42.4], [1.792312045E12, 33.4], [1.792312095E12, 14.2], [1.79231201E12, 44.2], [1.792312135E12, 42.0], [1.79231205E12, 40.2], [1.792312015E12, 21.4], [1.7923121E12, 40.2], [1.792312055E12, 41.4], [1.79231214E12, 40.0], [1.79231202E12, 2.4], [1.792312105E12, 39.0], [1.79231206E12, 37.0], [1.792312145E12, 41.0], [1.792312025E12, 9.4], [1.79231211E12, 42.0], [1.792312065E12, 40.8], [1.79231215E12, 40.6], [1.79231203E12, 14.0], [1.792312115E12, 36.8], [1.79231207E12, 42.6], [1.792312155E12, 11.4], [1.792312035E12, 11.8], [1.79231208E12, 42.0], [1.792312075E12, 41.6], [1.79231212E12, 38.0], [1.792312085E12, 43.4], [1.792312125E12, 42.4], [1.79231204E12, 34.6]], "isOverall": false, "label": "GET - List Orders Direct Azure-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.792312155E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 0.8, "minX": 1.792312005E12, "maxY": 44.2, "series": [{"data": [[1.79231209E12, 37.8], [1.792312005E12, 13.2], [1.79231213E12, 42.4], [1.792312045E12, 33.4], [1.792312095E12, 14.2], [1.79231201E12, 44.2], [1.792312135E12, 42.0], [1.79231205E12, 40.2], [1.792312015E12, 21.4], [1.7923121E12, 40.2], [1.792312055E12, 41.4], [1.79231214E12, 40.0], [1.79231202E12, 2.4], [1.792312105E12, 39.0], [1.79231206E12, 37.0], [1.792312145E12, 41.0], [1.792312025E12, 9.4], [1.79231211E12, 42.0], [1.792312065E12, 40.8], [1.79231215E12, 40.6], [1.79231203E12, 14.0], [1.792312115E12, 36.8], [1.79231207E12, 42.6], [1.792312155E12, 11.4], [1.792312035E12, 11.8], [1.79231208E12, 42.0], [1.792312075E12, 41.6], [1.79231212E12, 38.0], [1.792312085E12, 43.4], [1.792312125E12, 42.4], [1.79231204E12, 34.6]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [[1.792312035E12, 1.6], [1.792312025E12, 3.2], [1.79231203E12, 1.6], [1.79231202E12, 7.0], [1.79231204E12, 0.8]], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.792312155E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

