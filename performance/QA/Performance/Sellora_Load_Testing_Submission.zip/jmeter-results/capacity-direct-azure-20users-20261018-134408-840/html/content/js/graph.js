/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 112.0, "minX": 0.0, "maxY": 2094.0, "series": [{"data": [[0.0, 112.0], [0.1, 114.0], [0.2, 115.0], [0.3, 116.0], [0.4, 117.0], [0.5, 118.0], [0.6, 118.0], [0.7, 119.0], [0.8, 119.0], [0.9, 119.0], [1.0, 120.0], [1.1, 120.0], [1.2, 121.0], [1.3, 121.0], [1.4, 121.0], [1.5, 121.0], [1.6, 121.0], [1.7, 122.0], [1.8, 122.0], [1.9, 122.0], [2.0, 122.0], [2.1, 122.0], [2.2, 122.0], [2.3, 123.0], [2.4, 123.0], [2.5, 123.0], [2.6, 123.0], [2.7, 124.0], [2.8, 124.0], [2.9, 124.0], [3.0, 124.0], [3.1, 124.0], [3.2, 125.0], [3.3, 125.0], [3.4, 125.0], [3.5, 125.0], [3.6, 125.0], [3.7, 125.0], [3.8, 126.0], [3.9, 126.0], [4.0, 126.0], [4.1, 126.0], [4.2, 126.0], [4.3, 126.0], [4.4, 127.0], [4.5, 127.0], [4.6, 127.0], [4.7, 127.0], [4.8, 127.0], [4.9, 127.0], [5.0, 127.0], [5.1, 127.0], [5.2, 128.0], [5.3, 128.0], [5.4, 128.0], [5.5, 128.0], [5.6, 128.0], [5.7, 128.0], [5.8, 128.0], [5.9, 128.0], [6.0, 128.0], [6.1, 128.0], [6.2, 128.0], [6.3, 128.0], [6.4, 128.0], [6.5, 129.0], [6.6, 129.0], [6.7, 129.0], [6.8, 129.0], [6.9, 129.0], [7.0, 129.0], [7.1, 129.0], [7.2, 129.0], [7.3, 129.0], [7.4, 129.0], [7.5, 129.0], [7.6, 130.0], [7.7, 130.0], [7.8, 130.0], [7.9, 130.0], [8.0, 130.0], [8.1, 130.0], [8.2, 130.0], [8.3, 130.0], [8.4, 130.0], [8.5, 130.0], [8.6, 131.0], [8.7, 131.0], [8.8, 131.0], [8.9, 131.0], [9.0, 131.0], [9.1, 131.0], [9.2, 131.0], [9.3, 131.0], [9.4, 131.0], [9.5, 131.0], [9.6, 131.0], [9.7, 132.0], [9.8, 132.0], [9.9, 132.0], [10.0, 132.0], [10.1, 132.0], [10.2, 132.0], [10.3, 132.0], [10.4, 132.0], [10.5, 132.0], [10.6, 132.0], [10.7, 132.0], [10.8, 132.0], [10.9, 133.0], [11.0, 133.0], [11.1, 133.0], [11.2, 133.0], [11.3, 133.0], [11.4, 133.0], [11.5, 133.0], [11.6, 133.0], [11.7, 133.0], [11.8, 133.0], [11.9, 133.0], [12.0, 133.0], [12.1, 133.0], [12.2, 133.0], [12.3, 133.0], [12.4, 133.0], [12.5, 133.0], [12.6, 133.0], [12.7, 133.0], [12.8, 134.0], [12.9, 134.0], [13.0, 134.0], [13.1, 134.0], [13.2, 134.0], [13.3, 134.0], [13.4, 134.0], [13.5, 134.0], [13.6, 134.0], [13.7, 134.0], [13.8, 134.0], [13.9, 134.0], [14.0, 134.0], [14.1, 134.0], [14.2, 135.0], [14.3, 135.0], [14.4, 135.0], [14.5, 135.0], [14.6, 135.0], [14.7, 135.0], [14.8, 135.0], [14.9, 135.0], [15.0, 135.0], [15.1, 135.0], [15.2, 135.0], [15.3, 135.0], [15.4, 135.0], [15.5, 135.0], [15.6, 135.0], [15.7, 135.0], [15.8, 135.0], [15.9, 135.0], [16.0, 135.0], [16.1, 136.0], [16.2, 136.0], [16.3, 136.0], [16.4, 136.0], [16.5, 136.0], [16.6, 136.0], [16.7, 136.0], [16.8, 136.0], [16.9, 136.0], [17.0, 136.0], [17.1, 136.0], [17.2, 136.0], [17.3, 136.0], [17.4, 136.0], [17.5, 136.0], [17.6, 136.0], [17.7, 136.0], [17.8, 136.0], [17.9, 136.0], [18.0, 137.0], [18.1, 137.0], [18.2, 137.0], [18.3, 137.0], [18.4, 137.0], [18.5, 137.0], [18.6, 137.0], [18.7, 137.0], [18.8, 137.0], [18.9, 137.0], [19.0, 137.0], [19.1, 137.0], [19.2, 137.0], [19.3, 137.0], [19.4, 137.0], [19.5, 138.0], [19.6, 138.0], [19.7, 138.0], [19.8, 138.0], [19.9, 138.0], [20.0, 138.0], [20.1, 138.0], [20.2, 138.0], [20.3, 138.0], [20.4, 138.0], [20.5, 138.0], [20.6, 138.0], [20.7, 138.0], [20.8, 138.0], [20.9, 138.0], [21.0, 139.0], [21.1, 139.0], [21.2, 139.0], [21.3, 139.0], [21.4, 139.0], [21.5, 139.0], [21.6, 139.0], [21.7, 139.0], [21.8, 139.0], [21.9, 139.0], [22.0, 139.0], [22.1, 139.0], [22.2, 139.0], [22.3, 139.0], [22.4, 139.0], [22.5, 139.0], [22.6, 139.0], [22.7, 139.0], [22.8, 139.0], [22.9, 140.0], [23.0, 140.0], [23.1, 140.0], [23.2, 140.0], [23.3, 140.0], [23.4, 140.0], [23.5, 140.0], [23.6, 140.0], [23.7, 140.0], [23.8, 140.0], [23.9, 140.0], [24.0, 140.0], [24.1, 140.0], [24.2, 140.0], [24.3, 140.0], [24.4, 140.0], [24.5, 140.0], [24.6, 141.0], [24.7, 141.0], [24.8, 141.0], [24.9, 141.0], [25.0, 141.0], [25.1, 141.0], [25.2, 141.0], [25.3, 141.0], [25.4, 141.0], [25.5, 141.0], [25.6, 141.0], [25.7, 141.0], [25.8, 141.0], [25.9, 141.0], [26.0, 141.0], [26.1, 141.0], [26.2, 142.0], [26.3, 142.0], [26.4, 142.0], [26.5, 142.0], [26.6, 142.0], [26.7, 142.0], [26.8, 142.0], [26.9, 142.0], [27.0, 142.0], [27.1, 142.0], [27.2, 142.0], [27.3, 142.0], [27.4, 142.0], [27.5, 142.0], [27.6, 142.0], [27.7, 142.0], [27.8, 142.0], [27.9, 142.0], [28.0, 143.0], [28.1, 143.0], [28.2, 143.0], [28.3, 143.0], [28.4, 143.0], [28.5, 143.0], [28.6, 143.0], [28.7, 143.0], [28.8, 143.0], [28.9, 143.0], [29.0, 143.0], [29.1, 143.0], [29.2, 143.0], [29.3, 143.0], [29.4, 143.0], [29.5, 143.0], [29.6, 143.0], [29.7, 143.0], [29.8, 143.0], [29.9, 144.0], [30.0, 144.0], [30.1, 144.0], [30.2, 144.0], [30.3, 144.0], [30.4, 144.0], [30.5, 144.0], [30.6, 144.0], [30.7, 144.0], [30.8, 144.0], [30.9, 144.0], [31.0, 144.0], [31.1, 144.0], [31.2, 144.0], [31.3, 144.0], [31.4, 144.0], [31.5, 145.0], [31.6, 145.0], [31.7, 145.0], [31.8, 145.0], [31.9, 145.0], [32.0, 145.0], [32.1, 145.0], [32.2, 145.0], [32.3, 145.0], [32.4, 145.0], [32.5, 145.0], [32.6, 145.0], [32.7, 145.0], [32.8, 145.0], [32.9, 145.0], [33.0, 145.0], [33.1, 146.0], [33.2, 146.0], [33.3, 146.0], [33.4, 146.0], [33.5, 146.0], [33.6, 146.0], [33.7, 146.0], [33.8, 146.0], [33.9, 146.0], [34.0, 146.0], [34.1, 146.0], [34.2, 146.0], [34.3, 146.0], [34.4, 146.0], [34.5, 147.0], [34.6, 147.0], [34.7, 147.0], [34.8, 147.0], [34.9, 147.0], [35.0, 147.0], [35.1, 147.0], [35.2, 147.0], [35.3, 147.0], [35.4, 147.0], [35.5, 147.0], [35.6, 147.0], [35.7, 147.0], [35.8, 147.0], [35.9, 147.0], [36.0, 147.0], [36.1, 148.0], [36.2, 148.0], [36.3, 148.0], [36.4, 148.0], [36.5, 148.0], [36.6, 148.0], [36.7, 148.0], [36.8, 148.0], [36.9, 148.0], [37.0, 148.0], [37.1, 148.0], [37.2, 148.0], [37.3, 148.0], [37.4, 149.0], [37.5, 149.0], [37.6, 149.0], [37.7, 149.0], [37.8, 149.0], [37.9, 149.0], [38.0, 149.0], [38.1, 149.0], [38.2, 149.0], [38.3, 149.0], [38.4, 149.0], [38.5, 149.0], [38.6, 149.0], [38.7, 149.0], [38.8, 149.0], [38.9, 149.0], [39.0, 149.0], [39.1, 149.0], [39.2, 149.0], [39.3, 149.0], [39.4, 150.0], [39.5, 150.0], [39.6, 150.0], [39.7, 150.0], [39.8, 150.0], [39.9, 150.0], [40.0, 150.0], [40.1, 150.0], [40.2, 150.0], [40.3, 150.0], [40.4, 150.0], [40.5, 150.0], [40.6, 150.0], [40.7, 150.0], [40.8, 150.0], [40.9, 150.0], [41.0, 150.0], [41.1, 150.0], [41.2, 150.0], [41.3, 151.0], [41.4, 151.0], [41.5, 151.0], [41.6, 151.0], [41.7, 151.0], [41.8, 151.0], [41.9, 151.0], [42.0, 151.0], [42.1, 151.0], [42.2, 151.0], [42.3, 151.0], [42.4, 151.0], [42.5, 151.0], [42.6, 151.0], [42.7, 151.0], [42.8, 151.0], [42.9, 151.0], [43.0, 151.0], [43.1, 151.0], [43.2, 152.0], [43.3, 152.0], [43.4, 152.0], [43.5, 152.0], [43.6, 152.0], [43.7, 152.0], [43.8, 152.0], [43.9, 152.0], [44.0, 152.0], [44.1, 152.0], [44.2, 152.0], [44.3, 152.0], [44.4, 152.0], [44.5, 152.0], [44.6, 152.0], [44.7, 153.0], [44.8, 153.0], [44.9, 153.0], [45.0, 153.0], [45.1, 153.0], [45.2, 153.0], [45.3, 153.0], [45.4, 153.0], [45.5, 153.0], [45.6, 153.0], [45.7, 153.0], [45.8, 153.0], [45.9, 153.0], [46.0, 153.0], [46.1, 153.0], [46.2, 153.0], [46.3, 153.0], [46.4, 153.0], [46.5, 154.0], [46.6, 154.0], [46.7, 154.0], [46.8, 154.0], [46.9, 154.0], [47.0, 154.0], [47.1, 154.0], [47.2, 154.0], [47.3, 154.0], [47.4, 154.0], [47.5, 154.0], [47.6, 154.0], [47.7, 155.0], [47.8, 155.0], [47.9, 155.0], [48.0, 155.0], [48.1, 155.0], [48.2, 155.0], [48.3, 155.0], [48.4, 155.0], [48.5, 155.0], [48.6, 155.0], [48.7, 155.0], [48.8, 155.0], [48.9, 155.0], [49.0, 155.0], [49.1, 156.0], [49.2, 156.0], [49.3, 156.0], [49.4, 156.0], [49.5, 156.0], [49.6, 156.0], [49.7, 156.0], [49.8, 156.0], [49.9, 156.0], [50.0, 156.0], [50.1, 156.0], [50.2, 156.0], [50.3, 156.0], [50.4, 156.0], [50.5, 157.0], [50.6, 157.0], [50.7, 157.0], [50.8, 157.0], [50.9, 157.0], [51.0, 157.0], [51.1, 157.0], [51.2, 157.0], [51.3, 157.0], [51.4, 157.0], [51.5, 157.0], [51.6, 157.0], [51.7, 158.0], [51.8, 158.0], [51.9, 158.0], [52.0, 158.0], [52.1, 158.0], [52.2, 158.0], [52.3, 158.0], [52.4, 158.0], [52.5, 158.0], [52.6, 158.0], [52.7, 158.0], [52.8, 158.0], [52.9, 159.0], [53.0, 159.0], [53.1, 159.0], [53.2, 159.0], [53.3, 159.0], [53.4, 159.0], [53.5, 159.0], [53.6, 159.0], [53.7, 159.0], [53.8, 159.0], [53.9, 159.0], [54.0, 159.0], [54.1, 159.0], [54.2, 159.0], [54.3, 159.0], [54.4, 160.0], [54.5, 160.0], [54.6, 160.0], [54.7, 160.0], [54.8, 160.0], [54.9, 160.0], [55.0, 160.0], [55.1, 160.0], [55.2, 160.0], [55.3, 160.0], [55.4, 160.0], [55.5, 160.0], [55.6, 160.0], [55.7, 160.0], [55.8, 160.0], [55.9, 160.0], [56.0, 160.0], [56.1, 161.0], [56.2, 161.0], [56.3, 161.0], [56.4, 161.0], [56.5, 161.0], [56.6, 161.0], [56.7, 161.0], [56.8, 161.0], [56.9, 161.0], [57.0, 161.0], [57.1, 161.0], [57.2, 161.0], [57.3, 162.0], [57.4, 162.0], [57.5, 162.0], [57.6, 162.0], [57.7, 162.0], [57.8, 162.0], [57.9, 162.0], [58.0, 162.0], [58.1, 162.0], [58.2, 162.0], [58.3, 162.0], [58.4, 162.0], [58.5, 163.0], [58.6, 163.0], [58.7, 163.0], [58.8, 163.0], [58.9, 163.0], [59.0, 163.0], [59.1, 163.0], [59.2, 163.0], [59.3, 163.0], [59.4, 163.0], [59.5, 164.0], [59.6, 164.0], [59.7, 164.0], [59.8, 164.0], [59.9, 164.0], [60.0, 164.0], [60.1, 164.0], [60.2, 164.0], [60.3, 164.0], [60.4, 164.0], [60.5, 165.0], [60.6, 165.0], [60.7, 165.0], [60.8, 165.0], [60.9, 165.0], [61.0, 165.0], [61.1, 165.0], [61.2, 165.0], [61.3, 166.0], [61.4, 166.0], [61.5, 166.0], [61.6, 166.0], [61.7, 166.0], [61.8, 166.0], [61.9, 166.0], [62.0, 167.0], [62.1, 167.0], [62.2, 167.0], [62.3, 167.0], [62.4, 167.0], [62.5, 167.0], [62.6, 167.0], [62.7, 167.0], [62.8, 167.0], [62.9, 168.0], [63.0, 168.0], [63.1, 168.0], [63.2, 168.0], [63.3, 168.0], [63.4, 168.0], [63.5, 168.0], [63.6, 168.0], [63.7, 168.0], [63.8, 168.0], [63.9, 168.0], [64.0, 169.0], [64.1, 169.0], [64.2, 169.0], [64.3, 169.0], [64.4, 169.0], [64.5, 169.0], [64.6, 169.0], [64.7, 169.0], [64.8, 169.0], [64.9, 170.0], [65.0, 170.0], [65.1, 170.0], [65.2, 170.0], [65.3, 170.0], [65.4, 170.0], [65.5, 170.0], [65.6, 170.0], [65.7, 171.0], [65.8, 171.0], [65.9, 171.0], [66.0, 171.0], [66.1, 171.0], [66.2, 171.0], [66.3, 171.0], [66.4, 172.0], [66.5, 172.0], [66.6, 172.0], [66.7, 172.0], [66.8, 172.0], [66.9, 172.0], [67.0, 172.0], [67.1, 173.0], [67.2, 173.0], [67.3, 173.0], [67.4, 173.0], [67.5, 174.0], [67.6, 174.0], [67.7, 174.0], [67.8, 174.0], [67.9, 174.0], [68.0, 174.0], [68.1, 174.0], [68.2, 174.0], [68.3, 174.0], [68.4, 175.0], [68.5, 175.0], [68.6, 175.0], [68.7, 175.0], [68.8, 175.0], [68.9, 175.0], [69.0, 175.0], [69.1, 176.0], [69.2, 176.0], [69.3, 176.0], [69.4, 176.0], [69.5, 176.0], [69.6, 176.0], [69.7, 176.0], [69.8, 177.0], [69.9, 177.0], [70.0, 178.0], [70.1, 178.0], [70.2, 178.0], [70.3, 178.0], [70.4, 178.0], [70.5, 178.0], [70.6, 179.0], [70.7, 179.0], [70.8, 179.0], [70.9, 179.0], [71.0, 179.0], [71.1, 180.0], [71.2, 180.0], [71.3, 180.0], [71.4, 180.0], [71.5, 180.0], [71.6, 180.0], [71.7, 181.0], [71.8, 181.0], [71.9, 181.0], [72.0, 181.0], [72.1, 181.0], [72.2, 181.0], [72.3, 182.0], [72.4, 182.0], [72.5, 182.0], [72.6, 183.0], [72.7, 183.0], [72.8, 183.0], [72.9, 183.0], [73.0, 184.0], [73.1, 184.0], [73.2, 185.0], [73.3, 185.0], [73.4, 185.0], [73.5, 185.0], [73.6, 185.0], [73.7, 186.0], [73.8, 186.0], [73.9, 186.0], [74.0, 186.0], [74.1, 187.0], [74.2, 187.0], [74.3, 187.0], [74.4, 187.0], [74.5, 187.0], [74.6, 188.0], [74.7, 188.0], [74.8, 188.0], [74.9, 188.0], [75.0, 189.0], [75.1, 189.0], [75.2, 189.0], [75.3, 189.0], [75.4, 190.0], [75.5, 190.0], [75.6, 191.0], [75.7, 191.0], [75.8, 191.0], [75.9, 191.0], [76.0, 191.0], [76.1, 191.0], [76.2, 192.0], [76.3, 192.0], [76.4, 192.0], [76.5, 192.0], [76.6, 193.0], [76.7, 193.0], [76.8, 193.0], [76.9, 193.0], [77.0, 194.0], [77.1, 194.0], [77.2, 195.0], [77.3, 195.0], [77.4, 195.0], [77.5, 195.0], [77.6, 196.0], [77.7, 196.0], [77.8, 196.0], [77.9, 196.0], [78.0, 196.0], [78.1, 196.0], [78.2, 197.0], [78.3, 197.0], [78.4, 198.0], [78.5, 198.0], [78.6, 198.0], [78.7, 199.0], [78.8, 199.0], [78.9, 200.0], [79.0, 200.0], [79.1, 200.0], [79.2, 201.0], [79.3, 202.0], [79.4, 202.0], [79.5, 202.0], [79.6, 203.0], [79.7, 203.0], [79.8, 203.0], [79.9, 203.0], [80.0, 204.0], [80.1, 204.0], [80.2, 205.0], [80.3, 205.0], [80.4, 206.0], [80.5, 206.0], [80.6, 206.0], [80.7, 207.0], [80.8, 208.0], [80.9, 208.0], [81.0, 209.0], [81.1, 209.0], [81.2, 210.0], [81.3, 210.0], [81.4, 211.0], [81.5, 211.0], [81.6, 212.0], [81.7, 213.0], [81.8, 214.0], [81.9, 214.0], [82.0, 215.0], [82.1, 216.0], [82.2, 217.0], [82.3, 218.0], [82.4, 218.0], [82.5, 219.0], [82.6, 220.0], [82.7, 220.0], [82.8, 221.0], [82.9, 221.0], [83.0, 223.0], [83.1, 224.0], [83.2, 225.0], [83.3, 225.0], [83.4, 227.0], [83.5, 228.0], [83.6, 229.0], [83.7, 230.0], [83.8, 230.0], [83.9, 231.0], [84.0, 232.0], [84.1, 233.0], [84.2, 234.0], [84.3, 234.0], [84.4, 235.0], [84.5, 236.0], [84.6, 238.0], [84.7, 240.0], [84.8, 241.0], [84.9, 241.0], [85.0, 242.0], [85.1, 246.0], [85.2, 247.0], [85.3, 250.0], [85.4, 251.0], [85.5, 252.0], [85.6, 252.0], [85.7, 253.0], [85.8, 258.0], [85.9, 259.0], [86.0, 263.0], [86.1, 265.0], [86.2, 265.0], [86.3, 267.0], [86.4, 268.0], [86.5, 268.0], [86.6, 269.0], [86.7, 269.0], [86.8, 271.0], [86.9, 273.0], [87.0, 276.0], [87.1, 277.0], [87.2, 279.0], [87.3, 280.0], [87.4, 282.0], [87.5, 282.0], [87.6, 283.0], [87.7, 284.0], [87.8, 285.0], [87.9, 287.0], [88.0, 287.0], [88.1, 290.0], [88.2, 291.0], [88.3, 294.0], [88.4, 295.0], [88.5, 296.0], [88.6, 298.0], [88.7, 299.0], [88.8, 302.0], [88.9, 303.0], [89.0, 305.0], [89.1, 306.0], [89.2, 308.0], [89.3, 313.0], [89.4, 314.0], [89.5, 316.0], [89.6, 316.0], [89.7, 317.0], [89.8, 317.0], [89.9, 319.0], [90.0, 322.0], [90.1, 323.0], [90.2, 326.0], [90.3, 329.0], [90.4, 331.0], [90.5, 332.0], [90.6, 336.0], [90.7, 336.0], [90.8, 336.0], [90.9, 342.0], [91.0, 344.0], [91.1, 345.0], [91.2, 346.0], [91.3, 348.0], [91.4, 351.0], [91.5, 351.0], [91.6, 351.0], [91.7, 354.0], [91.8, 356.0], [91.9, 358.0], [92.0, 360.0], [92.1, 362.0], [92.2, 365.0], [92.3, 365.0], [92.4, 367.0], [92.5, 368.0], [92.6, 370.0], [92.7, 373.0], [92.8, 373.0], [92.9, 374.0], [93.0, 378.0], [93.1, 380.0], [93.2, 386.0], [93.3, 387.0], [93.4, 391.0], [93.5, 392.0], [93.6, 398.0], [93.7, 403.0], [93.8, 409.0], [93.9, 418.0], [94.0, 419.0], [94.1, 421.0], [94.2, 421.0], [94.3, 427.0], [94.4, 433.0], [94.5, 442.0], [94.6, 459.0], [94.7, 464.0], [94.8, 475.0], [94.9, 479.0], [95.0, 494.0], [95.1, 495.0], [95.2, 502.0], [95.3, 511.0], [95.4, 511.0], [95.5, 520.0], [95.6, 526.0], [95.7, 542.0], [95.8, 543.0], [95.9, 558.0], [96.0, 570.0], [96.1, 578.0], [96.2, 585.0], [96.3, 586.0], [96.4, 592.0], [96.5, 593.0], [96.6, 593.0], [96.7, 598.0], [96.8, 600.0], [96.9, 607.0], [97.0, 609.0], [97.1, 618.0], [97.2, 619.0], [97.3, 640.0], [97.4, 656.0], [97.5, 680.0], [97.6, 692.0], [97.7, 717.0], [97.8, 728.0], [97.9, 747.0], [98.0, 801.0], [98.1, 807.0], [98.2, 847.0], [98.3, 874.0], [98.4, 910.0], [98.5, 923.0], [98.6, 930.0], [98.7, 966.0], [98.8, 987.0], [98.9, 1021.0], [99.0, 1069.0], [99.1, 1173.0], [99.2, 1191.0], [99.3, 1232.0], [99.4, 1254.0], [99.5, 1377.0], [99.6, 1461.0], [99.7, 1483.0], [99.8, 1735.0], [99.9, 1790.0]], "isOverall": false, "label": "GET - List Orders Direct Azure", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 100.0, "maxY": 1921.0, "series": [{"data": [[600.0, 20.0], [700.0, 9.0], [200.0, 240.0], [800.0, 10.0], [900.0, 12.0], [1000.0, 4.0], [1100.0, 4.0], [300.0, 120.0], [1200.0, 5.0], [1300.0, 3.0], [1400.0, 5.0], [1500.0, 1.0], [100.0, 1921.0], [400.0, 38.0], [1700.0, 3.0], [1900.0, 1.0], [500.0, 39.0], [2000.0, 1.0]], "isOverall": false, "label": "GET - List Orders Direct Azure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 2000.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 6.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 2319.0, "series": [{"data": [[0.0, 2319.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 111.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [[2.0, 6.0]], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 2.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 6.090909090909091, "minX": 1.79231128E12, "maxY": 20.0, "series": [{"data": [[1.79231128E12, 20.0], [1.792311365E12, 20.0], [1.79231132E12, 20.0], [1.792311405E12, 20.0], [1.79231137E12, 20.0], [1.792311285E12, 20.0], [1.79231141E12, 20.0], [1.792311325E12, 20.0], [1.79231129E12, 20.0], [1.792311375E12, 20.0], [1.79231133E12, 20.0], [1.792311415E12, 20.0], [1.79231138E12, 20.0], [1.792311295E12, 20.0], [1.79231142E12, 20.0], [1.792311335E12, 20.0], [1.7923113E12, 20.0], [1.792311385E12, 20.0], [1.79231134E12, 20.0], [1.792311425E12, 19.605263157894736], [1.79231139E12, 20.0], [1.792311305E12, 20.0], [1.79231143E12, 6.090909090909091], [1.792311345E12, 20.0], [1.79231131E12, 20.0], [1.792311395E12, 20.0], [1.79231135E12, 20.0], [1.792311315E12, 20.0], [1.79231136E12, 20.0], [1.792311355E12, 20.0], [1.7923114E12, 20.0]], "isOverall": false, "label": "Thread Group", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.79231143E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 148.5, "minX": 1.0, "maxY": 1001.3333333333334, "series": [{"data": [[8.0, 174.0], [2.0, 238.0], [9.0, 173.0], [11.0, 148.5], [3.0, 228.0], [14.0, 1001.3333333333334], [4.0, 221.0], [1.0, 253.0], [17.0, 691.6666666666667], [18.0, 162.0], [19.0, 160.0], [20.0, 205.98965659908944], [5.0, 218.0], [6.0, 213.0], [7.0, 181.0]], "isOverall": false, "label": "GET - List Orders Direct Azure", "isController": false}, {"data": [[19.92487684729064, 207.50164203612442]], "isOverall": false, "label": "GET - List Orders Direct Azure-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 20.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 3445.2, "minX": 1.79231128E12, "maxY": 132084.0, "series": [{"data": [[1.79231128E12, 49898.4], [1.792311365E12, 127681.2], [1.79231132E12, 123278.4], [1.792311405E12, 111537.6], [1.79231137E12, 121810.8], [1.792311285E12, 123278.4], [1.79231141E12, 129148.8], [1.792311325E12, 117409.2], [1.79231129E12, 124746.0], [1.792311375E12, 117408.0], [1.79231133E12, 107136.2], [1.792311415E12, 118878.4], [1.79231138E12, 117410.8], [1.792311295E12, 124747.4], [1.79231142E12, 132084.0], [1.792311335E12, 117409.4], [1.7923113E12, 126213.6], [1.792311385E12, 127681.2], [1.79231134E12, 127681.2], [1.792311425E12, 111537.6], [1.79231139E12, 118877.0], [1.792311305E12, 110070.0], [1.79231143E12, 16143.6], [1.792311345E12, 114475.6], [1.79231131E12, 129148.8], [1.792311395E12, 115940.4], [1.79231135E12, 113006.6], [1.792311315E12, 120343.2], [1.79231136E12, 120343.2], [1.792311355E12, 127681.2], [1.7923114E12, 132084.0]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.79231128E12, 10648.8], [1.792311365E12, 27248.4], [1.79231132E12, 26308.8], [1.792311405E12, 23803.2], [1.79231137E12, 25995.6], [1.792311285E12, 26308.8], [1.79231141E12, 27561.6], [1.792311325E12, 25056.0], [1.79231129E12, 26622.0], [1.792311375E12, 25056.0], [1.79231133E12, 22863.6], [1.792311415E12, 25369.2], [1.79231138E12, 25056.0], [1.792311295E12, 26622.0], [1.79231142E12, 28188.0], [1.792311335E12, 25056.0], [1.7923113E12, 26935.2], [1.792311385E12, 27248.4], [1.79231134E12, 27248.4], [1.792311425E12, 23803.2], [1.79231139E12, 25369.2], [1.792311305E12, 23490.0], [1.79231143E12, 3445.2], [1.792311345E12, 24429.6], [1.79231131E12, 27561.6], [1.792311395E12, 24742.8], [1.79231135E12, 24116.4], [1.792311315E12, 25682.4], [1.79231136E12, 25682.4], [1.792311355E12, 27248.4], [1.7923114E12, 28188.0]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.79231143E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 149.0333333333333, "minX": 1.79231128E12, "maxY": 337.9726027397262, "series": [{"data": [[1.79231128E12, 309.764705882353], [1.792311365E12, 156.10344827586212], [1.79231132E12, 176.24999999999991], [1.792311405E12, 237.86842105263156], [1.79231137E12, 224.55421686746996], [1.792311285E12, 199.36904761904768], [1.79231141E12, 161.4204545454546], [1.792311325E12, 244.0], [1.79231129E12, 161.18823529411767], [1.792311375E12, 184.52499999999998], [1.79231133E12, 337.9726027397262], [1.792311415E12, 226.61728395061726], [1.79231138E12, 187.06250000000009], [1.792311295E12, 199.67058823529402], [1.79231142E12, 155.1222222222222], [1.792311335E12, 181.85], [1.7923113E12, 174.94186046511632], [1.792311385E12, 205.11494252873567], [1.79231134E12, 182.09195402298846], [1.792311425E12, 244.84210526315786], [1.79231139E12, 172.1851851851852], [1.792311305E12, 251.58666666666656], [1.79231143E12, 199.63636363636365], [1.792311345E12, 295.62820512820514], [1.79231131E12, 185.42045454545453], [1.792311395E12, 260.74683544303787], [1.79231135E12, 269.7792207792208], [1.792311315E12, 239.58536585365852], [1.79231136E12, 223.10975609756088], [1.792311355E12, 149.16091954022994], [1.7923114E12, 149.0333333333333]], "isOverall": false, "label": "GET - List Orders Direct Azure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.79231143E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 143.66666666666669, "minX": 1.79231128E12, "maxY": 309.8356164383561, "series": [{"data": [[1.79231128E12, 274.1764705882353], [1.792311365E12, 151.3218390804597], [1.79231132E12, 172.95238095238093], [1.792311405E12, 206.30263157894737], [1.79231137E12, 206.74698795180723], [1.792311285E12, 189.75], [1.79231141E12, 147.79545454545456], [1.792311325E12, 240.88749999999996], [1.79231129E12, 152.7764705882352], [1.792311375E12, 175.3], [1.79231133E12, 309.8356164383561], [1.792311415E12, 205.45679012345673], [1.79231138E12, 177.29999999999998], [1.792311295E12, 193.31764705882352], [1.79231142E12, 150.56666666666663], [1.792311335E12, 178.4125], [1.7923113E12, 170.29069767441868], [1.792311385E12, 187.8390804597701], [1.79231134E12, 179.48275862068962], [1.792311425E12, 235.23684210526315], [1.79231139E12, 166.98765432098767], [1.792311305E12, 241.4], [1.79231143E12, 198.0909090909091], [1.792311345E12, 260.6025641025641], [1.79231131E12, 182.04545454545456], [1.792311395E12, 240.00000000000009], [1.79231135E12, 252.09090909090915], [1.792311315E12, 233.09756097560984], [1.79231136E12, 206.03658536585368], [1.792311355E12, 143.66666666666669], [1.7923114E12, 146.20000000000005]], "isOverall": false, "label": "GET - List Orders Direct Azure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.79231143E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 0.0, "minX": 1.79231128E12, "maxY": 43.0, "series": [{"data": [[1.79231128E12, 0.0], [1.792311365E12, 0.0], [1.79231132E12, 8.73809523809524], [1.792311405E12, 0.0], [1.79231137E12, 36.30120481927711], [1.792311285E12, 0.0], [1.79231141E12, 0.0], [1.792311325E12, 0.0], [1.79231129E12, 0.0], [1.792311375E12, 31.299999999999997], [1.79231133E12, 0.0], [1.792311415E12, 0.0], [1.79231138E12, 17.450000000000006], [1.792311295E12, 0.0], [1.79231142E12, 0.0], [1.792311335E12, 0.0], [1.7923113E12, 0.0], [1.792311385E12, 0.0], [1.79231134E12, 0.0], [1.792311425E12, 0.0], [1.79231139E12, 0.0], [1.792311305E12, 0.0], [1.79231143E12, 0.0], [1.792311345E12, 0.0], [1.79231131E12, 16.75], [1.792311395E12, 0.0], [1.79231135E12, 0.0], [1.792311315E12, 43.0], [1.79231136E12, 0.0], [1.792311355E12, 0.0], [1.7923114E12, 0.0]], "isOverall": false, "label": "GET - List Orders Direct Azure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.79231143E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 112.0, "minX": 1.79231128E12, "maxY": 2094.0, "series": [{"data": [[1.79231128E12, 1254.0], [1.792311365E12, 212.0], [1.79231132E12, 440.0], [1.792311405E12, 1736.0], [1.79231137E12, 1461.0], [1.792311285E12, 1790.0], [1.79231141E12, 343.0], [1.792311325E12, 619.0], [1.79231129E12, 538.0], [1.792311375E12, 475.0], [1.79231133E12, 1234.0], [1.792311415E12, 1191.0], [1.79231138E12, 1069.0], [1.792311295E12, 932.0], [1.79231142E12, 299.0], [1.792311335E12, 307.0], [1.7923113E12, 316.0], [1.792311385E12, 1483.0], [1.79231134E12, 323.0], [1.792311425E12, 1393.0], [1.79231139E12, 593.0], [1.792311305E12, 1377.0], [1.79231143E12, 253.0], [1.792311345E12, 2094.0], [1.79231131E12, 497.0], [1.792311395E12, 1431.0], [1.79231135E12, 1909.0], [1.792311315E12, 966.0], [1.79231136E12, 1232.0], [1.792311355E12, 290.0], [1.7923114E12, 204.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.79231128E12, 124.0], [1.792311365E12, 115.0], [1.79231132E12, 125.0], [1.792311405E12, 121.0], [1.79231137E12, 116.0], [1.792311285E12, 115.0], [1.79231141E12, 122.0], [1.792311325E12, 115.0], [1.79231129E12, 116.0], [1.792311375E12, 121.0], [1.79231133E12, 133.0], [1.792311415E12, 120.0], [1.79231138E12, 118.0], [1.792311295E12, 127.0], [1.79231142E12, 120.0], [1.792311335E12, 127.0], [1.7923113E12, 125.0], [1.792311385E12, 121.0], [1.79231134E12, 122.0], [1.792311425E12, 119.0], [1.79231139E12, 112.0], [1.792311305E12, 121.0], [1.79231143E12, 148.0], [1.792311345E12, 123.0], [1.79231131E12, 126.0], [1.792311395E12, 121.0], [1.79231135E12, 123.0], [1.792311315E12, 123.0], [1.79231136E12, 114.0], [1.792311355E12, 121.0], [1.7923114E12, 119.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.79231128E12, 795.0], [1.792311365E12, 193.4], [1.79231132E12, 203.5], [1.792311405E12, 249.0999999999999], [1.79231137E12, 540.0], [1.792311285E12, 257.0], [1.79231141E12, 195.0], [1.792311325E12, 473.8000000000003], [1.79231129E12, 268.0], [1.792311375E12, 369.8], [1.79231133E12, 654.4000000000001], [1.792311415E12, 369.99999999999994], [1.79231138E12, 354.00000000000006], [1.792311295E12, 272.00000000000045], [1.79231142E12, 200.0], [1.792311335E12, 223.60000000000002], [1.7923113E12, 238.99999999999997], [1.792311385E12, 357.4000000000001], [1.79231134E12, 250.0000000000001], [1.792311425E12, 578.9999999999998], [1.79231139E12, 203.0], [1.792311305E12, 532.4000000000002], [1.79231143E12, 250.0], [1.792311345E12, 515.0000000000006], [1.79231131E12, 287.2000000000001], [1.792311395E12, 421.0], [1.79231135E12, 838.2000000000005], [1.792311315E12, 407.20000000000005], [1.79231136E12, 361.00000000000017], [1.792311355E12, 169.60000000000002], [1.7923114E12, 177.20000000000005]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.79231128E12, 1254.0], [1.792311365E12, 212.0], [1.79231132E12, 440.0], [1.792311405E12, 1736.0], [1.79231137E12, 1461.0], [1.792311285E12, 1790.0], [1.79231141E12, 343.0], [1.792311325E12, 619.0], [1.79231129E12, 538.0], [1.792311375E12, 475.0], [1.79231133E12, 1234.0], [1.792311415E12, 1191.0], [1.79231138E12, 1069.0], [1.792311295E12, 932.0], [1.79231142E12, 299.0], [1.792311335E12, 307.0], [1.7923113E12, 316.0], [1.792311385E12, 1483.0], [1.79231134E12, 323.0], [1.792311425E12, 1393.0], [1.79231139E12, 593.0], [1.792311305E12, 1377.0], [1.79231143E12, 253.0], [1.792311345E12, 2094.0], [1.79231131E12, 497.0], [1.792311395E12, 1431.0], [1.79231135E12, 1909.0], [1.792311315E12, 966.0], [1.79231136E12, 1232.0], [1.792311355E12, 290.0], [1.7923114E12, 204.0]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.79231128E12, 185.5], [1.792311365E12, 150.0], [1.79231132E12, 164.5], [1.792311405E12, 152.0], [1.79231137E12, 150.0], [1.792311285E12, 157.0], [1.79231141E12, 149.0], [1.792311325E12, 207.0], [1.79231129E12, 139.0], [1.792311375E12, 146.5], [1.79231133E12, 222.0], [1.792311415E12, 158.0], [1.79231138E12, 144.0], [1.792311295E12, 162.0], [1.79231142E12, 146.0], [1.792311335E12, 176.0], [1.7923113E12, 165.0], [1.792311385E12, 149.0], [1.79231134E12, 169.0], [1.792311425E12, 143.0], [1.79231139E12, 151.0], [1.792311305E12, 174.0], [1.79231143E12, 213.0], [1.792311345E12, 169.0], [1.79231131E12, 160.0], [1.792311395E12, 172.0], [1.79231135E12, 157.0], [1.792311315E12, 171.5], [1.79231136E12, 153.5], [1.792311355E12, 143.0], [1.7923114E12, 146.5]], "isOverall": false, "label": "Median", "isController": false}, {"data": [[1.79231128E12, 1005.75], [1.792311365E12, 203.0], [1.79231132E12, 265.0], [1.792311405E12, 1160.3999999999965], [1.79231137E12, 725.8], [1.792311285E12, 418.5], [1.79231141E12, 280.84999999999997], [1.792311325E12, 541.2], [1.79231129E12, 314.0], [1.792311375E12, 392.0], [1.79231133E12, 827.0999999999998], [1.792311415E12, 593.0999999999999], [1.79231138E12, 385.8500000000001], [1.792311295E12, 446.9000000000003], [1.79231142E12, 227.60000000000002], [1.792311335E12, 294.6], [1.7923113E12, 269.0], [1.792311385E12, 562.9999999999993], [1.79231134E12, 310.19999999999993], [1.792311425E12, 789.0499999999996], [1.79231139E12, 384.3999999999994], [1.792311305E12, 598.0], [1.79231143E12, 253.0], [1.792311345E12, 948.649999999999], [1.79231131E12, 365.9], [1.792311395E12, 616.0], [1.79231135E12, 1036.6999999999991], [1.792311315E12, 607.5999999999996], [1.79231136E12, 810.9499999999992], [1.792311355E12, 182.59999999999997], [1.7923114E12, 188.25]], "isOverall": false, "label": "95th percentile", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.79231143E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 145.0, "minX": 5.0, "maxY": 202.0, "series": [{"data": [[8.0, 155.0], [10.0, 172.5], [11.0, 202.0], [12.0, 158.5], [13.0, 145.0], [14.0, 163.5], [15.0, 153.0], [16.0, 154.0], [17.0, 156.0], [18.0, 155.0], [19.0, 150.0], [20.0, 161.0], [5.0, 183.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 20.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 145.0, "minX": 5.0, "maxY": 199.0, "series": [{"data": [[8.0, 152.0], [10.0, 172.5], [11.0, 199.0], [12.0, 156.0], [13.0, 145.0], [14.0, 158.5], [15.0, 149.0], [16.0, 152.0], [17.0, 150.0], [18.0, 151.0], [19.0, 146.0], [20.0, 157.0], [5.0, 180.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 20.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 1.4, "minX": 1.79231128E12, "maxY": 17.6, "series": [{"data": [[1.79231128E12, 7.8], [1.792311365E12, 16.6], [1.79231132E12, 16.8], [1.792311405E12, 16.8], [1.79231137E12, 16.6], [1.792311285E12, 16.4], [1.79231141E12, 16.8], [1.792311325E12, 16.4], [1.79231129E12, 17.2], [1.792311375E12, 16.2], [1.79231133E12, 14.2], [1.792311415E12, 16.0], [1.79231138E12, 17.6], [1.792311295E12, 17.4], [1.79231142E12, 17.6], [1.792311335E12, 16.4], [1.7923113E12, 16.0], [1.792311385E12, 15.8], [1.79231134E12, 17.4], [1.792311425E12, 15.6], [1.79231139E12, 16.2], [1.792311305E12, 16.4], [1.79231143E12, 1.4], [1.792311345E12, 15.6], [1.79231131E12, 17.4], [1.792311395E12, 16.2], [1.79231135E12, 16.0], [1.792311315E12, 15.2], [1.79231136E12, 16.4], [1.792311355E12, 17.2], [1.7923114E12, 17.6]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.79231143E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 2.2, "minX": 1.79231128E12, "maxY": 18.0, "series": [{"data": [[1.79231128E12, 6.8], [1.792311365E12, 17.4], [1.79231132E12, 16.8], [1.792311405E12, 15.2], [1.79231137E12, 16.6], [1.792311285E12, 16.8], [1.79231141E12, 17.6], [1.792311325E12, 16.0], [1.79231129E12, 17.0], [1.792311375E12, 16.0], [1.79231133E12, 14.6], [1.792311415E12, 16.2], [1.79231138E12, 16.0], [1.792311295E12, 17.0], [1.79231142E12, 18.0], [1.792311335E12, 16.0], [1.7923113E12, 17.2], [1.792311385E12, 17.4], [1.79231134E12, 17.4], [1.792311425E12, 15.2], [1.79231139E12, 16.2], [1.792311305E12, 15.0], [1.79231143E12, 2.2], [1.792311345E12, 15.6], [1.79231131E12, 17.6], [1.792311395E12, 15.8], [1.79231135E12, 15.4], [1.792311315E12, 16.4], [1.79231136E12, 16.4], [1.792311355E12, 17.4], [1.7923114E12, 18.0]], "isOverall": false, "label": "200", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.79231143E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 2.2, "minX": 1.79231128E12, "maxY": 18.0, "series": [{"data": [[1.79231128E12, 6.8], [1.792311365E12, 17.4], [1.79231132E12, 16.8], [1.792311405E12, 15.2], [1.79231137E12, 16.6], [1.792311285E12, 16.8], [1.79231141E12, 17.6], [1.792311325E12, 16.0], [1.79231129E12, 17.0], [1.792311375E12, 16.0], [1.79231133E12, 14.6], [1.792311415E12, 16.2], [1.79231138E12, 16.0], [1.792311295E12, 17.0], [1.79231142E12, 18.0], [1.792311335E12, 16.0], [1.7923113E12, 17.2], [1.792311385E12, 17.4], [1.79231134E12, 17.4], [1.792311425E12, 15.2], [1.79231139E12, 16.2], [1.792311305E12, 15.0], [1.79231143E12, 2.2], [1.792311345E12, 15.6], [1.79231131E12, 17.6], [1.792311395E12, 15.8], [1.79231135E12, 15.4], [1.792311315E12, 16.4], [1.79231136E12, 16.4], [1.792311355E12, 17.4], [1.7923114E12, 18.0]], "isOverall": false, "label": "GET - List Orders Direct Azure-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.79231143E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 2.2, "minX": 1.79231128E12, "maxY": 18.0, "series": [{"data": [[1.79231128E12, 6.8], [1.792311365E12, 17.4], [1.79231132E12, 16.8], [1.792311405E12, 15.2], [1.79231137E12, 16.6], [1.792311285E12, 16.8], [1.79231141E12, 17.6], [1.792311325E12, 16.0], [1.79231129E12, 17.0], [1.792311375E12, 16.0], [1.79231133E12, 14.6], [1.792311415E12, 16.2], [1.79231138E12, 16.0], [1.792311295E12, 17.0], [1.79231142E12, 18.0], [1.792311335E12, 16.0], [1.7923113E12, 17.2], [1.792311385E12, 17.4], [1.79231134E12, 17.4], [1.792311425E12, 15.2], [1.79231139E12, 16.2], [1.792311305E12, 15.0], [1.79231143E12, 2.2], [1.792311345E12, 15.6], [1.79231131E12, 17.6], [1.792311395E12, 15.8], [1.79231135E12, 15.4], [1.792311315E12, 16.4], [1.79231136E12, 16.4], [1.792311355E12, 17.4], [1.7923114E12, 18.0]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.79231143E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

