/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 466.0, "minX": 0.0, "maxY": 3512.0, "series": [{"data": [[0.0, 466.0], [0.1, 466.0], [0.2, 466.0], [0.3, 470.0], [0.4, 470.0], [0.5, 470.0], [0.6, 470.0], [0.7, 470.0], [0.8, 470.0], [0.9, 471.0], [1.0, 471.0], [1.1, 471.0], [1.2, 472.0], [1.3, 472.0], [1.4, 472.0], [1.5, 473.0], [1.6, 473.0], [1.7, 473.0], [1.8, 473.0], [1.9, 473.0], [2.0, 473.0], [2.1, 474.0], [2.2, 474.0], [2.3, 474.0], [2.4, 474.0], [2.5, 474.0], [2.6, 474.0], [2.7, 475.0], [2.8, 475.0], [2.9, 475.0], [3.0, 475.0], [3.1, 475.0], [3.2, 475.0], [3.3, 475.0], [3.4, 475.0], [3.5, 476.0], [3.6, 476.0], [3.7, 476.0], [3.8, 476.0], [3.9, 476.0], [4.0, 476.0], [4.1, 476.0], [4.2, 476.0], [4.3, 476.0], [4.4, 477.0], [4.5, 477.0], [4.6, 477.0], [4.7, 477.0], [4.8, 477.0], [4.9, 477.0], [5.0, 478.0], [5.1, 478.0], [5.2, 478.0], [5.3, 478.0], [5.4, 478.0], [5.5, 478.0], [5.6, 479.0], [5.7, 479.0], [5.8, 479.0], [5.9, 479.0], [6.0, 479.0], [6.1, 479.0], [6.2, 479.0], [6.3, 479.0], [6.4, 479.0], [6.5, 480.0], [6.6, 480.0], [6.7, 480.0], [6.8, 481.0], [6.9, 481.0], [7.0, 481.0], [7.1, 481.0], [7.2, 481.0], [7.3, 481.0], [7.4, 481.0], [7.5, 481.0], [7.6, 481.0], [7.7, 481.0], [7.8, 481.0], [7.9, 481.0], [8.0, 481.0], [8.1, 481.0], [8.2, 481.0], [8.3, 481.0], [8.4, 481.0], [8.5, 482.0], [8.6, 482.0], [8.7, 482.0], [8.8, 482.0], [8.9, 482.0], [9.0, 482.0], [9.1, 482.0], [9.2, 482.0], [9.3, 482.0], [9.4, 482.0], [9.5, 482.0], [9.6, 482.0], [9.7, 482.0], [9.8, 482.0], [9.9, 482.0], [10.0, 483.0], [10.1, 483.0], [10.2, 483.0], [10.3, 483.0], [10.4, 483.0], [10.5, 483.0], [10.6, 483.0], [10.7, 483.0], [10.8, 483.0], [10.9, 483.0], [11.0, 483.0], [11.1, 484.0], [11.2, 484.0], [11.3, 484.0], [11.4, 484.0], [11.5, 484.0], [11.6, 484.0], [11.7, 484.0], [11.8, 484.0], [11.9, 484.0], [12.0, 485.0], [12.1, 485.0], [12.2, 485.0], [12.3, 485.0], [12.4, 485.0], [12.5, 485.0], [12.6, 485.0], [12.7, 485.0], [12.8, 485.0], [12.9, 485.0], [13.0, 485.0], [13.1, 485.0], [13.2, 486.0], [13.3, 486.0], [13.4, 486.0], [13.5, 486.0], [13.6, 486.0], [13.7, 486.0], [13.8, 486.0], [13.9, 486.0], [14.0, 487.0], [14.1, 487.0], [14.2, 487.0], [14.3, 487.0], [14.4, 487.0], [14.5, 487.0], [14.6, 487.0], [14.7, 487.0], [14.8, 487.0], [14.9, 487.0], [15.0, 487.0], [15.1, 487.0], [15.2, 487.0], [15.3, 487.0], [15.4, 487.0], [15.5, 488.0], [15.6, 488.0], [15.7, 488.0], [15.8, 488.0], [15.9, 488.0], [16.0, 488.0], [16.1, 488.0], [16.2, 488.0], [16.3, 488.0], [16.4, 488.0], [16.5, 488.0], [16.6, 488.0], [16.7, 488.0], [16.8, 488.0], [16.9, 488.0], [17.0, 489.0], [17.1, 489.0], [17.2, 489.0], [17.3, 489.0], [17.4, 489.0], [17.5, 489.0], [17.6, 489.0], [17.7, 489.0], [17.8, 489.0], [17.9, 489.0], [18.0, 489.0], [18.1, 489.0], [18.2, 489.0], [18.3, 489.0], [18.4, 489.0], [18.5, 489.0], [18.6, 489.0], [18.7, 490.0], [18.8, 490.0], [18.9, 490.0], [19.0, 490.0], [19.1, 490.0], [19.2, 490.0], [19.3, 490.0], [19.4, 490.0], [19.5, 490.0], [19.6, 490.0], [19.7, 490.0], [19.8, 490.0], [19.9, 490.0], [20.0, 490.0], [20.1, 490.0], [20.2, 490.0], [20.3, 490.0], [20.4, 490.0], [20.5, 490.0], [20.6, 490.0], [20.7, 491.0], [20.8, 491.0], [20.9, 491.0], [21.0, 491.0], [21.1, 491.0], [21.2, 491.0], [21.3, 492.0], [21.4, 492.0], [21.5, 492.0], [21.6, 492.0], [21.7, 492.0], [21.8, 492.0], [21.9, 492.0], [22.0, 492.0], [22.1, 492.0], [22.2, 492.0], [22.3, 492.0], [22.4, 492.0], [22.5, 492.0], [22.6, 492.0], [22.7, 492.0], [22.8, 492.0], [22.9, 492.0], [23.0, 492.0], [23.1, 493.0], [23.2, 493.0], [23.3, 493.0], [23.4, 493.0], [23.5, 493.0], [23.6, 493.0], [23.7, 493.0], [23.8, 493.0], [23.9, 493.0], [24.0, 493.0], [24.1, 493.0], [24.2, 494.0], [24.3, 494.0], [24.4, 494.0], [24.5, 494.0], [24.6, 494.0], [24.7, 494.0], [24.8, 494.0], [24.9, 494.0], [25.0, 494.0], [25.1, 494.0], [25.2, 494.0], [25.3, 494.0], [25.4, 494.0], [25.5, 494.0], [25.6, 494.0], [25.7, 494.0], [25.8, 494.0], [25.9, 494.0], [26.0, 494.0], [26.1, 494.0], [26.2, 494.0], [26.3, 494.0], [26.4, 494.0], [26.5, 494.0], [26.6, 494.0], [26.7, 494.0], [26.8, 494.0], [26.9, 494.0], [27.0, 494.0], [27.1, 494.0], [27.2, 495.0], [27.3, 495.0], [27.4, 495.0], [27.5, 495.0], [27.6, 495.0], [27.7, 495.0], [27.8, 495.0], [27.9, 495.0], [28.0, 497.0], [28.1, 497.0], [28.2, 497.0], [28.3, 497.0], [28.4, 497.0], [28.5, 497.0], [28.6, 497.0], [28.7, 497.0], [28.8, 497.0], [28.9, 497.0], [29.0, 497.0], [29.1, 497.0], [29.2, 497.0], [29.3, 497.0], [29.4, 497.0], [29.5, 497.0], [29.6, 497.0], [29.7, 497.0], [29.8, 497.0], [29.9, 497.0], [30.0, 497.0], [30.1, 498.0], [30.2, 498.0], [30.3, 498.0], [30.4, 498.0], [30.5, 498.0], [30.6, 498.0], [30.7, 498.0], [30.8, 498.0], [30.9, 498.0], [31.0, 498.0], [31.1, 498.0], [31.2, 498.0], [31.3, 498.0], [31.4, 498.0], [31.5, 498.0], [31.6, 498.0], [31.7, 498.0], [31.8, 498.0], [31.9, 498.0], [32.0, 498.0], [32.1, 498.0], [32.2, 498.0], [32.3, 498.0], [32.4, 499.0], [32.5, 499.0], [32.6, 499.0], [32.7, 499.0], [32.8, 499.0], [32.9, 499.0], [33.0, 499.0], [33.1, 499.0], [33.2, 499.0], [33.3, 500.0], [33.4, 500.0], [33.5, 500.0], [33.6, 500.0], [33.7, 500.0], [33.8, 500.0], [33.9, 500.0], [34.0, 500.0], [34.1, 500.0], [34.2, 501.0], [34.3, 501.0], [34.4, 501.0], [34.5, 501.0], [34.6, 501.0], [34.7, 501.0], [34.8, 501.0], [34.9, 501.0], [35.0, 502.0], [35.1, 502.0], [35.2, 502.0], [35.3, 502.0], [35.4, 502.0], [35.5, 502.0], [35.6, 502.0], [35.7, 502.0], [35.8, 502.0], [35.9, 502.0], [36.0, 502.0], [36.1, 502.0], [36.2, 502.0], [36.3, 502.0], [36.4, 502.0], [36.5, 502.0], [36.6, 502.0], [36.7, 502.0], [36.8, 502.0], [36.9, 502.0], [37.0, 502.0], [37.1, 503.0], [37.2, 503.0], [37.3, 503.0], [37.4, 503.0], [37.5, 503.0], [37.6, 503.0], [37.7, 503.0], [37.8, 503.0], [37.9, 503.0], [38.0, 503.0], [38.1, 503.0], [38.2, 503.0], [38.3, 503.0], [38.4, 503.0], [38.5, 503.0], [38.6, 503.0], [38.7, 503.0], [38.8, 503.0], [38.9, 503.0], [39.0, 503.0], [39.1, 504.0], [39.2, 504.0], [39.3, 504.0], [39.4, 504.0], [39.5, 504.0], [39.6, 504.0], [39.7, 504.0], [39.8, 504.0], [39.9, 504.0], [40.0, 504.0], [40.1, 504.0], [40.2, 504.0], [40.3, 504.0], [40.4, 504.0], [40.5, 504.0], [40.6, 504.0], [40.7, 504.0], [40.8, 504.0], [40.9, 504.0], [41.0, 504.0], [41.1, 504.0], [41.2, 505.0], [41.3, 505.0], [41.4, 505.0], [41.5, 505.0], [41.6, 505.0], [41.7, 505.0], [41.8, 505.0], [41.9, 505.0], [42.0, 505.0], [42.1, 505.0], [42.2, 505.0], [42.3, 506.0], [42.4, 506.0], [42.5, 506.0], [42.6, 506.0], [42.7, 506.0], [42.8, 506.0], [42.9, 506.0], [43.0, 506.0], [43.1, 506.0], [43.2, 506.0], [43.3, 506.0], [43.4, 506.0], [43.5, 507.0], [43.6, 507.0], [43.7, 507.0], [43.8, 507.0], [43.9, 507.0], [44.0, 507.0], [44.1, 507.0], [44.2, 507.0], [44.3, 507.0], [44.4, 507.0], [44.5, 507.0], [44.6, 507.0], [44.7, 508.0], [44.8, 508.0], [44.9, 508.0], [45.0, 508.0], [45.1, 508.0], [45.2, 508.0], [45.3, 508.0], [45.4, 508.0], [45.5, 508.0], [45.6, 508.0], [45.7, 508.0], [45.8, 508.0], [45.9, 508.0], [46.0, 508.0], [46.1, 508.0], [46.2, 508.0], [46.3, 508.0], [46.4, 509.0], [46.5, 509.0], [46.6, 509.0], [46.7, 509.0], [46.8, 509.0], [46.9, 509.0], [47.0, 510.0], [47.1, 510.0], [47.2, 510.0], [47.3, 510.0], [47.4, 510.0], [47.5, 510.0], [47.6, 510.0], [47.7, 510.0], [47.8, 510.0], [47.9, 511.0], [48.0, 511.0], [48.1, 511.0], [48.2, 511.0], [48.3, 511.0], [48.4, 511.0], [48.5, 511.0], [48.6, 511.0], [48.7, 511.0], [48.8, 511.0], [48.9, 511.0], [49.0, 512.0], [49.1, 512.0], [49.2, 512.0], [49.3, 512.0], [49.4, 512.0], [49.5, 512.0], [49.6, 512.0], [49.7, 512.0], [49.8, 512.0], [49.9, 513.0], [50.0, 513.0], [50.1, 513.0], [50.2, 513.0], [50.3, 513.0], [50.4, 513.0], [50.5, 513.0], [50.6, 513.0], [50.7, 513.0], [50.8, 514.0], [50.9, 514.0], [51.0, 514.0], [51.1, 514.0], [51.2, 514.0], [51.3, 514.0], [51.4, 514.0], [51.5, 514.0], [51.6, 514.0], [51.7, 515.0], [51.8, 515.0], [51.9, 515.0], [52.0, 515.0], [52.1, 515.0], [52.2, 515.0], [52.3, 515.0], [52.4, 515.0], [52.5, 515.0], [52.6, 515.0], [52.7, 515.0], [52.8, 516.0], [52.9, 516.0], [53.0, 516.0], [53.1, 516.0], [53.2, 516.0], [53.3, 516.0], [53.4, 516.0], [53.5, 516.0], [53.6, 516.0], [53.7, 516.0], [53.8, 516.0], [53.9, 516.0], [54.0, 516.0], [54.1, 516.0], [54.2, 516.0], [54.3, 516.0], [54.4, 516.0], [54.5, 516.0], [54.6, 516.0], [54.7, 516.0], [54.8, 516.0], [54.9, 517.0], [55.0, 517.0], [55.1, 517.0], [55.2, 517.0], [55.3, 517.0], [55.4, 517.0], [55.5, 517.0], [55.6, 517.0], [55.7, 517.0], [55.8, 517.0], [55.9, 517.0], [56.0, 518.0], [56.1, 518.0], [56.2, 518.0], [56.3, 518.0], [56.4, 518.0], [56.5, 518.0], [56.6, 519.0], [56.7, 519.0], [56.8, 519.0], [56.9, 519.0], [57.0, 519.0], [57.1, 519.0], [57.2, 519.0], [57.3, 519.0], [57.4, 519.0], [57.5, 519.0], [57.6, 519.0], [57.7, 519.0], [57.8, 519.0], [57.9, 519.0], [58.0, 519.0], [58.1, 520.0], [58.2, 520.0], [58.3, 520.0], [58.4, 520.0], [58.5, 520.0], [58.6, 520.0], [58.7, 521.0], [58.8, 521.0], [58.9, 521.0], [59.0, 521.0], [59.1, 521.0], [59.2, 521.0], [59.3, 521.0], [59.4, 521.0], [59.5, 522.0], [59.6, 522.0], [59.7, 522.0], [59.8, 522.0], [59.9, 522.0], [60.0, 522.0], [60.1, 524.0], [60.2, 524.0], [60.3, 524.0], [60.4, 525.0], [60.5, 525.0], [60.6, 525.0], [60.7, 525.0], [60.8, 525.0], [60.9, 525.0], [61.0, 526.0], [61.1, 526.0], [61.2, 526.0], [61.3, 526.0], [61.4, 526.0], [61.5, 526.0], [61.6, 526.0], [61.7, 526.0], [61.8, 526.0], [61.9, 526.0], [62.0, 526.0], [62.1, 527.0], [62.2, 527.0], [62.3, 527.0], [62.4, 527.0], [62.5, 527.0], [62.6, 527.0], [62.7, 527.0], [62.8, 527.0], [62.9, 527.0], [63.0, 528.0], [63.1, 528.0], [63.2, 528.0], [63.3, 528.0], [63.4, 528.0], [63.5, 528.0], [63.6, 528.0], [63.7, 528.0], [63.8, 528.0], [63.9, 529.0], [64.0, 529.0], [64.1, 529.0], [64.2, 530.0], [64.3, 530.0], [64.4, 530.0], [64.5, 530.0], [64.6, 530.0], [64.7, 530.0], [64.8, 530.0], [64.9, 530.0], [65.0, 530.0], [65.1, 530.0], [65.2, 530.0], [65.3, 530.0], [65.4, 531.0], [65.5, 531.0], [65.6, 531.0], [65.7, 531.0], [65.8, 531.0], [65.9, 532.0], [66.0, 532.0], [66.1, 532.0], [66.2, 532.0], [66.3, 532.0], [66.4, 532.0], [66.5, 533.0], [66.6, 533.0], [66.7, 533.0], [66.8, 533.0], [66.9, 533.0], [67.0, 533.0], [67.1, 534.0], [67.2, 534.0], [67.3, 534.0], [67.4, 534.0], [67.5, 534.0], [67.6, 534.0], [67.7, 534.0], [67.8, 534.0], [67.9, 534.0], [68.0, 535.0], [68.1, 535.0], [68.2, 535.0], [68.3, 535.0], [68.4, 535.0], [68.5, 535.0], [68.6, 535.0], [68.7, 535.0], [68.8, 535.0], [68.9, 535.0], [69.0, 535.0], [69.1, 535.0], [69.2, 535.0], [69.3, 535.0], [69.4, 536.0], [69.5, 536.0], [69.6, 536.0], [69.7, 536.0], [69.8, 536.0], [69.9, 536.0], [70.0, 536.0], [70.1, 536.0], [70.2, 536.0], [70.3, 536.0], [70.4, 536.0], [70.5, 536.0], [70.6, 537.0], [70.7, 537.0], [70.8, 537.0], [70.9, 539.0], [71.0, 539.0], [71.1, 539.0], [71.2, 539.0], [71.3, 539.0], [71.4, 539.0], [71.5, 539.0], [71.6, 539.0], [71.7, 539.0], [71.8, 539.0], [71.9, 539.0], [72.0, 539.0], [72.1, 540.0], [72.2, 540.0], [72.3, 540.0], [72.4, 542.0], [72.5, 542.0], [72.6, 542.0], [72.7, 542.0], [72.8, 542.0], [72.9, 543.0], [73.0, 543.0], [73.1, 543.0], [73.2, 543.0], [73.3, 543.0], [73.4, 543.0], [73.5, 544.0], [73.6, 544.0], [73.7, 544.0], [73.8, 545.0], [73.9, 545.0], [74.0, 545.0], [74.1, 545.0], [74.2, 545.0], [74.3, 545.0], [74.4, 546.0], [74.5, 546.0], [74.6, 546.0], [74.7, 547.0], [74.8, 547.0], [74.9, 547.0], [75.0, 547.0], [75.1, 547.0], [75.2, 547.0], [75.3, 548.0], [75.4, 548.0], [75.5, 548.0], [75.6, 548.0], [75.7, 548.0], [75.8, 548.0], [75.9, 549.0], [76.0, 549.0], [76.1, 550.0], [76.2, 550.0], [76.3, 550.0], [76.4, 558.0], [76.5, 558.0], [76.6, 558.0], [76.7, 562.0], [76.8, 562.0], [76.9, 562.0], [77.0, 563.0], [77.1, 563.0], [77.2, 563.0], [77.3, 565.0], [77.4, 565.0], [77.5, 565.0], [77.6, 566.0], [77.7, 566.0], [77.8, 566.0], [77.9, 571.0], [78.0, 571.0], [78.1, 571.0], [78.2, 572.0], [78.3, 572.0], [78.4, 572.0], [78.5, 580.0], [78.6, 580.0], [78.7, 580.0], [78.8, 599.0], [78.9, 599.0], [79.0, 599.0], [79.1, 615.0], [79.2, 615.0], [79.3, 615.0], [79.4, 662.0], [79.5, 662.0], [79.6, 674.0], [79.7, 674.0], [79.8, 674.0], [79.9, 680.0], [80.0, 680.0], [80.1, 680.0], [80.2, 685.0], [80.3, 685.0], [80.4, 685.0], [80.5, 695.0], [80.6, 695.0], [80.7, 695.0], [80.8, 699.0], [80.9, 699.0], [81.0, 699.0], [81.1, 707.0], [81.2, 707.0], [81.3, 707.0], [81.4, 709.0], [81.5, 709.0], [81.6, 709.0], [81.7, 710.0], [81.8, 710.0], [81.9, 710.0], [82.0, 713.0], [82.1, 713.0], [82.2, 713.0], [82.3, 723.0], [82.4, 723.0], [82.5, 723.0], [82.6, 723.0], [82.7, 723.0], [82.8, 727.0], [82.9, 727.0], [83.0, 727.0], [83.1, 731.0], [83.2, 731.0], [83.3, 731.0], [83.4, 741.0], [83.5, 741.0], [83.6, 741.0], [83.7, 742.0], [83.8, 742.0], [83.9, 742.0], [84.0, 743.0], [84.1, 743.0], [84.2, 743.0], [84.3, 744.0], [84.4, 744.0], [84.5, 744.0], [84.6, 748.0], [84.7, 748.0], [84.8, 748.0], [84.9, 748.0], [85.0, 748.0], [85.1, 748.0], [85.2, 755.0], [85.3, 755.0], [85.4, 755.0], [85.5, 756.0], [85.6, 756.0], [85.7, 756.0], [85.8, 767.0], [85.9, 767.0], [86.0, 767.0], [86.1, 768.0], [86.2, 768.0], [86.3, 771.0], [86.4, 771.0], [86.5, 771.0], [86.6, 772.0], [86.7, 772.0], [86.8, 772.0], [86.9, 774.0], [87.0, 774.0], [87.1, 774.0], [87.2, 784.0], [87.3, 784.0], [87.4, 784.0], [87.5, 784.0], [87.6, 784.0], [87.7, 784.0], [87.8, 798.0], [87.9, 798.0], [88.0, 798.0], [88.1, 798.0], [88.2, 798.0], [88.3, 798.0], [88.4, 815.0], [88.5, 815.0], [88.6, 815.0], [88.7, 889.0], [88.8, 889.0], [88.9, 889.0], [89.0, 1075.0], [89.1, 1075.0], [89.2, 1075.0], [89.3, 1114.0], [89.4, 1114.0], [89.5, 1114.0], [89.6, 1121.0], [89.7, 1121.0], [89.8, 1128.0], [89.9, 1128.0], [90.0, 1128.0], [90.1, 1145.0], [90.2, 1145.0], [90.3, 1145.0], [90.4, 1146.0], [90.5, 1146.0], [90.6, 1146.0], [90.7, 1147.0], [90.8, 1147.0], [90.9, 1147.0], [91.0, 1149.0], [91.1, 1149.0], [91.2, 1149.0], [91.3, 1153.0], [91.4, 1153.0], [91.5, 1153.0], [91.6, 1171.0], [91.7, 1171.0], [91.8, 1171.0], [91.9, 1190.0], [92.0, 1190.0], [92.1, 1190.0], [92.2, 1192.0], [92.3, 1192.0], [92.4, 1192.0], [92.5, 1236.0], [92.6, 1236.0], [92.7, 1236.0], [92.8, 1242.0], [92.9, 1242.0], [93.0, 1242.0], [93.1, 1259.0], [93.2, 1259.0], [93.3, 1288.0], [93.4, 1288.0], [93.5, 1288.0], [93.6, 1298.0], [93.7, 1298.0], [93.8, 1298.0], [93.9, 1299.0], [94.0, 1299.0], [94.1, 1299.0], [94.2, 1381.0], [94.3, 1381.0], [94.4, 1381.0], [94.5, 1584.0], [94.6, 1584.0], [94.7, 1584.0], [94.8, 1699.0], [94.9, 1699.0], [95.0, 1699.0], [95.1, 1739.0], [95.2, 1739.0], [95.3, 1739.0], [95.4, 1744.0], [95.5, 1744.0], [95.6, 1744.0], [95.7, 1823.0], [95.8, 1823.0], [95.9, 1823.0], [96.0, 1845.0], [96.1, 1845.0], [96.2, 1845.0], [96.3, 1850.0], [96.4, 1850.0], [96.5, 1850.0], [96.6, 1869.0], [96.7, 1869.0], [96.8, 1869.0], [96.9, 1869.0], [97.0, 1869.0], [97.1, 1913.0], [97.2, 1913.0], [97.3, 1913.0], [97.4, 2121.0], [97.5, 2121.0], [97.6, 2121.0], [97.7, 2168.0], [97.8, 2168.0], [97.9, 2168.0], [98.0, 2231.0], [98.1, 2231.0], [98.2, 2231.0], [98.3, 2512.0], [98.4, 2512.0], [98.5, 2512.0], [98.6, 3215.0], [98.7, 3215.0], [98.8, 3215.0], [98.9, 3249.0], [99.0, 3249.0], [99.1, 3249.0], [99.2, 3392.0], [99.3, 3392.0], [99.4, 3392.0], [99.5, 3475.0], [99.6, 3475.0], [99.7, 3475.0], [99.8, 3512.0], [99.9, 3512.0], [100.0, 3512.0]], "isOverall": false, "label": "GET - List Orders", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 400.0, "maxY": 157.0, "series": [{"data": [[2100.0, 2.0], [2200.0, 1.0], [600.0, 7.0], [2500.0, 1.0], [700.0, 25.0], [3200.0, 2.0], [800.0, 2.0], [3300.0, 1.0], [3400.0, 1.0], [3500.0, 1.0], [1000.0, 1.0], [1100.0, 11.0], [1200.0, 6.0], [1300.0, 1.0], [1500.0, 1.0], [400.0, 114.0], [1600.0, 1.0], [1700.0, 2.0], [1800.0, 5.0], [1900.0, 1.0], [500.0, 157.0]], "isOverall": false, "label": "GET - List Orders", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 3500.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 19.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 207.0, "series": [{"data": [[0.0, 117.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 207.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [[2.0, 19.0]], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 2.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 5.0, "minX": 1.7923024E12, "maxY": 10.0, "series": [{"data": [[1.79230242E12, 10.0], [1.7923024E12, 5.0], [1.79230246E12, 7.555555555555555], [1.79230244E12, 10.0], [1.792302435E12, 10.0], [1.792302415E12, 10.0], [1.792302455E12, 10.0], [1.79230243E12, 10.0], [1.79230241E12, 10.0], [1.79230245E12, 10.0], [1.792302425E12, 10.0], [1.792302405E12, 9.458333333333332], [1.792302445E12, 10.0]], "isOverall": false, "label": "Thread Group", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.79230246E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 488.0, "minX": 1.0, "maxY": 2231.0, "series": [{"data": [[8.0, 650.0], [4.0, 1823.0], [2.0, 488.0], [1.0, 498.0], [9.0, 701.6666666666666], [5.0, 935.5], [10.0, 656.7461773700308], [6.0, 843.5], [3.0, 2231.0], [7.0, 1192.0]], "isOverall": false, "label": "GET - List Orders", "isController": false}, {"data": [[9.819241982507295, 668.3702623906701]], "isOverall": false, "label": "GET - List Orders-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 10.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 307.2, "minX": 1.7923024E12, "maxY": 50462.8, "series": [{"data": [[1.79230242E12, 34136.6], [1.7923024E12, 1484.2], [1.79230246E12, 26715.6], [1.79230244E12, 50462.8], [1.792302435E12, 44526.0], [1.792302415E12, 50462.8], [1.792302455E12, 47494.4], [1.79230243E12, 44529.8], [1.79230241E12, 48978.6], [1.79230245E12, 47494.4], [1.792302425E12, 34136.6], [1.792302405E12, 35620.8], [1.792302445E12, 43041.8]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.79230242E12, 7065.6], [1.7923024E12, 307.2], [1.79230246E12, 5529.6], [1.79230244E12, 10444.8], [1.792302435E12, 9216.0], [1.792302415E12, 10444.8], [1.792302455E12, 9830.4], [1.79230243E12, 9216.0], [1.79230241E12, 10137.6], [1.79230245E12, 9830.4], [1.792302425E12, 7065.6], [1.792302405E12, 7372.8], [1.792302445E12, 8908.8]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.79230246E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 490.6176470588235, "minX": 1.7923024E12, "maxY": 1381.0, "series": [{"data": [[1.79230242E12, 1021.8260869565217], [1.7923024E12, 1381.0], [1.79230246E12, 668.5], [1.79230244E12, 527.3529411764706], [1.792302435E12, 536.6666666666666], [1.792302415E12, 490.6176470588235], [1.792302455E12, 530.125], [1.79230243E12, 946.7666666666665], [1.79230241E12, 502.9393939393939], [1.79230245E12, 519.53125], [1.792302425E12, 945.5652173913043], [1.792302405E12, 736.1249999999999], [1.792302445E12, 814.4827586206897]], "isOverall": false, "label": "GET - List Orders", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.79230246E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 490.55882352941177, "minX": 1.7923024E12, "maxY": 1378.0, "series": [{"data": [[1.79230242E12, 1021.391304347826], [1.7923024E12, 1378.0], [1.79230246E12, 667.6666666666666], [1.79230244E12, 527.3529411764706], [1.792302435E12, 536.1333333333333], [1.792302415E12, 490.55882352941177], [1.792302455E12, 530.125], [1.79230243E12, 933.1666666666667], [1.79230241E12, 502.9393939393939], [1.79230245E12, 518.4687499999999], [1.792302425E12, 945.5217391304348], [1.792302405E12, 736.1249999999999], [1.792302445E12, 814.4482758620691]], "isOverall": false, "label": "GET - List Orders", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.79230246E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 0.0, "minX": 1.7923024E12, "maxY": 876.0, "series": [{"data": [[1.79230242E12, 0.0], [1.7923024E12, 876.0], [1.79230246E12, 0.0], [1.79230244E12, 0.0], [1.792302435E12, 0.0], [1.792302415E12, 0.0], [1.792302455E12, 0.0], [1.79230243E12, 0.0], [1.79230241E12, 0.0], [1.79230245E12, 0.0], [1.792302425E12, 0.0], [1.792302405E12, 248.16666666666666], [1.792302445E12, 0.0]], "isOverall": false, "label": "GET - List Orders", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.79230246E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 466.0, "minX": 1.7923024E12, "maxY": 3512.0, "series": [{"data": [[1.79230242E12, 3249.0], [1.7923024E12, 1381.0], [1.79230246E12, 2231.0], [1.79230244E12, 727.0], [1.792302435E12, 768.0], [1.792302415E12, 540.0], [1.792302455E12, 815.0], [1.79230243E12, 3512.0], [1.79230241E12, 539.0], [1.79230245E12, 771.0], [1.792302425E12, 2168.0], [1.792302405E12, 1192.0], [1.792302445E12, 2512.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.79230242E12, 474.0], [1.7923024E12, 1381.0], [1.79230246E12, 481.0], [1.79230244E12, 476.0], [1.792302435E12, 494.0], [1.792302415E12, 466.0], [1.792302455E12, 481.0], [1.79230243E12, 495.0], [1.79230241E12, 474.0], [1.79230245E12, 487.0], [1.792302425E12, 478.0], [1.792302405E12, 470.0], [1.792302445E12, 493.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.79230242E12, 1895.4], [1.7923024E12, 1381.0], [1.79230246E12, 1863.8000000000006], [1.79230244E12, 607.0], [1.792302435E12, 571.1], [1.792302415E12, 518.0], [1.792302455E12, 656.3], [1.79230243E12, 3374.3], [1.79230241E12, 539.0], [1.79230245E12, 544.1], [1.792302425E12, 1742.0], [1.792302405E12, 1171.5], [1.792302445E12, 1869.0]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.79230242E12, 3249.0], [1.7923024E12, 1381.0], [1.79230246E12, 2231.0], [1.79230244E12, 727.0], [1.792302435E12, 768.0], [1.792302415E12, 540.0], [1.792302455E12, 815.0], [1.79230243E12, 3512.0], [1.79230241E12, 539.0], [1.79230245E12, 771.0], [1.792302425E12, 2168.0], [1.792302405E12, 1192.0], [1.792302445E12, 2512.0]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.79230242E12, 680.0], [1.7923024E12, 1381.0], [1.79230246E12, 497.0], [1.79230244E12, 507.5], [1.792302435E12, 521.0], [1.792302415E12, 486.0], [1.792302455E12, 503.5], [1.79230243E12, 539.0], [1.79230241E12, 502.0], [1.79230245E12, 505.5], [1.792302425E12, 756.0], [1.792302405E12, 494.0], [1.792302445E12, 580.0]], "isOverall": false, "label": "Median", "isController": false}, {"data": [[1.79230242E12, 2981.799999999996], [1.7923024E12, 1381.0], [1.79230246E12, 2231.0], [1.79230244E12, 678.25], [1.792302435E12, 753.15], [1.792302415E12, 536.25], [1.792302455E12, 739.5999999999998], [1.79230243E12, 3491.65], [1.79230241E12, 539.0], [1.79230245E12, 715.0999999999998], [1.792302425E12, 2083.199999999999], [1.792302405E12, 1191.5], [1.792302445E12, 2316.5]], "isOverall": false, "label": "95th percentile", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.79230246E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 502.0, "minX": 1.0, "maxY": 1381.0, "series": [{"data": [[1.0, 1381.0], [2.0, 633.5], [4.0, 610.5], [8.0, 511.0], [9.0, 516.0], [5.0, 519.0], [6.0, 503.5], [3.0, 547.5], [7.0, 502.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 9.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 502.0, "minX": 1.0, "maxY": 1378.0, "series": [{"data": [[1.0, 1378.0], [2.0, 633.5], [4.0, 610.5], [8.0, 511.0], [9.0, 516.0], [5.0, 519.0], [6.0, 502.5], [3.0, 547.5], [7.0, 502.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 9.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 0.8, "minX": 1.7923024E12, "maxY": 7.6, "series": [{"data": [[1.79230242E12, 5.0], [1.7923024E12, 0.8], [1.79230246E12, 2.4], [1.79230244E12, 6.2], [1.792302435E12, 7.6], [1.792302415E12, 6.6], [1.792302455E12, 7.0], [1.79230243E12, 5.2], [1.79230241E12, 6.8], [1.79230245E12, 6.4], [1.792302425E12, 4.4], [1.792302405E12, 4.8], [1.792302445E12, 5.4]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.79230246E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 0.2, "minX": 1.7923024E12, "maxY": 6.8, "series": [{"data": [[1.79230242E12, 4.6], [1.7923024E12, 0.2], [1.79230246E12, 3.6], [1.79230244E12, 6.8], [1.792302435E12, 6.0], [1.792302415E12, 6.8], [1.792302455E12, 6.4], [1.79230243E12, 6.0], [1.79230241E12, 6.6], [1.79230245E12, 6.4], [1.792302425E12, 4.6], [1.792302405E12, 4.8], [1.792302445E12, 5.8]], "isOverall": false, "label": "200", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.79230246E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 0.2, "minX": 1.7923024E12, "maxY": 6.8, "series": [{"data": [[1.79230242E12, 4.6], [1.7923024E12, 0.2], [1.79230246E12, 3.6], [1.79230244E12, 6.8], [1.792302435E12, 6.0], [1.792302415E12, 6.8], [1.792302455E12, 6.4], [1.79230243E12, 6.0], [1.79230241E12, 6.6], [1.79230245E12, 6.4], [1.792302425E12, 4.6], [1.792302405E12, 4.8], [1.792302445E12, 5.8]], "isOverall": false, "label": "GET - List Orders-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.79230246E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 0.2, "minX": 1.7923024E12, "maxY": 6.8, "series": [{"data": [[1.79230242E12, 4.6], [1.7923024E12, 0.2], [1.79230246E12, 3.6], [1.79230244E12, 6.8], [1.792302435E12, 6.0], [1.792302415E12, 6.8], [1.792302455E12, 6.4], [1.79230243E12, 6.0], [1.79230241E12, 6.6], [1.79230245E12, 6.4], [1.792302425E12, 4.6], [1.792302405E12, 4.8], [1.792302445E12, 5.8]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.79230246E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

