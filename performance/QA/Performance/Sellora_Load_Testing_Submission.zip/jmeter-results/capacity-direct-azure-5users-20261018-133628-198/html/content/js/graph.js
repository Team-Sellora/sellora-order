/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 114.0, "minX": 0.0, "maxY": 2101.0, "series": [{"data": [[0.0, 114.0], [0.1, 114.0], [0.2, 115.0], [0.3, 115.0], [0.4, 118.0], [0.5, 119.0], [0.6, 119.0], [0.7, 120.0], [0.8, 120.0], [0.9, 120.0], [1.0, 121.0], [1.1, 121.0], [1.2, 121.0], [1.3, 121.0], [1.4, 121.0], [1.5, 121.0], [1.6, 121.0], [1.7, 121.0], [1.8, 121.0], [1.9, 122.0], [2.0, 122.0], [2.1, 122.0], [2.2, 122.0], [2.3, 122.0], [2.4, 122.0], [2.5, 123.0], [2.6, 123.0], [2.7, 123.0], [2.8, 123.0], [2.9, 123.0], [3.0, 123.0], [3.1, 123.0], [3.2, 123.0], [3.3, 123.0], [3.4, 123.0], [3.5, 124.0], [3.6, 124.0], [3.7, 124.0], [3.8, 124.0], [3.9, 124.0], [4.0, 124.0], [4.1, 124.0], [4.2, 124.0], [4.3, 125.0], [4.4, 125.0], [4.5, 125.0], [4.6, 125.0], [4.7, 125.0], [4.8, 125.0], [4.9, 125.0], [5.0, 126.0], [5.1, 126.0], [5.2, 126.0], [5.3, 126.0], [5.4, 126.0], [5.5, 126.0], [5.6, 126.0], [5.7, 126.0], [5.8, 126.0], [5.9, 126.0], [6.0, 126.0], [6.1, 126.0], [6.2, 126.0], [6.3, 126.0], [6.4, 126.0], [6.5, 126.0], [6.6, 126.0], [6.7, 126.0], [6.8, 126.0], [6.9, 126.0], [7.0, 126.0], [7.1, 127.0], [7.2, 127.0], [7.3, 127.0], [7.4, 127.0], [7.5, 127.0], [7.6, 127.0], [7.7, 127.0], [7.8, 127.0], [7.9, 127.0], [8.0, 127.0], [8.1, 127.0], [8.2, 127.0], [8.3, 127.0], [8.4, 128.0], [8.5, 128.0], [8.6, 128.0], [8.7, 128.0], [8.8, 128.0], [8.9, 128.0], [9.0, 128.0], [9.1, 128.0], [9.2, 128.0], [9.3, 128.0], [9.4, 129.0], [9.5, 129.0], [9.6, 129.0], [9.7, 129.0], [9.8, 129.0], [9.9, 129.0], [10.0, 129.0], [10.1, 129.0], [10.2, 129.0], [10.3, 129.0], [10.4, 129.0], [10.5, 129.0], [10.6, 129.0], [10.7, 129.0], [10.8, 129.0], [10.9, 130.0], [11.0, 130.0], [11.1, 130.0], [11.2, 130.0], [11.3, 130.0], [11.4, 130.0], [11.5, 130.0], [11.6, 130.0], [11.7, 130.0], [11.8, 130.0], [11.9, 130.0], [12.0, 130.0], [12.1, 130.0], [12.2, 130.0], [12.3, 130.0], [12.4, 130.0], [12.5, 130.0], [12.6, 130.0], [12.7, 130.0], [12.8, 130.0], [12.9, 131.0], [13.0, 131.0], [13.1, 131.0], [13.2, 131.0], [13.3, 131.0], [13.4, 131.0], [13.5, 131.0], [13.6, 131.0], [13.7, 131.0], [13.8, 131.0], [13.9, 131.0], [14.0, 132.0], [14.1, 132.0], [14.2, 132.0], [14.3, 132.0], [14.4, 132.0], [14.5, 132.0], [14.6, 132.0], [14.7, 132.0], [14.8, 132.0], [14.9, 132.0], [15.0, 132.0], [15.1, 132.0], [15.2, 132.0], [15.3, 132.0], [15.4, 132.0], [15.5, 132.0], [15.6, 132.0], [15.7, 132.0], [15.8, 132.0], [15.9, 132.0], [16.0, 132.0], [16.1, 132.0], [16.2, 133.0], [16.3, 133.0], [16.4, 133.0], [16.5, 133.0], [16.6, 133.0], [16.7, 133.0], [16.8, 133.0], [16.9, 133.0], [17.0, 133.0], [17.1, 133.0], [17.2, 133.0], [17.3, 133.0], [17.4, 133.0], [17.5, 134.0], [17.6, 134.0], [17.7, 134.0], [17.8, 134.0], [17.9, 134.0], [18.0, 134.0], [18.1, 134.0], [18.2, 134.0], [18.3, 134.0], [18.4, 134.0], [18.5, 134.0], [18.6, 134.0], [18.7, 134.0], [18.8, 134.0], [18.9, 134.0], [19.0, 134.0], [19.1, 134.0], [19.2, 134.0], [19.3, 134.0], [19.4, 134.0], [19.5, 134.0], [19.6, 135.0], [19.7, 135.0], [19.8, 135.0], [19.9, 135.0], [20.0, 135.0], [20.1, 135.0], [20.2, 135.0], [20.3, 135.0], [20.4, 135.0], [20.5, 135.0], [20.6, 135.0], [20.7, 135.0], [20.8, 135.0], [20.9, 135.0], [21.0, 135.0], [21.1, 135.0], [21.2, 135.0], [21.3, 136.0], [21.4, 136.0], [21.5, 136.0], [21.6, 136.0], [21.7, 136.0], [21.8, 136.0], [21.9, 136.0], [22.0, 136.0], [22.1, 136.0], [22.2, 136.0], [22.3, 136.0], [22.4, 136.0], [22.5, 136.0], [22.6, 136.0], [22.7, 136.0], [22.8, 136.0], [22.9, 136.0], [23.0, 136.0], [23.1, 137.0], [23.2, 137.0], [23.3, 137.0], [23.4, 137.0], [23.5, 137.0], [23.6, 137.0], [23.7, 137.0], [23.8, 137.0], [23.9, 137.0], [24.0, 137.0], [24.1, 137.0], [24.2, 137.0], [24.3, 137.0], [24.4, 137.0], [24.5, 137.0], [24.6, 138.0], [24.7, 138.0], [24.8, 138.0], [24.9, 138.0], [25.0, 138.0], [25.1, 138.0], [25.2, 138.0], [25.3, 138.0], [25.4, 138.0], [25.5, 138.0], [25.6, 138.0], [25.7, 138.0], [25.8, 138.0], [25.9, 138.0], [26.0, 138.0], [26.1, 138.0], [26.2, 139.0], [26.3, 139.0], [26.4, 139.0], [26.5, 139.0], [26.6, 139.0], [26.7, 139.0], [26.8, 139.0], [26.9, 139.0], [27.0, 139.0], [27.1, 139.0], [27.2, 139.0], [27.3, 139.0], [27.4, 139.0], [27.5, 139.0], [27.6, 139.0], [27.7, 139.0], [27.8, 139.0], [27.9, 139.0], [28.0, 139.0], [28.1, 139.0], [28.2, 140.0], [28.3, 140.0], [28.4, 140.0], [28.5, 140.0], [28.6, 140.0], [28.7, 140.0], [28.8, 140.0], [28.9, 140.0], [29.0, 140.0], [29.1, 140.0], [29.2, 140.0], [29.3, 140.0], [29.4, 140.0], [29.5, 140.0], [29.6, 140.0], [29.7, 140.0], [29.8, 140.0], [29.9, 140.0], [30.0, 140.0], [30.1, 140.0], [30.2, 140.0], [30.3, 140.0], [30.4, 140.0], [30.5, 140.0], [30.6, 140.0], [30.7, 140.0], [30.8, 141.0], [30.9, 141.0], [31.0, 141.0], [31.1, 141.0], [31.2, 141.0], [31.3, 141.0], [31.4, 141.0], [31.5, 141.0], [31.6, 141.0], [31.7, 141.0], [31.8, 141.0], [31.9, 141.0], [32.0, 141.0], [32.1, 141.0], [32.2, 141.0], [32.3, 142.0], [32.4, 142.0], [32.5, 142.0], [32.6, 142.0], [32.7, 142.0], [32.8, 142.0], [32.9, 142.0], [33.0, 142.0], [33.1, 142.0], [33.2, 142.0], [33.3, 142.0], [33.4, 142.0], [33.5, 142.0], [33.6, 142.0], [33.7, 142.0], [33.8, 142.0], [33.9, 143.0], [34.0, 143.0], [34.1, 143.0], [34.2, 143.0], [34.3, 143.0], [34.4, 143.0], [34.5, 143.0], [34.6, 143.0], [34.7, 143.0], [34.8, 143.0], [34.9, 143.0], [35.0, 143.0], [35.1, 143.0], [35.2, 143.0], [35.3, 143.0], [35.4, 143.0], [35.5, 143.0], [35.6, 144.0], [35.7, 144.0], [35.8, 144.0], [35.9, 144.0], [36.0, 144.0], [36.1, 144.0], [36.2, 144.0], [36.3, 144.0], [36.4, 144.0], [36.5, 144.0], [36.6, 144.0], [36.7, 144.0], [36.8, 144.0], [36.9, 144.0], [37.0, 144.0], [37.1, 144.0], [37.2, 144.0], [37.3, 144.0], [37.4, 144.0], [37.5, 144.0], [37.6, 144.0], [37.7, 144.0], [37.8, 144.0], [37.9, 144.0], [38.0, 144.0], [38.1, 144.0], [38.2, 145.0], [38.3, 145.0], [38.4, 145.0], [38.5, 145.0], [38.6, 145.0], [38.7, 145.0], [38.8, 145.0], [38.9, 145.0], [39.0, 145.0], [39.1, 145.0], [39.2, 145.0], [39.3, 145.0], [39.4, 145.0], [39.5, 145.0], [39.6, 145.0], [39.7, 145.0], [39.8, 145.0], [39.9, 145.0], [40.0, 145.0], [40.1, 145.0], [40.2, 145.0], [40.3, 145.0], [40.4, 145.0], [40.5, 145.0], [40.6, 145.0], [40.7, 145.0], [40.8, 146.0], [40.9, 146.0], [41.0, 146.0], [41.1, 146.0], [41.2, 146.0], [41.3, 146.0], [41.4, 146.0], [41.5, 146.0], [41.6, 146.0], [41.7, 146.0], [41.8, 146.0], [41.9, 146.0], [42.0, 146.0], [42.1, 146.0], [42.2, 146.0], [42.3, 146.0], [42.4, 146.0], [42.5, 146.0], [42.6, 146.0], [42.7, 146.0], [42.8, 146.0], [42.9, 146.0], [43.0, 146.0], [43.1, 147.0], [43.2, 147.0], [43.3, 147.0], [43.4, 147.0], [43.5, 147.0], [43.6, 147.0], [43.7, 147.0], [43.8, 147.0], [43.9, 147.0], [44.0, 147.0], [44.1, 147.0], [44.2, 147.0], [44.3, 147.0], [44.4, 147.0], [44.5, 147.0], [44.6, 147.0], [44.7, 147.0], [44.8, 147.0], [44.9, 147.0], [45.0, 148.0], [45.1, 148.0], [45.2, 148.0], [45.3, 148.0], [45.4, 148.0], [45.5, 148.0], [45.6, 148.0], [45.7, 148.0], [45.8, 148.0], [45.9, 148.0], [46.0, 148.0], [46.1, 148.0], [46.2, 148.0], [46.3, 148.0], [46.4, 148.0], [46.5, 148.0], [46.6, 148.0], [46.7, 148.0], [46.8, 148.0], [46.9, 148.0], [47.0, 148.0], [47.1, 149.0], [47.2, 149.0], [47.3, 149.0], [47.4, 149.0], [47.5, 149.0], [47.6, 149.0], [47.7, 149.0], [47.8, 149.0], [47.9, 149.0], [48.0, 149.0], [48.1, 149.0], [48.2, 149.0], [48.3, 149.0], [48.4, 149.0], [48.5, 149.0], [48.6, 150.0], [48.7, 150.0], [48.8, 150.0], [48.9, 150.0], [49.0, 150.0], [49.1, 150.0], [49.2, 150.0], [49.3, 150.0], [49.4, 150.0], [49.5, 150.0], [49.6, 150.0], [49.7, 150.0], [49.8, 150.0], [49.9, 150.0], [50.0, 150.0], [50.1, 150.0], [50.2, 150.0], [50.3, 150.0], [50.4, 150.0], [50.5, 150.0], [50.6, 150.0], [50.7, 150.0], [50.8, 150.0], [50.9, 151.0], [51.0, 151.0], [51.1, 151.0], [51.2, 151.0], [51.3, 151.0], [51.4, 151.0], [51.5, 151.0], [51.6, 151.0], [51.7, 151.0], [51.8, 151.0], [51.9, 151.0], [52.0, 151.0], [52.1, 151.0], [52.2, 151.0], [52.3, 151.0], [52.4, 151.0], [52.5, 151.0], [52.6, 151.0], [52.7, 152.0], [52.8, 152.0], [52.9, 152.0], [53.0, 152.0], [53.1, 152.0], [53.2, 152.0], [53.3, 152.0], [53.4, 152.0], [53.5, 153.0], [53.6, 153.0], [53.7, 153.0], [53.8, 153.0], [53.9, 153.0], [54.0, 153.0], [54.1, 153.0], [54.2, 153.0], [54.3, 153.0], [54.4, 153.0], [54.5, 153.0], [54.6, 153.0], [54.7, 153.0], [54.8, 154.0], [54.9, 154.0], [55.0, 154.0], [55.1, 154.0], [55.2, 154.0], [55.3, 154.0], [55.4, 154.0], [55.5, 154.0], [55.6, 154.0], [55.7, 154.0], [55.8, 154.0], [55.9, 154.0], [56.0, 154.0], [56.1, 155.0], [56.2, 155.0], [56.3, 155.0], [56.4, 155.0], [56.5, 155.0], [56.6, 155.0], [56.7, 155.0], [56.8, 155.0], [56.9, 155.0], [57.0, 155.0], [57.1, 155.0], [57.2, 155.0], [57.3, 156.0], [57.4, 156.0], [57.5, 156.0], [57.6, 156.0], [57.7, 156.0], [57.8, 156.0], [57.9, 156.0], [58.0, 156.0], [58.1, 156.0], [58.2, 156.0], [58.3, 157.0], [58.4, 157.0], [58.5, 157.0], [58.6, 157.0], [58.7, 157.0], [58.8, 157.0], [58.9, 157.0], [59.0, 157.0], [59.1, 157.0], [59.2, 157.0], [59.3, 157.0], [59.4, 157.0], [59.5, 157.0], [59.6, 158.0], [59.7, 158.0], [59.8, 158.0], [59.9, 158.0], [60.0, 158.0], [60.1, 158.0], [60.2, 158.0], [60.3, 158.0], [60.4, 158.0], [60.5, 158.0], [60.6, 158.0], [60.7, 158.0], [60.8, 158.0], [60.9, 158.0], [61.0, 158.0], [61.1, 158.0], [61.2, 159.0], [61.3, 159.0], [61.4, 159.0], [61.5, 159.0], [61.6, 159.0], [61.7, 159.0], [61.8, 159.0], [61.9, 159.0], [62.0, 159.0], [62.1, 159.0], [62.2, 159.0], [62.3, 159.0], [62.4, 159.0], [62.5, 159.0], [62.6, 159.0], [62.7, 159.0], [62.8, 159.0], [62.9, 159.0], [63.0, 159.0], [63.1, 159.0], [63.2, 160.0], [63.3, 160.0], [63.4, 160.0], [63.5, 160.0], [63.6, 160.0], [63.7, 160.0], [63.8, 160.0], [63.9, 160.0], [64.0, 160.0], [64.1, 160.0], [64.2, 160.0], [64.3, 160.0], [64.4, 161.0], [64.5, 161.0], [64.6, 161.0], [64.7, 161.0], [64.8, 161.0], [64.9, 162.0], [65.0, 162.0], [65.1, 162.0], [65.2, 162.0], [65.3, 162.0], [65.4, 162.0], [65.5, 163.0], [65.6, 163.0], [65.7, 163.0], [65.8, 163.0], [65.9, 163.0], [66.0, 163.0], [66.1, 163.0], [66.2, 164.0], [66.3, 164.0], [66.4, 164.0], [66.5, 164.0], [66.6, 164.0], [66.7, 164.0], [66.8, 165.0], [66.9, 165.0], [67.0, 165.0], [67.1, 165.0], [67.2, 165.0], [67.3, 165.0], [67.4, 165.0], [67.5, 165.0], [67.6, 165.0], [67.7, 165.0], [67.8, 166.0], [67.9, 166.0], [68.0, 166.0], [68.1, 166.0], [68.2, 166.0], [68.3, 166.0], [68.4, 166.0], [68.5, 166.0], [68.6, 166.0], [68.7, 166.0], [68.8, 167.0], [68.9, 167.0], [69.0, 167.0], [69.1, 167.0], [69.2, 167.0], [69.3, 167.0], [69.4, 167.0], [69.5, 167.0], [69.6, 167.0], [69.7, 167.0], [69.8, 167.0], [69.9, 167.0], [70.0, 167.0], [70.1, 167.0], [70.2, 167.0], [70.3, 168.0], [70.4, 168.0], [70.5, 168.0], [70.6, 168.0], [70.7, 168.0], [70.8, 168.0], [70.9, 168.0], [71.0, 168.0], [71.1, 169.0], [71.2, 169.0], [71.3, 169.0], [71.4, 169.0], [71.5, 169.0], [71.6, 169.0], [71.7, 169.0], [71.8, 169.0], [71.9, 170.0], [72.0, 170.0], [72.1, 170.0], [72.2, 170.0], [72.3, 170.0], [72.4, 171.0], [72.5, 171.0], [72.6, 171.0], [72.7, 171.0], [72.8, 171.0], [72.9, 171.0], [73.0, 171.0], [73.1, 171.0], [73.2, 172.0], [73.3, 172.0], [73.4, 172.0], [73.5, 172.0], [73.6, 172.0], [73.7, 172.0], [73.8, 172.0], [73.9, 172.0], [74.0, 172.0], [74.1, 172.0], [74.2, 173.0], [74.3, 173.0], [74.4, 173.0], [74.5, 173.0], [74.6, 174.0], [74.7, 174.0], [74.8, 174.0], [74.9, 174.0], [75.0, 174.0], [75.1, 175.0], [75.2, 175.0], [75.3, 175.0], [75.4, 175.0], [75.5, 176.0], [75.6, 176.0], [75.7, 176.0], [75.8, 176.0], [75.9, 176.0], [76.0, 177.0], [76.1, 177.0], [76.2, 177.0], [76.3, 177.0], [76.4, 178.0], [76.5, 178.0], [76.6, 178.0], [76.7, 178.0], [76.8, 178.0], [76.9, 178.0], [77.0, 179.0], [77.1, 179.0], [77.2, 179.0], [77.3, 179.0], [77.4, 180.0], [77.5, 180.0], [77.6, 180.0], [77.7, 182.0], [77.8, 184.0], [77.9, 184.0], [78.0, 184.0], [78.1, 184.0], [78.2, 184.0], [78.3, 185.0], [78.4, 185.0], [78.5, 186.0], [78.6, 186.0], [78.7, 186.0], [78.8, 187.0], [78.9, 187.0], [79.0, 187.0], [79.1, 187.0], [79.2, 187.0], [79.3, 187.0], [79.4, 187.0], [79.5, 188.0], [79.6, 188.0], [79.7, 189.0], [79.8, 189.0], [79.9, 189.0], [80.0, 190.0], [80.1, 192.0], [80.2, 192.0], [80.3, 192.0], [80.4, 192.0], [80.5, 193.0], [80.6, 195.0], [80.7, 195.0], [80.8, 195.0], [80.9, 195.0], [81.0, 195.0], [81.1, 196.0], [81.2, 196.0], [81.3, 196.0], [81.4, 196.0], [81.5, 197.0], [81.6, 200.0], [81.7, 200.0], [81.8, 201.0], [81.9, 201.0], [82.0, 203.0], [82.1, 204.0], [82.2, 204.0], [82.3, 205.0], [82.4, 205.0], [82.5, 206.0], [82.6, 206.0], [82.7, 206.0], [82.8, 207.0], [82.9, 208.0], [83.0, 208.0], [83.1, 211.0], [83.2, 211.0], [83.3, 212.0], [83.4, 214.0], [83.5, 214.0], [83.6, 215.0], [83.7, 215.0], [83.8, 216.0], [83.9, 217.0], [84.0, 217.0], [84.1, 217.0], [84.2, 217.0], [84.3, 220.0], [84.4, 223.0], [84.5, 223.0], [84.6, 228.0], [84.7, 228.0], [84.8, 229.0], [84.9, 231.0], [85.0, 231.0], [85.1, 232.0], [85.2, 233.0], [85.3, 233.0], [85.4, 237.0], [85.5, 237.0], [85.6, 238.0], [85.7, 242.0], [85.8, 242.0], [85.9, 248.0], [86.0, 248.0], [86.1, 249.0], [86.2, 251.0], [86.3, 251.0], [86.4, 255.0], [86.5, 255.0], [86.6, 258.0], [86.7, 261.0], [86.8, 261.0], [86.9, 264.0], [87.0, 264.0], [87.1, 268.0], [87.2, 274.0], [87.3, 274.0], [87.4, 290.0], [87.5, 291.0], [87.6, 291.0], [87.7, 293.0], [87.8, 293.0], [87.9, 293.0], [88.0, 313.0], [88.1, 313.0], [88.2, 315.0], [88.3, 315.0], [88.4, 315.0], [88.5, 322.0], [88.6, 322.0], [88.7, 322.0], [88.8, 322.0], [88.9, 325.0], [89.0, 327.0], [89.1, 327.0], [89.2, 334.0], [89.3, 334.0], [89.4, 337.0], [89.5, 342.0], [89.6, 342.0], [89.7, 346.0], [89.8, 346.0], [89.9, 348.0], [90.0, 349.0], [90.1, 349.0], [90.2, 349.0], [90.3, 349.0], [90.4, 349.0], [90.5, 353.0], [90.6, 353.0], [90.7, 354.0], [90.8, 355.0], [90.9, 355.0], [91.0, 355.0], [91.1, 355.0], [91.2, 360.0], [91.3, 377.0], [91.4, 377.0], [91.5, 381.0], [91.6, 381.0], [91.7, 381.0], [91.8, 391.0], [91.9, 391.0], [92.0, 407.0], [92.1, 407.0], [92.2, 414.0], [92.3, 437.0], [92.4, 437.0], [92.5, 463.0], [92.6, 463.0], [92.7, 463.0], [92.8, 471.0], [92.9, 471.0], [93.0, 476.0], [93.1, 481.0], [93.2, 481.0], [93.3, 489.0], [93.4, 489.0], [93.5, 518.0], [93.6, 542.0], [93.7, 542.0], [93.8, 546.0], [93.9, 546.0], [94.0, 564.0], [94.1, 574.0], [94.2, 574.0], [94.3, 576.0], [94.4, 576.0], [94.5, 578.0], [94.6, 586.0], [94.7, 586.0], [94.8, 588.0], [94.9, 588.0], [95.0, 591.0], [95.1, 595.0], [95.2, 595.0], [95.3, 607.0], [95.4, 607.0], [95.5, 607.0], [95.6, 611.0], [95.7, 611.0], [95.8, 611.0], [95.9, 612.0], [96.0, 612.0], [96.1, 617.0], [96.2, 617.0], [96.3, 619.0], [96.4, 624.0], [96.5, 624.0], [96.6, 676.0], [96.7, 676.0], [96.8, 686.0], [96.9, 691.0], [97.0, 691.0], [97.1, 707.0], [97.2, 707.0], [97.3, 742.0], [97.4, 743.0], [97.5, 743.0], [97.6, 773.0], [97.7, 829.0], [97.8, 829.0], [97.9, 865.0], [98.0, 865.0], [98.1, 866.0], [98.2, 933.0], [98.3, 933.0], [98.4, 940.0], [98.5, 940.0], [98.6, 956.0], [98.7, 1075.0], [98.8, 1075.0], [98.9, 1103.0], [99.0, 1103.0], [99.1, 1161.0], [99.2, 1526.0], [99.3, 1526.0], [99.4, 1561.0], [99.5, 1561.0], [99.6, 1561.0], [99.7, 1677.0], [99.8, 1677.0], [99.9, 2101.0]], "isOverall": false, "label": "GET - List Orders Direct Azure", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 100.0, "maxY": 496.0, "series": [{"data": [[2100.0, 1.0], [600.0, 11.0], [700.0, 4.0], [200.0, 39.0], [800.0, 3.0], [900.0, 3.0], [1000.0, 1.0], [1100.0, 2.0], [300.0, 24.0], [1500.0, 3.0], [100.0, 496.0], [400.0, 9.0], [1600.0, 1.0], [500.0, 11.0]], "isOverall": false, "label": "GET - List Orders Direct Azure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 2100.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 5.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 568.0, "series": [{"data": [[0.0, 568.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 35.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [[2.0, 5.0]], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 2.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 4.500000000000001, "minX": 1.79231082E12, "maxY": 5.0, "series": [{"data": [[1.792310895E12, 5.0], [1.79231085E12, 5.0], [1.792310935E12, 5.0], [1.7923109E12, 5.0], [1.79231094E12, 5.0], [1.792310855E12, 5.0], [1.79231082E12, 5.0], [1.792310905E12, 5.0], [1.79231086E12, 5.0], [1.792310945E12, 5.0], [1.792310825E12, 5.0], [1.79231091E12, 5.0], [1.792310865E12, 5.0], [1.79231095E12, 5.0], [1.79231083E12, 5.0], [1.792310915E12, 5.0], [1.79231096E12, 5.0], [1.79231087E12, 5.0], [1.792310955E12, 5.0], [1.792310835E12, 5.0], [1.79231088E12, 5.0], [1.792310965E12, 4.500000000000001], [1.792310875E12, 5.0], [1.79231092E12, 5.0], [1.792310885E12, 5.0], [1.79231084E12, 5.0], [1.792310925E12, 5.0], [1.79231089E12, 5.0], [1.792310845E12, 5.0], [1.79231093E12, 5.0]], "isOverall": false, "label": "Thread Group", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.792310965E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 144.0, "minX": 1.0, "maxY": 211.2996688741719, "series": [{"data": [[4.0, 208.0], [2.0, 153.0], [1.0, 144.0], [5.0, 211.2996688741719], [3.0, 157.0]], "isOverall": false, "label": "GET - List Orders Direct Azure", "isController": false}, {"data": [[4.983552631578948, 210.99835526315763]], "isOverall": false, "label": "GET - List Orders Direct Azure-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 5.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 4384.8, "minX": 1.79231082E12, "maxY": 35222.4, "series": [{"data": [[1.792310895E12, 30819.6], [1.79231085E12, 29352.0], [1.792310935E12, 32287.2], [1.7923109E12, 35222.4], [1.79231094E12, 30819.6], [1.792310855E12, 24950.6], [1.79231082E12, 20546.4], [1.792310905E12, 29353.4], [1.79231086E12, 32287.2], [1.792310945E12, 27884.4], [1.792310825E12, 33754.8], [1.79231091E12, 30819.6], [1.792310865E12, 32287.2], [1.79231095E12, 29353.4], [1.79231083E12, 29353.4], [1.792310915E12, 32287.2], [1.79231096E12, 27884.4], [1.79231087E12, 24949.2], [1.792310955E12, 29352.0], [1.792310835E12, 30819.6], [1.79231088E12, 29352.0], [1.792310965E12, 29352.0], [1.792310875E12, 33754.8], [1.79231092E12, 30819.6], [1.792310885E12, 22014.0], [1.79231084E12, 30819.6], [1.792310925E12, 30819.6], [1.79231089E12, 29352.0], [1.792310845E12, 29352.0], [1.79231093E12, 32287.2]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.792310895E12, 6577.2], [1.79231085E12, 6264.0], [1.792310935E12, 6890.4], [1.7923109E12, 7516.8], [1.79231094E12, 6577.2], [1.792310855E12, 5324.4], [1.79231082E12, 4384.8], [1.792310905E12, 6264.0], [1.79231086E12, 6890.4], [1.792310945E12, 5950.8], [1.792310825E12, 7203.6], [1.79231091E12, 6577.2], [1.792310865E12, 6890.4], [1.79231095E12, 6264.0], [1.79231083E12, 6264.0], [1.792310915E12, 6890.4], [1.79231096E12, 5950.8], [1.79231087E12, 5324.4], [1.792310955E12, 6264.0], [1.792310835E12, 6577.2], [1.79231088E12, 6264.0], [1.792310965E12, 6264.0], [1.792310875E12, 7203.6], [1.79231092E12, 6577.2], [1.792310885E12, 4698.0], [1.79231084E12, 6577.2], [1.792310925E12, 6577.2], [1.79231089E12, 6264.0], [1.792310845E12, 6264.0], [1.79231093E12, 6890.4]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.792310965E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 139.5, "minX": 1.79231082E12, "maxY": 465.6000000000001, "series": [{"data": [[1.792310895E12, 142.23809523809524], [1.79231085E12, 198.45], [1.792310935E12, 146.86363636363637], [1.7923109E12, 139.5], [1.79231094E12, 142.38095238095238], [1.792310855E12, 237.7058823529412], [1.79231082E12, 168.7142857142857], [1.792310905E12, 152.4], [1.79231086E12, 265.5], [1.792310945E12, 235.73684210526318], [1.792310825E12, 144.43478260869568], [1.79231091E12, 176.19047619047618], [1.792310865E12, 169.68181818181813], [1.79231095E12, 385.5], [1.79231083E12, 208.8], [1.792310915E12, 195.90909090909093], [1.79231096E12, 290.10526315789474], [1.79231087E12, 346.3529411764706], [1.792310955E12, 218.25], [1.792310835E12, 191.71428571428575], [1.79231088E12, 144.85000000000002], [1.792310965E12, 173.64999999999998], [1.792310875E12, 167.69565217391303], [1.79231092E12, 179.9047619047619], [1.792310885E12, 465.6000000000001], [1.79231084E12, 159.90476190476187], [1.792310925E12, 141.52380952380955], [1.79231089E12, 391.8], [1.792310845E12, 340.04999999999995], [1.79231093E12, 149.68181818181816]], "isOverall": false, "label": "GET - List Orders Direct Azure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.792310965E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 136.75, "minX": 1.79231082E12, "maxY": 434.0, "series": [{"data": [[1.792310895E12, 137.76190476190476], [1.79231085E12, 194.85], [1.792310935E12, 143.5909090909091], [1.7923109E12, 136.75], [1.79231094E12, 137.38095238095238], [1.792310855E12, 227.8823529411765], [1.79231082E12, 163.14285714285717], [1.792310905E12, 147.10000000000002], [1.79231086E12, 244.27272727272725], [1.792310945E12, 223.4736842105263], [1.792310825E12, 142.2608695652174], [1.79231091E12, 168.71428571428572], [1.792310865E12, 161.27272727272728], [1.79231095E12, 352.7], [1.79231083E12, 202.15], [1.792310915E12, 187.86363636363637], [1.79231096E12, 248.21052631578945], [1.79231087E12, 314.52941176470586], [1.792310955E12, 209.14999999999995], [1.792310835E12, 188.6190476190476], [1.79231088E12, 141.0], [1.792310965E12, 151.79999999999998], [1.792310875E12, 158.52173913043472], [1.79231092E12, 155.76190476190476], [1.792310885E12, 434.0], [1.79231084E12, 155.47619047619042], [1.792310925E12, 138.23809523809524], [1.79231089E12, 354.79999999999995], [1.792310845E12, 312.59999999999997], [1.79231093E12, 144.54545454545453]], "isOverall": false, "label": "GET - List Orders Direct Azure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.792310965E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 0.0, "minX": 1.79231082E12, "maxY": 82.0, "series": [{"data": [[1.792310895E12, 0.0], [1.79231085E12, 30.700000000000003], [1.792310935E12, 0.0], [1.7923109E12, 0.0], [1.79231094E12, 0.0], [1.792310855E12, 54.23529411764706], [1.79231082E12, 0.0], [1.792310905E12, 0.0], [1.79231086E12, 82.0], [1.792310945E12, 0.0], [1.792310825E12, 0.0], [1.79231091E12, 30.333333333333336], [1.792310865E12, 0.0], [1.79231095E12, 0.0], [1.79231083E12, 0.0], [1.792310915E12, 32.27272727272727], [1.79231096E12, 0.0], [1.79231087E12, 0.0], [1.792310955E12, 0.0], [1.792310835E12, 0.0], [1.79231088E12, 0.0], [1.792310965E12, 0.0], [1.792310875E12, 0.0], [1.79231092E12, 0.0], [1.792310885E12, 0.0], [1.79231084E12, 0.0], [1.792310925E12, 0.0], [1.79231089E12, 0.0], [1.792310845E12, 0.0], [1.79231093E12, 0.0]], "isOverall": false, "label": "GET - List Orders Direct Azure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.792310965E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 114.0, "minX": 1.79231082E12, "maxY": 2101.0, "series": [{"data": [[1.792310895E12, 174.0], [1.79231085E12, 564.0], [1.792310935E12, 196.0], [1.7923109E12, 160.0], [1.79231094E12, 171.0], [1.792310855E12, 829.0], [1.79231082E12, 231.0], [1.792310905E12, 193.0], [1.79231086E12, 2101.0], [1.792310945E12, 686.0], [1.792310825E12, 172.0], [1.79231091E12, 578.0], [1.792310865E12, 617.0], [1.79231095E12, 1677.0], [1.79231083E12, 334.0], [1.792310915E12, 611.0], [1.79231096E12, 707.0], [1.79231087E12, 1526.0], [1.792310955E12, 574.0], [1.792310835E12, 274.0], [1.79231088E12, 167.0], [1.792310965E12, 463.0], [1.792310875E12, 624.0], [1.79231092E12, 542.0], [1.792310885E12, 1561.0], [1.79231084E12, 206.0], [1.792310925E12, 165.0], [1.79231089E12, 1161.0], [1.792310845E12, 773.0], [1.79231093E12, 187.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.792310895E12, 114.0], [1.79231085E12, 130.0], [1.792310935E12, 122.0], [1.7923109E12, 122.0], [1.79231094E12, 122.0], [1.792310855E12, 129.0], [1.79231082E12, 126.0], [1.792310905E12, 121.0], [1.79231086E12, 121.0], [1.792310945E12, 115.0], [1.792310825E12, 127.0], [1.79231091E12, 123.0], [1.792310865E12, 123.0], [1.79231095E12, 128.0], [1.79231083E12, 154.0], [1.792310915E12, 123.0], [1.79231096E12, 118.0], [1.79231087E12, 120.0], [1.792310955E12, 132.0], [1.792310835E12, 154.0], [1.79231088E12, 124.0], [1.792310965E12, 126.0], [1.792310875E12, 120.0], [1.79231092E12, 124.0], [1.792310885E12, 123.0], [1.79231084E12, 135.0], [1.792310925E12, 126.0], [1.79231089E12, 132.0], [1.792310845E12, 136.0], [1.79231093E12, 119.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.792310895E12, 170.20000000000002], [1.79231085E12, 373.9000000000004], [1.792310935E12, 174.9], [1.7923109E12, 157.5], [1.79231094E12, 167.4], [1.792310855E12, 634.5999999999998], [1.79231082E12, 229.5], [1.792310905E12, 185.20000000000002], [1.79231086E12, 427.0999999999999], [1.792310945E12, 576.0], [1.792310825E12, 169.4], [1.79231091E12, 364.60000000000014], [1.792310865E12, 273.0999999999999], [1.79231095E12, 914.0000000000005], [1.79231083E12, 267.6], [1.792310915E12, 381.0], [1.79231096E12, 595.0], [1.79231087E12, 1187.5999999999997], [1.792310955E12, 475.60000000000025], [1.792310835E12, 254.0], [1.79231088E12, 165.10000000000002], [1.792310965E12, 206.8], [1.792310875E12, 210.80000000000013], [1.79231092E12, 419.0000000000002], [1.792310885E12, 1561.0], [1.79231084E12, 197.60000000000002], [1.792310925E12, 157.0], [1.79231089E12, 865.9], [1.792310845E12, 618.3000000000001], [1.79231093E12, 173.9]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.792310895E12, 174.0], [1.79231085E12, 564.0], [1.792310935E12, 196.0], [1.7923109E12, 160.0], [1.79231094E12, 171.0], [1.792310855E12, 829.0], [1.79231082E12, 231.0], [1.792310905E12, 193.0], [1.79231086E12, 2101.0], [1.792310945E12, 686.0], [1.792310825E12, 172.0], [1.79231091E12, 578.0], [1.792310865E12, 617.0], [1.79231095E12, 1677.0], [1.79231083E12, 334.0], [1.792310915E12, 611.0], [1.79231096E12, 707.0], [1.79231087E12, 1526.0], [1.792310955E12, 574.0], [1.792310835E12, 274.0], [1.79231088E12, 167.0], [1.792310965E12, 463.0], [1.792310875E12, 624.0], [1.79231092E12, 542.0], [1.792310885E12, 1561.0], [1.79231084E12, 206.0], [1.792310925E12, 165.0], [1.79231089E12, 1161.0], [1.792310845E12, 773.0], [1.79231093E12, 187.0]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.792310895E12, 141.0], [1.79231085E12, 161.0], [1.792310935E12, 145.0], [1.7923109E12, 136.0], [1.79231094E12, 138.0], [1.792310855E12, 149.0], [1.79231082E12, 165.5], [1.792310905E12, 150.0], [1.79231086E12, 146.5], [1.792310945E12, 149.0], [1.792310825E12, 143.0], [1.79231091E12, 142.0], [1.792310865E12, 141.0], [1.79231095E12, 222.0], [1.79231083E12, 191.0], [1.792310915E12, 145.0], [1.79231096E12, 156.0], [1.79231087E12, 149.0], [1.792310955E12, 156.5], [1.792310835E12, 180.0], [1.79231088E12, 145.0], [1.792310965E12, 156.0], [1.792310875E12, 146.0], [1.79231092E12, 145.0], [1.792310885E12, 160.0], [1.79231084E12, 159.0], [1.792310925E12, 142.0], [1.79231089E12, 241.5], [1.792310845E12, 306.0], [1.79231093E12, 148.5]], "isOverall": false, "label": "Median", "isController": false}, {"data": [[1.792310895E12, 174.0], [1.79231085E12, 555.3499999999999], [1.792310935E12, 193.14999999999995], [1.7923109E12, 159.75], [1.79231094E12, 170.7], [1.792310855E12, 829.0], [1.79231082E12, 231.0], [1.792310905E12, 192.65], [1.79231086E12, 1857.2499999999966], [1.792310945E12, 686.0], [1.792310825E12, 171.8], [1.79231091E12, 561.5999999999998], [1.792310865E12, 572.7499999999993], [1.79231095E12, 1639.7999999999995], [1.79231083E12, 330.69999999999993], [1.792310915E12, 576.4999999999995], [1.79231096E12, 707.0], [1.79231087E12, 1526.0], [1.792310955E12, 569.75], [1.792310835E12, 272.4], [1.79231088E12, 166.95], [1.792310965E12, 450.24999999999983], [1.792310875E12, 547.5999999999989], [1.79231092E12, 535.8999999999999], [1.792310885E12, 1561.0], [1.79231084E12, 205.8], [1.792310925E12, 164.29999999999998], [1.79231089E12, 1146.2499999999998], [1.792310845E12, 765.3], [1.79231093E12, 185.34999999999997]], "isOverall": false, "label": "95th percentile", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.792310965E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 142.5, "minX": 1.0, "maxY": 348.5, "series": [{"data": [[2.0, 142.5], [4.0, 148.0], [1.0, 348.5], [5.0, 151.0], [3.0, 155.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 5.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 140.0, "minX": 1.0, "maxY": 348.5, "series": [{"data": [[2.0, 140.0], [4.0, 142.5], [1.0, 348.5], [5.0, 145.0], [3.0, 151.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 5.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 2.8, "minX": 1.79231082E12, "maxY": 4.6, "series": [{"data": [[1.792310895E12, 4.6], [1.79231085E12, 4.0], [1.792310935E12, 4.4], [1.7923109E12, 4.2], [1.79231094E12, 4.0], [1.792310855E12, 4.0], [1.79231082E12, 2.8], [1.792310905E12, 4.2], [1.79231086E12, 3.8], [1.792310945E12, 4.4], [1.792310825E12, 4.6], [1.79231091E12, 4.4], [1.792310865E12, 4.4], [1.79231095E12, 3.4], [1.79231083E12, 4.0], [1.792310915E12, 4.2], [1.79231096E12, 4.0], [1.79231087E12, 3.4], [1.792310955E12, 4.0], [1.792310835E12, 4.4], [1.79231088E12, 4.2], [1.792310965E12, 3.8], [1.792310875E12, 4.6], [1.79231092E12, 4.0], [1.792310885E12, 3.4], [1.79231084E12, 4.0], [1.792310925E12, 4.2], [1.79231089E12, 3.6], [1.792310845E12, 4.0], [1.79231093E12, 4.6]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.792310965E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 2.8, "minX": 1.79231082E12, "maxY": 4.8, "series": [{"data": [[1.792310895E12, 4.2], [1.79231085E12, 4.0], [1.792310935E12, 4.4], [1.7923109E12, 4.8], [1.79231094E12, 4.2], [1.792310855E12, 3.4], [1.79231082E12, 2.8], [1.792310905E12, 4.0], [1.79231086E12, 4.4], [1.792310945E12, 3.8], [1.792310825E12, 4.6], [1.79231091E12, 4.2], [1.792310865E12, 4.4], [1.79231095E12, 4.0], [1.79231083E12, 4.0], [1.792310915E12, 4.4], [1.79231096E12, 3.8], [1.79231087E12, 3.4], [1.792310955E12, 4.0], [1.792310835E12, 4.2], [1.79231088E12, 4.0], [1.792310965E12, 4.0], [1.792310875E12, 4.6], [1.79231092E12, 4.2], [1.792310885E12, 3.0], [1.79231084E12, 4.2], [1.792310925E12, 4.2], [1.79231089E12, 4.0], [1.792310845E12, 4.0], [1.79231093E12, 4.4]], "isOverall": false, "label": "200", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.792310965E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 2.8, "minX": 1.79231082E12, "maxY": 4.8, "series": [{"data": [[1.792310895E12, 4.2], [1.79231085E12, 4.0], [1.792310935E12, 4.4], [1.7923109E12, 4.8], [1.79231094E12, 4.2], [1.792310855E12, 3.4], [1.79231082E12, 2.8], [1.792310905E12, 4.0], [1.79231086E12, 4.4], [1.792310945E12, 3.8], [1.792310825E12, 4.6], [1.79231091E12, 4.2], [1.792310865E12, 4.4], [1.79231095E12, 4.0], [1.79231083E12, 4.0], [1.792310915E12, 4.4], [1.79231096E12, 3.8], [1.79231087E12, 3.4], [1.792310955E12, 4.0], [1.792310835E12, 4.2], [1.79231088E12, 4.0], [1.792310965E12, 4.0], [1.792310875E12, 4.6], [1.79231092E12, 4.2], [1.792310885E12, 3.0], [1.79231084E12, 4.2], [1.792310925E12, 4.2], [1.79231089E12, 4.0], [1.792310845E12, 4.0], [1.79231093E12, 4.4]], "isOverall": false, "label": "GET - List Orders Direct Azure-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.792310965E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 2.8, "minX": 1.79231082E12, "maxY": 4.8, "series": [{"data": [[1.792310895E12, 4.2], [1.79231085E12, 4.0], [1.792310935E12, 4.4], [1.7923109E12, 4.8], [1.79231094E12, 4.2], [1.792310855E12, 3.4], [1.79231082E12, 2.8], [1.792310905E12, 4.0], [1.79231086E12, 4.4], [1.792310945E12, 3.8], [1.792310825E12, 4.6], [1.79231091E12, 4.2], [1.792310865E12, 4.4], [1.79231095E12, 4.0], [1.79231083E12, 4.0], [1.792310915E12, 4.4], [1.79231096E12, 3.8], [1.79231087E12, 3.4], [1.792310955E12, 4.0], [1.792310835E12, 4.2], [1.79231088E12, 4.0], [1.792310965E12, 4.0], [1.792310875E12, 4.6], [1.79231092E12, 4.2], [1.792310885E12, 3.0], [1.79231084E12, 4.2], [1.792310925E12, 4.2], [1.79231089E12, 4.0], [1.792310845E12, 4.0], [1.79231093E12, 4.4]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.792310965E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

