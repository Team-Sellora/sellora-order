/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 114.0, "minX": 0.0, "maxY": 2194.0, "series": [{"data": [[0.0, 114.0], [0.1, 115.0], [0.2, 115.0], [0.3, 115.0], [0.4, 117.0], [0.5, 118.0], [0.6, 118.0], [0.7, 118.0], [0.8, 118.0], [0.9, 118.0], [1.0, 119.0], [1.1, 119.0], [1.2, 119.0], [1.3, 119.0], [1.4, 119.0], [1.5, 119.0], [1.6, 119.0], [1.7, 120.0], [1.8, 120.0], [1.9, 120.0], [2.0, 120.0], [2.1, 120.0], [2.2, 120.0], [2.3, 120.0], [2.4, 121.0], [2.5, 121.0], [2.6, 121.0], [2.7, 121.0], [2.8, 122.0], [2.9, 122.0], [3.0, 122.0], [3.1, 122.0], [3.2, 122.0], [3.3, 122.0], [3.4, 123.0], [3.5, 123.0], [3.6, 123.0], [3.7, 123.0], [3.8, 123.0], [3.9, 124.0], [4.0, 124.0], [4.1, 124.0], [4.2, 124.0], [4.3, 124.0], [4.4, 124.0], [4.5, 124.0], [4.6, 124.0], [4.7, 125.0], [4.8, 125.0], [4.9, 125.0], [5.0, 125.0], [5.1, 125.0], [5.2, 125.0], [5.3, 125.0], [5.4, 125.0], [5.5, 125.0], [5.6, 126.0], [5.7, 126.0], [5.8, 126.0], [5.9, 126.0], [6.0, 126.0], [6.1, 126.0], [6.2, 126.0], [6.3, 126.0], [6.4, 126.0], [6.5, 126.0], [6.6, 126.0], [6.7, 126.0], [6.8, 126.0], [6.9, 126.0], [7.0, 127.0], [7.1, 127.0], [7.2, 127.0], [7.3, 127.0], [7.4, 127.0], [7.5, 127.0], [7.6, 127.0], [7.7, 127.0], [7.8, 127.0], [7.9, 127.0], [8.0, 127.0], [8.1, 128.0], [8.2, 128.0], [8.3, 128.0], [8.4, 128.0], [8.5, 128.0], [8.6, 128.0], [8.7, 128.0], [8.8, 129.0], [8.9, 129.0], [9.0, 129.0], [9.1, 129.0], [9.2, 129.0], [9.3, 129.0], [9.4, 129.0], [9.5, 129.0], [9.6, 129.0], [9.7, 129.0], [9.8, 129.0], [9.9, 129.0], [10.0, 129.0], [10.1, 130.0], [10.2, 130.0], [10.3, 130.0], [10.4, 130.0], [10.5, 130.0], [10.6, 130.0], [10.7, 130.0], [10.8, 130.0], [10.9, 130.0], [11.0, 130.0], [11.1, 130.0], [11.2, 130.0], [11.3, 130.0], [11.4, 130.0], [11.5, 130.0], [11.6, 130.0], [11.7, 130.0], [11.8, 130.0], [11.9, 130.0], [12.0, 130.0], [12.1, 130.0], [12.2, 131.0], [12.3, 131.0], [12.4, 131.0], [12.5, 131.0], [12.6, 131.0], [12.7, 131.0], [12.8, 131.0], [12.9, 131.0], [13.0, 131.0], [13.1, 131.0], [13.2, 131.0], [13.3, 131.0], [13.4, 131.0], [13.5, 131.0], [13.6, 131.0], [13.7, 131.0], [13.8, 131.0], [13.9, 131.0], [14.0, 131.0], [14.1, 131.0], [14.2, 131.0], [14.3, 131.0], [14.4, 132.0], [14.5, 132.0], [14.6, 132.0], [14.7, 132.0], [14.8, 132.0], [14.9, 132.0], [15.0, 132.0], [15.1, 132.0], [15.2, 132.0], [15.3, 132.0], [15.4, 132.0], [15.5, 132.0], [15.6, 132.0], [15.7, 132.0], [15.8, 132.0], [15.9, 133.0], [16.0, 133.0], [16.1, 133.0], [16.2, 133.0], [16.3, 133.0], [16.4, 133.0], [16.5, 133.0], [16.6, 133.0], [16.7, 133.0], [16.8, 133.0], [16.9, 133.0], [17.0, 133.0], [17.1, 133.0], [17.2, 133.0], [17.3, 133.0], [17.4, 133.0], [17.5, 133.0], [17.6, 133.0], [17.7, 133.0], [17.8, 133.0], [17.9, 133.0], [18.0, 134.0], [18.1, 134.0], [18.2, 134.0], [18.3, 134.0], [18.4, 134.0], [18.5, 134.0], [18.6, 134.0], [18.7, 134.0], [18.8, 134.0], [18.9, 134.0], [19.0, 134.0], [19.1, 134.0], [19.2, 134.0], [19.3, 134.0], [19.4, 134.0], [19.5, 134.0], [19.6, 135.0], [19.7, 135.0], [19.8, 135.0], [19.9, 135.0], [20.0, 135.0], [20.1, 135.0], [20.2, 135.0], [20.3, 135.0], [20.4, 135.0], [20.5, 135.0], [20.6, 135.0], [20.7, 135.0], [20.8, 135.0], [20.9, 135.0], [21.0, 135.0], [21.1, 135.0], [21.2, 135.0], [21.3, 135.0], [21.4, 135.0], [21.5, 135.0], [21.6, 136.0], [21.7, 136.0], [21.8, 136.0], [21.9, 136.0], [22.0, 136.0], [22.1, 136.0], [22.2, 136.0], [22.3, 136.0], [22.4, 136.0], [22.5, 136.0], [22.6, 136.0], [22.7, 136.0], [22.8, 136.0], [22.9, 136.0], [23.0, 136.0], [23.1, 136.0], [23.2, 136.0], [23.3, 137.0], [23.4, 137.0], [23.5, 137.0], [23.6, 137.0], [23.7, 137.0], [23.8, 137.0], [23.9, 137.0], [24.0, 137.0], [24.1, 137.0], [24.2, 137.0], [24.3, 137.0], [24.4, 137.0], [24.5, 137.0], [24.6, 137.0], [24.7, 137.0], [24.8, 138.0], [24.9, 138.0], [25.0, 138.0], [25.1, 138.0], [25.2, 138.0], [25.3, 138.0], [25.4, 138.0], [25.5, 138.0], [25.6, 138.0], [25.7, 138.0], [25.8, 138.0], [25.9, 138.0], [26.0, 138.0], [26.1, 138.0], [26.2, 138.0], [26.3, 139.0], [26.4, 139.0], [26.5, 139.0], [26.6, 139.0], [26.7, 139.0], [26.8, 139.0], [26.9, 139.0], [27.0, 139.0], [27.1, 139.0], [27.2, 139.0], [27.3, 139.0], [27.4, 139.0], [27.5, 139.0], [27.6, 139.0], [27.7, 139.0], [27.8, 139.0], [27.9, 139.0], [28.0, 139.0], [28.1, 139.0], [28.2, 140.0], [28.3, 140.0], [28.4, 140.0], [28.5, 140.0], [28.6, 140.0], [28.7, 140.0], [28.8, 140.0], [28.9, 140.0], [29.0, 140.0], [29.1, 140.0], [29.2, 140.0], [29.3, 140.0], [29.4, 140.0], [29.5, 140.0], [29.6, 140.0], [29.7, 140.0], [29.8, 140.0], [29.9, 140.0], [30.0, 140.0], [30.1, 140.0], [30.2, 140.0], [30.3, 140.0], [30.4, 140.0], [30.5, 140.0], [30.6, 140.0], [30.7, 141.0], [30.8, 141.0], [30.9, 141.0], [31.0, 141.0], [31.1, 141.0], [31.2, 141.0], [31.3, 141.0], [31.4, 141.0], [31.5, 141.0], [31.6, 141.0], [31.7, 141.0], [31.8, 141.0], [31.9, 141.0], [32.0, 141.0], [32.1, 141.0], [32.2, 141.0], [32.3, 141.0], [32.4, 142.0], [32.5, 142.0], [32.6, 142.0], [32.7, 142.0], [32.8, 142.0], [32.9, 142.0], [33.0, 142.0], [33.1, 142.0], [33.2, 142.0], [33.3, 142.0], [33.4, 142.0], [33.5, 142.0], [33.6, 142.0], [33.7, 142.0], [33.8, 142.0], [33.9, 142.0], [34.0, 142.0], [34.1, 142.0], [34.2, 142.0], [34.3, 142.0], [34.4, 142.0], [34.5, 142.0], [34.6, 142.0], [34.7, 142.0], [34.8, 142.0], [34.9, 143.0], [35.0, 143.0], [35.1, 143.0], [35.2, 143.0], [35.3, 143.0], [35.4, 143.0], [35.5, 143.0], [35.6, 143.0], [35.7, 143.0], [35.8, 143.0], [35.9, 143.0], [36.0, 143.0], [36.1, 143.0], [36.2, 143.0], [36.3, 143.0], [36.4, 143.0], [36.5, 143.0], [36.6, 143.0], [36.7, 143.0], [36.8, 143.0], [36.9, 144.0], [37.0, 144.0], [37.1, 144.0], [37.2, 144.0], [37.3, 144.0], [37.4, 144.0], [37.5, 144.0], [37.6, 144.0], [37.7, 144.0], [37.8, 144.0], [37.9, 144.0], [38.0, 144.0], [38.1, 144.0], [38.2, 144.0], [38.3, 144.0], [38.4, 144.0], [38.5, 144.0], [38.6, 144.0], [38.7, 144.0], [38.8, 145.0], [38.9, 145.0], [39.0, 145.0], [39.1, 145.0], [39.2, 145.0], [39.3, 145.0], [39.4, 145.0], [39.5, 145.0], [39.6, 145.0], [39.7, 145.0], [39.8, 145.0], [39.9, 145.0], [40.0, 145.0], [40.1, 146.0], [40.2, 146.0], [40.3, 146.0], [40.4, 146.0], [40.5, 146.0], [40.6, 146.0], [40.7, 146.0], [40.8, 146.0], [40.9, 146.0], [41.0, 146.0], [41.1, 146.0], [41.2, 146.0], [41.3, 146.0], [41.4, 146.0], [41.5, 146.0], [41.6, 146.0], [41.7, 146.0], [41.8, 146.0], [41.9, 146.0], [42.0, 146.0], [42.1, 147.0], [42.2, 147.0], [42.3, 147.0], [42.4, 147.0], [42.5, 147.0], [42.6, 147.0], [42.7, 147.0], [42.8, 147.0], [42.9, 147.0], [43.0, 147.0], [43.1, 147.0], [43.2, 147.0], [43.3, 147.0], [43.4, 147.0], [43.5, 147.0], [43.6, 148.0], [43.7, 148.0], [43.8, 148.0], [43.9, 148.0], [44.0, 148.0], [44.1, 148.0], [44.2, 148.0], [44.3, 149.0], [44.4, 149.0], [44.5, 149.0], [44.6, 149.0], [44.7, 149.0], [44.8, 149.0], [44.9, 149.0], [45.0, 149.0], [45.1, 149.0], [45.2, 149.0], [45.3, 149.0], [45.4, 149.0], [45.5, 149.0], [45.6, 149.0], [45.7, 150.0], [45.8, 150.0], [45.9, 150.0], [46.0, 150.0], [46.1, 150.0], [46.2, 150.0], [46.3, 150.0], [46.4, 150.0], [46.5, 150.0], [46.6, 150.0], [46.7, 150.0], [46.8, 150.0], [46.9, 150.0], [47.0, 150.0], [47.1, 151.0], [47.2, 151.0], [47.3, 151.0], [47.4, 151.0], [47.5, 151.0], [47.6, 151.0], [47.7, 151.0], [47.8, 151.0], [47.9, 151.0], [48.0, 151.0], [48.1, 151.0], [48.2, 151.0], [48.3, 151.0], [48.4, 151.0], [48.5, 151.0], [48.6, 151.0], [48.7, 151.0], [48.8, 151.0], [48.9, 152.0], [49.0, 152.0], [49.1, 152.0], [49.2, 152.0], [49.3, 152.0], [49.4, 152.0], [49.5, 152.0], [49.6, 153.0], [49.7, 153.0], [49.8, 153.0], [49.9, 153.0], [50.0, 153.0], [50.1, 153.0], [50.2, 153.0], [50.3, 153.0], [50.4, 153.0], [50.5, 153.0], [50.6, 153.0], [50.7, 153.0], [50.8, 153.0], [50.9, 153.0], [51.0, 153.0], [51.1, 153.0], [51.2, 153.0], [51.3, 153.0], [51.4, 154.0], [51.5, 154.0], [51.6, 154.0], [51.7, 154.0], [51.8, 154.0], [51.9, 154.0], [52.0, 154.0], [52.1, 154.0], [52.2, 154.0], [52.3, 154.0], [52.4, 154.0], [52.5, 154.0], [52.6, 155.0], [52.7, 155.0], [52.8, 155.0], [52.9, 155.0], [53.0, 155.0], [53.1, 155.0], [53.2, 155.0], [53.3, 155.0], [53.4, 155.0], [53.5, 155.0], [53.6, 155.0], [53.7, 155.0], [53.8, 155.0], [53.9, 155.0], [54.0, 156.0], [54.1, 156.0], [54.2, 156.0], [54.3, 156.0], [54.4, 156.0], [54.5, 156.0], [54.6, 156.0], [54.7, 156.0], [54.8, 156.0], [54.9, 156.0], [55.0, 156.0], [55.1, 156.0], [55.2, 157.0], [55.3, 157.0], [55.4, 157.0], [55.5, 157.0], [55.6, 157.0], [55.7, 157.0], [55.8, 157.0], [55.9, 157.0], [56.0, 157.0], [56.1, 157.0], [56.2, 157.0], [56.3, 157.0], [56.4, 157.0], [56.5, 157.0], [56.6, 157.0], [56.7, 158.0], [56.8, 158.0], [56.9, 158.0], [57.0, 158.0], [57.1, 158.0], [57.2, 158.0], [57.3, 158.0], [57.4, 158.0], [57.5, 158.0], [57.6, 158.0], [57.7, 159.0], [57.8, 159.0], [57.9, 159.0], [58.0, 159.0], [58.1, 159.0], [58.2, 159.0], [58.3, 159.0], [58.4, 159.0], [58.5, 159.0], [58.6, 159.0], [58.7, 160.0], [58.8, 160.0], [58.9, 160.0], [59.0, 160.0], [59.1, 160.0], [59.2, 160.0], [59.3, 160.0], [59.4, 160.0], [59.5, 160.0], [59.6, 161.0], [59.7, 161.0], [59.8, 161.0], [59.9, 161.0], [60.0, 161.0], [60.1, 161.0], [60.2, 161.0], [60.3, 161.0], [60.4, 162.0], [60.5, 162.0], [60.6, 162.0], [60.7, 162.0], [60.8, 162.0], [60.9, 162.0], [61.0, 162.0], [61.1, 162.0], [61.2, 162.0], [61.3, 162.0], [61.4, 162.0], [61.5, 162.0], [61.6, 162.0], [61.7, 162.0], [61.8, 163.0], [61.9, 163.0], [62.0, 163.0], [62.1, 163.0], [62.2, 163.0], [62.3, 163.0], [62.4, 163.0], [62.5, 164.0], [62.6, 164.0], [62.7, 164.0], [62.8, 164.0], [62.9, 164.0], [63.0, 164.0], [63.1, 165.0], [63.2, 165.0], [63.3, 165.0], [63.4, 165.0], [63.5, 165.0], [63.6, 165.0], [63.7, 165.0], [63.8, 165.0], [63.9, 165.0], [64.0, 165.0], [64.1, 166.0], [64.2, 166.0], [64.3, 166.0], [64.4, 167.0], [64.5, 167.0], [64.6, 167.0], [64.7, 167.0], [64.8, 167.0], [64.9, 167.0], [65.0, 167.0], [65.1, 168.0], [65.2, 168.0], [65.3, 168.0], [65.4, 168.0], [65.5, 168.0], [65.6, 169.0], [65.7, 169.0], [65.8, 169.0], [65.9, 169.0], [66.0, 169.0], [66.1, 169.0], [66.2, 169.0], [66.3, 169.0], [66.4, 169.0], [66.5, 169.0], [66.6, 169.0], [66.7, 169.0], [66.8, 170.0], [66.9, 170.0], [67.0, 170.0], [67.1, 170.0], [67.2, 170.0], [67.3, 171.0], [67.4, 171.0], [67.5, 171.0], [67.6, 171.0], [67.7, 171.0], [67.8, 171.0], [67.9, 171.0], [68.0, 171.0], [68.1, 171.0], [68.2, 171.0], [68.3, 172.0], [68.4, 172.0], [68.5, 172.0], [68.6, 172.0], [68.7, 172.0], [68.8, 172.0], [68.9, 173.0], [69.0, 173.0], [69.1, 173.0], [69.2, 173.0], [69.3, 173.0], [69.4, 173.0], [69.5, 173.0], [69.6, 173.0], [69.7, 173.0], [69.8, 174.0], [69.9, 174.0], [70.0, 174.0], [70.1, 174.0], [70.2, 174.0], [70.3, 174.0], [70.4, 175.0], [70.5, 175.0], [70.6, 175.0], [70.7, 175.0], [70.8, 175.0], [70.9, 175.0], [71.0, 176.0], [71.1, 176.0], [71.2, 176.0], [71.3, 176.0], [71.4, 177.0], [71.5, 177.0], [71.6, 177.0], [71.7, 177.0], [71.8, 177.0], [71.9, 177.0], [72.0, 177.0], [72.1, 177.0], [72.2, 177.0], [72.3, 178.0], [72.4, 178.0], [72.5, 178.0], [72.6, 178.0], [72.7, 178.0], [72.8, 178.0], [72.9, 179.0], [73.0, 179.0], [73.1, 180.0], [73.2, 180.0], [73.3, 180.0], [73.4, 180.0], [73.5, 180.0], [73.6, 181.0], [73.7, 181.0], [73.8, 181.0], [73.9, 181.0], [74.0, 182.0], [74.1, 182.0], [74.2, 182.0], [74.3, 182.0], [74.4, 183.0], [74.5, 183.0], [74.6, 183.0], [74.7, 183.0], [74.8, 183.0], [74.9, 184.0], [75.0, 184.0], [75.1, 184.0], [75.2, 186.0], [75.3, 186.0], [75.4, 186.0], [75.5, 186.0], [75.6, 186.0], [75.7, 187.0], [75.8, 187.0], [75.9, 187.0], [76.0, 187.0], [76.1, 188.0], [76.2, 188.0], [76.3, 188.0], [76.4, 188.0], [76.5, 188.0], [76.6, 188.0], [76.7, 189.0], [76.8, 189.0], [76.9, 189.0], [77.0, 189.0], [77.1, 190.0], [77.2, 190.0], [77.3, 190.0], [77.4, 190.0], [77.5, 191.0], [77.6, 192.0], [77.7, 192.0], [77.8, 192.0], [77.9, 192.0], [78.0, 193.0], [78.1, 193.0], [78.2, 193.0], [78.3, 193.0], [78.4, 193.0], [78.5, 193.0], [78.6, 194.0], [78.7, 194.0], [78.8, 194.0], [78.9, 195.0], [79.0, 195.0], [79.1, 195.0], [79.2, 195.0], [79.3, 195.0], [79.4, 196.0], [79.5, 196.0], [79.6, 196.0], [79.7, 196.0], [79.8, 197.0], [79.9, 197.0], [80.0, 197.0], [80.1, 197.0], [80.2, 200.0], [80.3, 200.0], [80.4, 201.0], [80.5, 201.0], [80.6, 202.0], [80.7, 202.0], [80.8, 203.0], [80.9, 203.0], [81.0, 203.0], [81.1, 204.0], [81.2, 206.0], [81.3, 207.0], [81.4, 207.0], [81.5, 207.0], [81.6, 207.0], [81.7, 208.0], [81.8, 209.0], [81.9, 211.0], [82.0, 213.0], [82.1, 214.0], [82.2, 214.0], [82.3, 215.0], [82.4, 215.0], [82.5, 216.0], [82.6, 217.0], [82.7, 217.0], [82.8, 217.0], [82.9, 217.0], [83.0, 217.0], [83.1, 217.0], [83.2, 217.0], [83.3, 217.0], [83.4, 219.0], [83.5, 219.0], [83.6, 219.0], [83.7, 220.0], [83.8, 222.0], [83.9, 222.0], [84.0, 223.0], [84.1, 223.0], [84.2, 223.0], [84.3, 224.0], [84.4, 227.0], [84.5, 227.0], [84.6, 227.0], [84.7, 228.0], [84.8, 229.0], [84.9, 229.0], [85.0, 230.0], [85.1, 231.0], [85.2, 231.0], [85.3, 232.0], [85.4, 232.0], [85.5, 236.0], [85.6, 236.0], [85.7, 237.0], [85.8, 238.0], [85.9, 238.0], [86.0, 239.0], [86.1, 241.0], [86.2, 247.0], [86.3, 250.0], [86.4, 251.0], [86.5, 251.0], [86.6, 251.0], [86.7, 253.0], [86.8, 258.0], [86.9, 259.0], [87.0, 264.0], [87.1, 264.0], [87.2, 265.0], [87.3, 265.0], [87.4, 266.0], [87.5, 269.0], [87.6, 270.0], [87.7, 270.0], [87.8, 270.0], [87.9, 272.0], [88.0, 273.0], [88.1, 276.0], [88.2, 276.0], [88.3, 280.0], [88.4, 282.0], [88.5, 289.0], [88.6, 289.0], [88.7, 290.0], [88.8, 294.0], [88.9, 295.0], [89.0, 304.0], [89.1, 304.0], [89.2, 304.0], [89.3, 304.0], [89.4, 304.0], [89.5, 306.0], [89.6, 313.0], [89.7, 314.0], [89.8, 316.0], [89.9, 318.0], [90.0, 319.0], [90.1, 320.0], [90.2, 326.0], [90.3, 327.0], [90.4, 329.0], [90.5, 329.0], [90.6, 329.0], [90.7, 334.0], [90.8, 337.0], [90.9, 337.0], [91.0, 345.0], [91.1, 345.0], [91.2, 348.0], [91.3, 355.0], [91.4, 357.0], [91.5, 359.0], [91.6, 362.0], [91.7, 363.0], [91.8, 368.0], [91.9, 369.0], [92.0, 373.0], [92.1, 375.0], [92.2, 384.0], [92.3, 384.0], [92.4, 388.0], [92.5, 389.0], [92.6, 393.0], [92.7, 397.0], [92.8, 397.0], [92.9, 397.0], [93.0, 397.0], [93.1, 415.0], [93.2, 415.0], [93.3, 422.0], [93.4, 428.0], [93.5, 428.0], [93.6, 439.0], [93.7, 444.0], [93.8, 447.0], [93.9, 450.0], [94.0, 462.0], [94.1, 468.0], [94.2, 470.0], [94.3, 484.0], [94.4, 485.0], [94.5, 488.0], [94.6, 494.0], [94.7, 494.0], [94.8, 497.0], [94.9, 514.0], [95.0, 522.0], [95.1, 525.0], [95.2, 533.0], [95.3, 551.0], [95.4, 569.0], [95.5, 573.0], [95.6, 585.0], [95.7, 596.0], [95.8, 602.0], [95.9, 607.0], [96.0, 613.0], [96.1, 626.0], [96.2, 633.0], [96.3, 635.0], [96.4, 644.0], [96.5, 647.0], [96.6, 647.0], [96.7, 663.0], [96.8, 695.0], [96.9, 695.0], [97.0, 697.0], [97.1, 730.0], [97.2, 747.0], [97.3, 765.0], [97.4, 769.0], [97.5, 772.0], [97.6, 785.0], [97.7, 822.0], [97.8, 839.0], [97.9, 857.0], [98.0, 887.0], [98.1, 892.0], [98.2, 900.0], [98.3, 904.0], [98.4, 939.0], [98.5, 942.0], [98.6, 944.0], [98.7, 996.0], [98.8, 998.0], [98.9, 1035.0], [99.0, 1049.0], [99.1, 1060.0], [99.2, 1060.0], [99.3, 1156.0], [99.4, 1241.0], [99.5, 1247.0], [99.6, 1360.0], [99.7, 1522.0], [99.8, 1625.0], [99.9, 1656.0]], "isOverall": false, "label": "GET - List Orders Direct Azure", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 100.0, "maxY": 976.0, "series": [{"data": [[2100.0, 1.0], [600.0, 16.0], [700.0, 8.0], [200.0, 106.0], [800.0, 6.0], [900.0, 8.0], [1000.0, 5.0], [1100.0, 1.0], [300.0, 50.0], [1200.0, 2.0], [1300.0, 2.0], [1500.0, 1.0], [100.0, 976.0], [400.0, 22.0], [1600.0, 2.0], [500.0, 11.0]], "isOverall": false, "label": "GET - List Orders Direct Azure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 2100.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 4.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 1154.0, "series": [{"data": [[0.0, 1154.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 59.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [[2.0, 4.0]], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 2.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 8.500000000000002, "minX": 1.792311055E12, "maxY": 10.0, "series": [{"data": [[1.79231115E12, 10.0], [1.792311065E12, 10.0], [1.79231119E12, 10.0], [1.792311105E12, 10.0], [1.79231107E12, 10.0], [1.792311155E12, 10.0], [1.7923112E12, 8.500000000000002], [1.79231111E12, 10.0], [1.792311195E12, 10.0], [1.792311075E12, 10.0], [1.79231112E12, 10.0], [1.792311115E12, 10.0], [1.79231116E12, 10.0], [1.792311125E12, 10.0], [1.79231108E12, 10.0], [1.792311165E12, 10.0], [1.79231113E12, 10.0], [1.79231117E12, 10.0], [1.792311085E12, 10.0], [1.792311135E12, 10.0], [1.79231109E12, 10.0], [1.792311175E12, 10.0], [1.79231114E12, 10.0], [1.792311055E12, 10.0], [1.79231118E12, 10.0], [1.792311095E12, 10.0], [1.79231106E12, 10.0], [1.792311145E12, 10.0], [1.7923111E12, 10.0], [1.792311185E12, 10.0]], "isOverall": false, "label": "Thread Group", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.7923112E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 133.0, "minX": 1.0, "maxY": 207.28311258278157, "series": [{"data": [[8.0, 147.0], [4.0, 174.0], [2.0, 193.0], [1.0, 146.0], [9.0, 148.0], [10.0, 207.28311258278157], [5.0, 133.0], [6.0, 137.0], [3.0, 164.0], [7.0, 134.0]], "isOverall": false, "label": "GET - List Orders Direct Azure", "isController": false}, {"data": [[9.963023829087918, 206.8808545603945]], "isOverall": false, "label": "GET - List Orders Direct Azure-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 10.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 9396.0, "minX": 1.792311055E12, "maxY": 70444.8, "series": [{"data": [[1.79231115E12, 57236.4], [1.792311065E12, 60171.6], [1.79231119E12, 64574.4], [1.792311105E12, 67511.0], [1.79231107E12, 55768.8], [1.792311155E12, 64574.4], [1.7923112E12, 44029.4], [1.79231111E12, 55770.2], [1.792311195E12, 57236.4], [1.792311075E12, 60171.6], [1.79231112E12, 54301.2], [1.792311115E12, 57236.4], [1.79231116E12, 57236.4], [1.792311125E12, 63106.8], [1.79231108E12, 70444.8], [1.792311165E12, 61639.2], [1.79231113E12, 51366.0], [1.79231117E12, 68977.2], [1.792311085E12, 54301.2], [1.792311135E12, 60171.6], [1.79231109E12, 57236.4], [1.792311175E12, 60171.6], [1.79231114E12, 58704.0], [1.792311055E12, 58704.0], [1.79231118E12, 60171.6], [1.792311095E12, 60171.6], [1.79231106E12, 61639.2], [1.792311145E12, 61639.2], [1.7923111E12, 58704.0], [1.792311185E12, 63106.8]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.79231115E12, 12214.8], [1.792311065E12, 12841.2], [1.79231119E12, 13780.8], [1.792311105E12, 14407.2], [1.79231107E12, 11901.6], [1.792311155E12, 13780.8], [1.7923112E12, 9396.0], [1.79231111E12, 11901.6], [1.792311195E12, 12214.8], [1.792311075E12, 12841.2], [1.79231112E12, 11588.4], [1.792311115E12, 12214.8], [1.79231116E12, 12214.8], [1.792311125E12, 13467.6], [1.79231108E12, 15033.6], [1.792311165E12, 13154.4], [1.79231113E12, 10962.0], [1.79231117E12, 14720.4], [1.792311085E12, 11588.4], [1.792311135E12, 12841.2], [1.79231109E12, 12214.8], [1.792311175E12, 12841.2], [1.79231114E12, 12528.0], [1.792311055E12, 12528.0], [1.79231118E12, 12841.2], [1.792311095E12, 12841.2], [1.79231106E12, 13154.4], [1.792311145E12, 13154.4], [1.7923111E12, 12528.0], [1.792311185E12, 13467.6]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.7923112E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 137.04878048780495, "minX": 1.792311055E12, "maxY": 369.6857142857143, "series": [{"data": [[1.79231115E12, 303.7179487179487], [1.792311065E12, 168.70731707317074], [1.79231119E12, 141.31818181818184], [1.792311105E12, 205.7826086956522], [1.79231107E12, 350.52631578947376], [1.792311155E12, 141.9545454545454], [1.7923112E12, 148.86666666666665], [1.79231111E12, 295.7368421052632], [1.792311195E12, 237.53846153846158], [1.792311075E12, 149.36585365853657], [1.79231112E12, 332.94594594594594], [1.792311115E12, 215.76923076923075], [1.79231116E12, 148.69230769230765], [1.792311125E12, 185.79069767441862], [1.79231108E12, 152.24999999999997], [1.792311165E12, 250.11904761904762], [1.79231113E12, 369.6857142857143], [1.79231117E12, 142.63829787234044], [1.792311085E12, 304.5135135135136], [1.792311135E12, 286.09756097560984], [1.79231109E12, 301.1538461538461], [1.792311175E12, 137.04878048780495], [1.79231114E12, 169.975], [1.792311055E12, 154.87499999999997], [1.79231118E12, 204.02439024390242], [1.792311095E12, 141.1707317073171], [1.79231106E12, 162.21428571428575], [1.792311145E12, 191.3095238095238], [1.7923111E12, 148.42500000000004], [1.792311185E12, 148.8139534883721]], "isOverall": false, "label": "GET - List Orders Direct Azure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.7923112E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 131.43902439024396, "minX": 1.792311055E12, "maxY": 346.8857142857143, "series": [{"data": [[1.79231115E12, 275.4358974358974], [1.792311065E12, 153.02439024390242], [1.79231119E12, 136.5909090909091], [1.792311105E12, 202.71739130434784], [1.79231107E12, 315.6052631578947], [1.792311155E12, 133.18181818181822], [1.7923112E12, 141.60000000000002], [1.79231111E12, 258.5263157894737], [1.792311195E12, 197.33333333333331], [1.792311075E12, 143.3170731707317], [1.79231112E12, 265.32432432432427], [1.792311115E12, 191.25641025641028], [1.79231116E12, 144.56410256410254], [1.792311125E12, 166.3488372093024], [1.79231108E12, 148.58333333333334], [1.792311165E12, 243.66666666666669], [1.79231113E12, 346.8857142857143], [1.79231117E12, 136.59574468085106], [1.792311085E12, 296.5405405405405], [1.792311135E12, 246.95121951219517], [1.79231109E12, 280.3846153846154], [1.792311175E12, 131.43902439024396], [1.79231114E12, 164.75000000000003], [1.792311055E12, 150.87499999999997], [1.79231118E12, 193.51219512195124], [1.792311095E12, 137.02439024390247], [1.79231106E12, 156.52380952380955], [1.792311145E12, 186.8809523809524], [1.7923111E12, 145.24999999999997], [1.792311185E12, 138.79069767441865]], "isOverall": false, "label": "GET - List Orders Direct Azure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.7923112E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 0.0, "minX": 1.792311055E12, "maxY": 102.1282051282051, "series": [{"data": [[1.79231115E12, 40.38461538461539], [1.792311065E12, 0.0], [1.79231119E12, 0.0], [1.792311105E12, 0.0], [1.79231107E12, 0.0], [1.792311155E12, 0.0], [1.7923112E12, 0.0], [1.79231111E12, 0.0], [1.792311195E12, 0.0], [1.792311075E12, 0.0], [1.79231112E12, 0.0], [1.792311115E12, 0.0], [1.79231116E12, 0.0], [1.792311125E12, 0.0], [1.79231108E12, 0.0], [1.792311165E12, 0.0], [1.79231113E12, 0.0], [1.79231117E12, 0.0], [1.792311085E12, 57.13513513513514], [1.792311135E12, 0.0], [1.79231109E12, 102.1282051282051], [1.792311175E12, 0.0], [1.79231114E12, 0.0], [1.792311055E12, 0.0], [1.79231118E12, 0.0], [1.792311095E12, 0.0], [1.79231106E12, 0.0], [1.792311145E12, 22.97619047619047], [1.7923111E12, 0.0], [1.792311185E12, 0.0]], "isOverall": false, "label": "GET - List Orders Direct Azure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.7923112E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 114.0, "minX": 1.792311055E12, "maxY": 2194.0, "series": [{"data": [[1.79231115E12, 1247.0], [1.792311065E12, 569.0], [1.79231119E12, 174.0], [1.792311105E12, 462.0], [1.79231107E12, 1306.0], [1.792311155E12, 368.0], [1.7923112E12, 222.0], [1.79231111E12, 1625.0], [1.792311195E12, 1522.0], [1.792311075E12, 222.0], [1.79231112E12, 1060.0], [1.792311115E12, 602.0], [1.79231116E12, 295.0], [1.792311125E12, 488.0], [1.79231108E12, 204.0], [1.792311165E12, 982.0], [1.79231113E12, 1360.0], [1.79231117E12, 175.0], [1.792311085E12, 1156.0], [1.792311135E12, 1241.0], [1.79231109E12, 2194.0], [1.792311175E12, 156.0], [1.79231114E12, 237.0], [1.792311055E12, 202.0], [1.79231118E12, 596.0], [1.792311095E12, 178.0], [1.79231106E12, 251.0], [1.792311145E12, 450.0], [1.7923111E12, 184.0], [1.792311185E12, 447.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.79231115E12, 124.0], [1.792311065E12, 120.0], [1.79231119E12, 120.0], [1.792311105E12, 130.0], [1.79231107E12, 124.0], [1.792311155E12, 118.0], [1.7923112E12, 127.0], [1.79231111E12, 122.0], [1.792311195E12, 119.0], [1.792311075E12, 117.0], [1.79231112E12, 129.0], [1.792311115E12, 130.0], [1.79231116E12, 120.0], [1.792311125E12, 125.0], [1.79231108E12, 119.0], [1.792311165E12, 119.0], [1.79231113E12, 134.0], [1.79231117E12, 115.0], [1.792311085E12, 126.0], [1.792311135E12, 136.0], [1.79231109E12, 134.0], [1.792311175E12, 118.0], [1.79231114E12, 129.0], [1.792311055E12, 125.0], [1.79231118E12, 114.0], [1.792311095E12, 119.0], [1.79231106E12, 117.0], [1.792311145E12, 133.0], [1.7923111E12, 124.0], [1.792311185E12, 115.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.79231115E12, 607.0], [1.792311065E12, 204.20000000000005], [1.79231119E12, 157.0], [1.792311105E12, 271.8], [1.79231107E12, 760.0], [1.792311155E12, 155.5], [1.7923112E12, 173.5], [1.79231111E12, 572.1000000000007], [1.792311195E12, 573.0], [1.792311075E12, 169.0], [1.79231112E12, 934.8000000000004], [1.792311115E12, 444.0], [1.79231116E12, 182.0], [1.792311125E12, 322.00000000000006], [1.79231108E12, 194.0], [1.792311165E12, 727.7000000000011], [1.79231113E12, 777.6], [1.79231117E12, 165.8], [1.792311085E12, 653.4000000000001], [1.792311135E12, 878.0000000000003], [1.79231109E12, 464.0], [1.792311175E12, 152.60000000000002], [1.79231114E12, 207.0], [1.792311055E12, 185.1], [1.79231118E12, 512.0000000000001], [1.792311095E12, 162.60000000000002], [1.79231106E12, 189.7], [1.792311145E12, 336.1000000000004], [1.7923111E12, 169.0], [1.792311185E12, 164.2]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.79231115E12, 1247.0], [1.792311065E12, 569.0], [1.79231119E12, 174.0], [1.792311105E12, 462.0], [1.79231107E12, 1306.0], [1.792311155E12, 368.0], [1.7923112E12, 222.0], [1.79231111E12, 1625.0], [1.792311195E12, 1522.0], [1.792311075E12, 222.0], [1.79231112E12, 1060.0], [1.792311115E12, 602.0], [1.79231116E12, 295.0], [1.792311125E12, 488.0], [1.79231108E12, 204.0], [1.792311165E12, 982.0], [1.79231113E12, 1360.0], [1.79231117E12, 175.0], [1.792311085E12, 1156.0], [1.792311135E12, 1241.0], [1.79231109E12, 2194.0], [1.792311175E12, 156.0], [1.79231114E12, 237.0], [1.792311055E12, 202.0], [1.79231118E12, 596.0], [1.792311095E12, 178.0], [1.79231106E12, 251.0], [1.792311145E12, 450.0], [1.7923111E12, 184.0], [1.792311185E12, 447.0]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.79231115E12, 184.0], [1.792311065E12, 143.0], [1.79231119E12, 138.0], [1.792311105E12, 200.5], [1.79231107E12, 227.0], [1.792311155E12, 136.5], [1.7923112E12, 145.0], [1.79231111E12, 170.5], [1.792311195E12, 144.0], [1.792311075E12, 146.0], [1.79231112E12, 189.0], [1.792311115E12, 168.0], [1.79231116E12, 139.0], [1.792311125E12, 158.0], [1.79231108E12, 147.5], [1.792311165E12, 141.5], [1.79231113E12, 238.0], [1.79231117E12, 140.0], [1.792311085E12, 173.0], [1.792311135E12, 192.0], [1.79231109E12, 173.0], [1.792311175E12, 138.0], [1.79231114E12, 166.5], [1.792311055E12, 149.0], [1.79231118E12, 140.0], [1.792311095E12, 141.0], [1.79231106E12, 157.5], [1.792311145E12, 167.5], [1.7923111E12, 148.0], [1.792311185E12, 142.0]], "isOverall": false, "label": "Median", "isController": false}, {"data": [[1.79231115E12, 1049.0], [1.792311065E12, 457.9999999999996], [1.79231119E12, 159.0], [1.792311105E12, 294.84999999999997], [1.79231107E12, 916.4999999999989], [1.792311155E12, 169.25], [1.7923112E12, 206.04999999999998], [1.79231111E12, 1029.3499999999983], [1.792311195E12, 857.0], [1.792311075E12, 190.8], [1.79231112E12, 1060.0], [1.792311115E12, 533.0], [1.79231116E12, 209.0], [1.792311125E12, 443.39999999999964], [1.79231108E12, 203.0], [1.792311165E12, 898.0500000000001], [1.79231113E12, 1099.9999999999986], [1.79231117E12, 171.6], [1.792311085E12, 963.4000000000003], [1.792311135E12, 943.5], [1.79231109E12, 1656.0], [1.792311175E12, 154.9], [1.79231114E12, 219.74999999999997], [1.792311055E12, 192.95], [1.79231118E12, 581.5999999999999], [1.792311095E12, 166.9], [1.79231106E12, 225.90000000000003], [1.792311145E12, 395.55], [1.7923111E12, 178.64999999999998], [1.792311185E12, 184.39999999999995]], "isOverall": false, "label": "95th percentile", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.7923112E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 147.5, "minX": 2.0, "maxY": 284.5, "series": [{"data": [[4.0, 162.5], [8.0, 147.5], [2.0, 284.5], [9.0, 151.0], [10.0, 154.0], [5.0, 148.0], [3.0, 170.0], [6.0, 155.0], [7.0, 157.5]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 10.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 143.0, "minX": 2.0, "maxY": 203.0, "series": [{"data": [[4.0, 160.0], [8.0, 143.5], [2.0, 203.0], [9.0, 147.0], [10.0, 148.0], [5.0, 143.0], [3.0, 145.0], [6.0, 149.0], [7.0, 152.5]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 10.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 5.8, "minX": 1.792311055E12, "maxY": 9.6, "series": [{"data": [[1.79231115E12, 8.0], [1.792311065E12, 8.4], [1.79231119E12, 9.0], [1.792311105E12, 8.6], [1.79231107E12, 7.6], [1.792311155E12, 8.6], [1.7923112E12, 5.8], [1.79231111E12, 7.8], [1.792311195E12, 7.6], [1.792311075E12, 8.2], [1.79231112E12, 7.2], [1.792311115E12, 7.6], [1.79231116E12, 8.2], [1.792311125E12, 8.4], [1.79231108E12, 9.6], [1.792311165E12, 7.8], [1.79231113E12, 7.4], [1.79231117E12, 9.6], [1.792311085E12, 7.6], [1.792311135E12, 7.8], [1.79231109E12, 7.4], [1.792311175E12, 8.0], [1.79231114E12, 8.0], [1.792311055E12, 8.4], [1.79231118E12, 8.2], [1.792311095E12, 8.2], [1.79231106E12, 8.0], [1.792311145E12, 8.6], [1.7923111E12, 9.0], [1.792311185E12, 8.8]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.7923112E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 6.0, "minX": 1.792311055E12, "maxY": 9.6, "series": [{"data": [[1.79231115E12, 7.8], [1.792311065E12, 8.2], [1.79231119E12, 8.8], [1.792311105E12, 9.2], [1.79231107E12, 7.6], [1.792311155E12, 8.8], [1.7923112E12, 6.0], [1.79231111E12, 7.6], [1.792311195E12, 7.8], [1.792311075E12, 8.2], [1.79231112E12, 7.4], [1.792311115E12, 7.8], [1.79231116E12, 7.8], [1.792311125E12, 8.6], [1.79231108E12, 9.6], [1.792311165E12, 8.4], [1.79231113E12, 7.0], [1.79231117E12, 9.4], [1.792311085E12, 7.4], [1.792311135E12, 8.2], [1.79231109E12, 7.8], [1.792311175E12, 8.2], [1.79231114E12, 8.0], [1.792311055E12, 8.0], [1.79231118E12, 8.2], [1.792311095E12, 8.2], [1.79231106E12, 8.4], [1.792311145E12, 8.4], [1.7923111E12, 8.0], [1.792311185E12, 8.6]], "isOverall": false, "label": "200", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.7923112E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 6.0, "minX": 1.792311055E12, "maxY": 9.6, "series": [{"data": [[1.79231115E12, 7.8], [1.792311065E12, 8.2], [1.79231119E12, 8.8], [1.792311105E12, 9.2], [1.79231107E12, 7.6], [1.792311155E12, 8.8], [1.7923112E12, 6.0], [1.79231111E12, 7.6], [1.792311195E12, 7.8], [1.792311075E12, 8.2], [1.79231112E12, 7.4], [1.792311115E12, 7.8], [1.79231116E12, 7.8], [1.792311125E12, 8.6], [1.79231108E12, 9.6], [1.792311165E12, 8.4], [1.79231113E12, 7.0], [1.79231117E12, 9.4], [1.792311085E12, 7.4], [1.792311135E12, 8.2], [1.79231109E12, 7.8], [1.792311175E12, 8.2], [1.79231114E12, 8.0], [1.792311055E12, 8.0], [1.79231118E12, 8.2], [1.792311095E12, 8.2], [1.79231106E12, 8.4], [1.792311145E12, 8.4], [1.7923111E12, 8.0], [1.792311185E12, 8.6]], "isOverall": false, "label": "GET - List Orders Direct Azure-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.7923112E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 6.0, "minX": 1.792311055E12, "maxY": 9.6, "series": [{"data": [[1.79231115E12, 7.8], [1.792311065E12, 8.2], [1.79231119E12, 8.8], [1.792311105E12, 9.2], [1.79231107E12, 7.6], [1.792311155E12, 8.8], [1.7923112E12, 6.0], [1.79231111E12, 7.6], [1.792311195E12, 7.8], [1.792311075E12, 8.2], [1.79231112E12, 7.4], [1.792311115E12, 7.8], [1.79231116E12, 7.8], [1.792311125E12, 8.6], [1.79231108E12, 9.6], [1.792311165E12, 8.4], [1.79231113E12, 7.0], [1.79231117E12, 9.4], [1.792311085E12, 7.4], [1.792311135E12, 8.2], [1.79231109E12, 7.8], [1.792311175E12, 8.2], [1.79231114E12, 8.0], [1.792311055E12, 8.0], [1.79231118E12, 8.2], [1.792311095E12, 8.2], [1.79231106E12, 8.4], [1.792311145E12, 8.4], [1.7923111E12, 8.0], [1.792311185E12, 8.6]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.7923112E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

