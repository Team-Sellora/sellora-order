/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 114.0, "minX": 0.0, "maxY": 6238.0, "series": [{"data": [[0.0, 114.0], [0.1, 117.0], [0.2, 119.0], [0.3, 120.0], [0.4, 121.0], [0.5, 121.0], [0.6, 122.0], [0.7, 123.0], [0.8, 124.0], [0.9, 124.0], [1.0, 125.0], [1.1, 125.0], [1.2, 125.0], [1.3, 126.0], [1.4, 126.0], [1.5, 127.0], [1.6, 127.0], [1.7, 127.0], [1.8, 128.0], [1.9, 128.0], [2.0, 128.0], [2.1, 129.0], [2.2, 129.0], [2.3, 129.0], [2.4, 129.0], [2.5, 129.0], [2.6, 130.0], [2.7, 130.0], [2.8, 130.0], [2.9, 130.0], [3.0, 131.0], [3.1, 131.0], [3.2, 131.0], [3.3, 131.0], [3.4, 131.0], [3.5, 132.0], [3.6, 132.0], [3.7, 132.0], [3.8, 133.0], [3.9, 133.0], [4.0, 133.0], [4.1, 133.0], [4.2, 133.0], [4.3, 133.0], [4.4, 134.0], [4.5, 134.0], [4.6, 134.0], [4.7, 134.0], [4.8, 134.0], [4.9, 134.0], [5.0, 135.0], [5.1, 135.0], [5.2, 135.0], [5.3, 135.0], [5.4, 135.0], [5.5, 136.0], [5.6, 136.0], [5.7, 136.0], [5.8, 136.0], [5.9, 136.0], [6.0, 137.0], [6.1, 137.0], [6.2, 137.0], [6.3, 137.0], [6.4, 137.0], [6.5, 137.0], [6.6, 137.0], [6.7, 138.0], [6.8, 138.0], [6.9, 138.0], [7.0, 138.0], [7.1, 138.0], [7.2, 138.0], [7.3, 139.0], [7.4, 139.0], [7.5, 139.0], [7.6, 139.0], [7.7, 139.0], [7.8, 139.0], [7.9, 139.0], [8.0, 140.0], [8.1, 140.0], [8.2, 140.0], [8.3, 140.0], [8.4, 140.0], [8.5, 140.0], [8.6, 140.0], [8.7, 140.0], [8.8, 141.0], [8.9, 141.0], [9.0, 141.0], [9.1, 141.0], [9.2, 141.0], [9.3, 141.0], [9.4, 141.0], [9.5, 141.0], [9.6, 142.0], [9.7, 142.0], [9.8, 142.0], [9.9, 142.0], [10.0, 142.0], [10.1, 142.0], [10.2, 142.0], [10.3, 143.0], [10.4, 143.0], [10.5, 143.0], [10.6, 143.0], [10.7, 143.0], [10.8, 143.0], [10.9, 143.0], [11.0, 143.0], [11.1, 144.0], [11.2, 144.0], [11.3, 144.0], [11.4, 144.0], [11.5, 144.0], [11.6, 144.0], [11.7, 144.0], [11.8, 144.0], [11.9, 145.0], [12.0, 145.0], [12.1, 145.0], [12.2, 145.0], [12.3, 145.0], [12.4, 145.0], [12.5, 145.0], [12.6, 145.0], [12.7, 145.0], [12.8, 146.0], [12.9, 146.0], [13.0, 146.0], [13.1, 146.0], [13.2, 146.0], [13.3, 146.0], [13.4, 146.0], [13.5, 146.0], [13.6, 146.0], [13.7, 147.0], [13.8, 147.0], [13.9, 147.0], [14.0, 147.0], [14.1, 147.0], [14.2, 147.0], [14.3, 147.0], [14.4, 147.0], [14.5, 148.0], [14.6, 148.0], [14.7, 148.0], [14.8, 148.0], [14.9, 148.0], [15.0, 148.0], [15.1, 148.0], [15.2, 149.0], [15.3, 149.0], [15.4, 149.0], [15.5, 149.0], [15.6, 149.0], [15.7, 149.0], [15.8, 149.0], [15.9, 149.0], [16.0, 149.0], [16.1, 150.0], [16.2, 150.0], [16.3, 150.0], [16.4, 150.0], [16.5, 150.0], [16.6, 150.0], [16.7, 150.0], [16.8, 150.0], [16.9, 151.0], [17.0, 151.0], [17.1, 151.0], [17.2, 151.0], [17.3, 151.0], [17.4, 152.0], [17.5, 152.0], [17.6, 152.0], [17.7, 152.0], [17.8, 152.0], [17.9, 152.0], [18.0, 152.0], [18.1, 152.0], [18.2, 153.0], [18.3, 153.0], [18.4, 153.0], [18.5, 153.0], [18.6, 153.0], [18.7, 153.0], [18.8, 153.0], [18.9, 154.0], [19.0, 154.0], [19.1, 154.0], [19.2, 154.0], [19.3, 154.0], [19.4, 154.0], [19.5, 154.0], [19.6, 154.0], [19.7, 154.0], [19.8, 154.0], [19.9, 154.0], [20.0, 155.0], [20.1, 155.0], [20.2, 155.0], [20.3, 155.0], [20.4, 155.0], [20.5, 155.0], [20.6, 155.0], [20.7, 155.0], [20.8, 156.0], [20.9, 156.0], [21.0, 156.0], [21.1, 156.0], [21.2, 156.0], [21.3, 156.0], [21.4, 156.0], [21.5, 156.0], [21.6, 156.0], [21.7, 156.0], [21.8, 157.0], [21.9, 157.0], [22.0, 157.0], [22.1, 157.0], [22.2, 157.0], [22.3, 157.0], [22.4, 158.0], [22.5, 158.0], [22.6, 158.0], [22.7, 158.0], [22.8, 158.0], [22.9, 158.0], [23.0, 158.0], [23.1, 158.0], [23.2, 159.0], [23.3, 159.0], [23.4, 159.0], [23.5, 159.0], [23.6, 159.0], [23.7, 159.0], [23.8, 159.0], [23.9, 159.0], [24.0, 160.0], [24.1, 160.0], [24.2, 160.0], [24.3, 160.0], [24.4, 160.0], [24.5, 160.0], [24.6, 161.0], [24.7, 161.0], [24.8, 161.0], [24.9, 161.0], [25.0, 161.0], [25.1, 161.0], [25.2, 161.0], [25.3, 161.0], [25.4, 162.0], [25.5, 162.0], [25.6, 162.0], [25.7, 162.0], [25.8, 162.0], [25.9, 162.0], [26.0, 162.0], [26.1, 162.0], [26.2, 163.0], [26.3, 163.0], [26.4, 163.0], [26.5, 163.0], [26.6, 163.0], [26.7, 163.0], [26.8, 163.0], [26.9, 163.0], [27.0, 164.0], [27.1, 164.0], [27.2, 164.0], [27.3, 164.0], [27.4, 164.0], [27.5, 164.0], [27.6, 164.0], [27.7, 164.0], [27.8, 165.0], [27.9, 165.0], [28.0, 165.0], [28.1, 165.0], [28.2, 165.0], [28.3, 165.0], [28.4, 165.0], [28.5, 165.0], [28.6, 165.0], [28.7, 165.0], [28.8, 166.0], [28.9, 166.0], [29.0, 166.0], [29.1, 166.0], [29.2, 166.0], [29.3, 166.0], [29.4, 166.0], [29.5, 167.0], [29.6, 167.0], [29.7, 167.0], [29.8, 167.0], [29.9, 167.0], [30.0, 167.0], [30.1, 168.0], [30.2, 168.0], [30.3, 168.0], [30.4, 168.0], [30.5, 168.0], [30.6, 168.0], [30.7, 168.0], [30.8, 168.0], [30.9, 169.0], [31.0, 169.0], [31.1, 169.0], [31.2, 169.0], [31.3, 169.0], [31.4, 169.0], [31.5, 169.0], [31.6, 170.0], [31.7, 170.0], [31.8, 170.0], [31.9, 170.0], [32.0, 170.0], [32.1, 170.0], [32.2, 170.0], [32.3, 170.0], [32.4, 171.0], [32.5, 171.0], [32.6, 171.0], [32.7, 171.0], [32.8, 171.0], [32.9, 171.0], [33.0, 171.0], [33.1, 171.0], [33.2, 172.0], [33.3, 172.0], [33.4, 172.0], [33.5, 172.0], [33.6, 172.0], [33.7, 172.0], [33.8, 173.0], [33.9, 173.0], [34.0, 173.0], [34.1, 173.0], [34.2, 173.0], [34.3, 173.0], [34.4, 174.0], [34.5, 174.0], [34.6, 174.0], [34.7, 174.0], [34.8, 174.0], [34.9, 174.0], [35.0, 175.0], [35.1, 175.0], [35.2, 175.0], [35.3, 175.0], [35.4, 175.0], [35.5, 175.0], [35.6, 175.0], [35.7, 176.0], [35.8, 176.0], [35.9, 176.0], [36.0, 176.0], [36.1, 176.0], [36.2, 176.0], [36.3, 176.0], [36.4, 177.0], [36.5, 177.0], [36.6, 177.0], [36.7, 177.0], [36.8, 177.0], [36.9, 177.0], [37.0, 177.0], [37.1, 178.0], [37.2, 178.0], [37.3, 178.0], [37.4, 178.0], [37.5, 178.0], [37.6, 178.0], [37.7, 178.0], [37.8, 179.0], [37.9, 179.0], [38.0, 179.0], [38.1, 179.0], [38.2, 179.0], [38.3, 179.0], [38.4, 180.0], [38.5, 180.0], [38.6, 180.0], [38.7, 180.0], [38.8, 180.0], [38.9, 180.0], [39.0, 180.0], [39.1, 181.0], [39.2, 181.0], [39.3, 181.0], [39.4, 181.0], [39.5, 181.0], [39.6, 181.0], [39.7, 181.0], [39.8, 181.0], [39.9, 182.0], [40.0, 182.0], [40.1, 182.0], [40.2, 182.0], [40.3, 182.0], [40.4, 182.0], [40.5, 182.0], [40.6, 183.0], [40.7, 183.0], [40.8, 183.0], [40.9, 183.0], [41.0, 183.0], [41.1, 183.0], [41.2, 184.0], [41.3, 184.0], [41.4, 184.0], [41.5, 184.0], [41.6, 184.0], [41.7, 184.0], [41.8, 185.0], [41.9, 185.0], [42.0, 185.0], [42.1, 185.0], [42.2, 185.0], [42.3, 185.0], [42.4, 186.0], [42.5, 186.0], [42.6, 186.0], [42.7, 186.0], [42.8, 186.0], [42.9, 186.0], [43.0, 187.0], [43.1, 187.0], [43.2, 187.0], [43.3, 187.0], [43.4, 187.0], [43.5, 187.0], [43.6, 187.0], [43.7, 187.0], [43.8, 187.0], [43.9, 187.0], [44.0, 188.0], [44.1, 188.0], [44.2, 188.0], [44.3, 188.0], [44.4, 188.0], [44.5, 189.0], [44.6, 189.0], [44.7, 189.0], [44.8, 189.0], [44.9, 189.0], [45.0, 190.0], [45.1, 190.0], [45.2, 190.0], [45.3, 191.0], [45.4, 191.0], [45.5, 191.0], [45.6, 192.0], [45.7, 192.0], [45.8, 192.0], [45.9, 192.0], [46.0, 192.0], [46.1, 192.0], [46.2, 193.0], [46.3, 193.0], [46.4, 193.0], [46.5, 193.0], [46.6, 193.0], [46.7, 194.0], [46.8, 194.0], [46.9, 194.0], [47.0, 194.0], [47.1, 194.0], [47.2, 195.0], [47.3, 195.0], [47.4, 195.0], [47.5, 195.0], [47.6, 196.0], [47.7, 196.0], [47.8, 196.0], [47.9, 197.0], [48.0, 197.0], [48.1, 197.0], [48.2, 197.0], [48.3, 198.0], [48.4, 198.0], [48.5, 198.0], [48.6, 198.0], [48.7, 198.0], [48.8, 199.0], [48.9, 199.0], [49.0, 199.0], [49.1, 199.0], [49.2, 199.0], [49.3, 200.0], [49.4, 200.0], [49.5, 200.0], [49.6, 201.0], [49.7, 201.0], [49.8, 201.0], [49.9, 201.0], [50.0, 202.0], [50.1, 202.0], [50.2, 202.0], [50.3, 202.0], [50.4, 203.0], [50.5, 203.0], [50.6, 203.0], [50.7, 203.0], [50.8, 204.0], [50.9, 204.0], [51.0, 204.0], [51.1, 204.0], [51.2, 205.0], [51.3, 205.0], [51.4, 205.0], [51.5, 206.0], [51.6, 206.0], [51.7, 206.0], [51.8, 206.0], [51.9, 206.0], [52.0, 206.0], [52.1, 207.0], [52.2, 207.0], [52.3, 208.0], [52.4, 208.0], [52.5, 208.0], [52.6, 208.0], [52.7, 209.0], [52.8, 209.0], [52.9, 209.0], [53.0, 209.0], [53.1, 210.0], [53.2, 210.0], [53.3, 210.0], [53.4, 210.0], [53.5, 211.0], [53.6, 211.0], [53.7, 211.0], [53.8, 211.0], [53.9, 212.0], [54.0, 212.0], [54.1, 212.0], [54.2, 212.0], [54.3, 213.0], [54.4, 213.0], [54.5, 213.0], [54.6, 213.0], [54.7, 214.0], [54.8, 214.0], [54.9, 214.0], [55.0, 214.0], [55.1, 215.0], [55.2, 215.0], [55.3, 215.0], [55.4, 216.0], [55.5, 216.0], [55.6, 216.0], [55.7, 216.0], [55.8, 217.0], [55.9, 217.0], [56.0, 217.0], [56.1, 217.0], [56.2, 218.0], [56.3, 218.0], [56.4, 218.0], [56.5, 219.0], [56.6, 219.0], [56.7, 220.0], [56.8, 220.0], [56.9, 220.0], [57.0, 221.0], [57.1, 221.0], [57.2, 221.0], [57.3, 222.0], [57.4, 222.0], [57.5, 222.0], [57.6, 223.0], [57.7, 224.0], [57.8, 224.0], [57.9, 224.0], [58.0, 225.0], [58.1, 225.0], [58.2, 226.0], [58.3, 226.0], [58.4, 226.0], [58.5, 227.0], [58.6, 227.0], [58.7, 228.0], [58.8, 228.0], [58.9, 228.0], [59.0, 229.0], [59.1, 230.0], [59.2, 230.0], [59.3, 230.0], [59.4, 230.0], [59.5, 231.0], [59.6, 231.0], [59.7, 232.0], [59.8, 232.0], [59.9, 232.0], [60.0, 233.0], [60.1, 233.0], [60.2, 234.0], [60.3, 234.0], [60.4, 234.0], [60.5, 234.0], [60.6, 235.0], [60.7, 235.0], [60.8, 236.0], [60.9, 236.0], [61.0, 236.0], [61.1, 237.0], [61.2, 237.0], [61.3, 237.0], [61.4, 238.0], [61.5, 238.0], [61.6, 238.0], [61.7, 239.0], [61.8, 239.0], [61.9, 239.0], [62.0, 240.0], [62.1, 240.0], [62.2, 240.0], [62.3, 241.0], [62.4, 241.0], [62.5, 241.0], [62.6, 242.0], [62.7, 242.0], [62.8, 243.0], [62.9, 243.0], [63.0, 244.0], [63.1, 244.0], [63.2, 244.0], [63.3, 244.0], [63.4, 244.0], [63.5, 245.0], [63.6, 245.0], [63.7, 245.0], [63.8, 246.0], [63.9, 246.0], [64.0, 246.0], [64.1, 246.0], [64.2, 246.0], [64.3, 247.0], [64.4, 247.0], [64.5, 248.0], [64.6, 249.0], [64.7, 249.0], [64.8, 249.0], [64.9, 249.0], [65.0, 250.0], [65.1, 250.0], [65.2, 250.0], [65.3, 251.0], [65.4, 251.0], [65.5, 251.0], [65.6, 252.0], [65.7, 252.0], [65.8, 252.0], [65.9, 253.0], [66.0, 254.0], [66.1, 254.0], [66.2, 255.0], [66.3, 255.0], [66.4, 255.0], [66.5, 256.0], [66.6, 257.0], [66.7, 257.0], [66.8, 258.0], [66.9, 259.0], [67.0, 259.0], [67.1, 259.0], [67.2, 260.0], [67.3, 260.0], [67.4, 261.0], [67.5, 261.0], [67.6, 262.0], [67.7, 262.0], [67.8, 262.0], [67.9, 262.0], [68.0, 263.0], [68.1, 264.0], [68.2, 264.0], [68.3, 265.0], [68.4, 265.0], [68.5, 266.0], [68.6, 266.0], [68.7, 266.0], [68.8, 267.0], [68.9, 267.0], [69.0, 267.0], [69.1, 268.0], [69.2, 268.0], [69.3, 269.0], [69.4, 269.0], [69.5, 269.0], [69.6, 269.0], [69.7, 270.0], [69.8, 270.0], [69.9, 271.0], [70.0, 271.0], [70.1, 271.0], [70.2, 272.0], [70.3, 273.0], [70.4, 274.0], [70.5, 275.0], [70.6, 275.0], [70.7, 277.0], [70.8, 277.0], [70.9, 278.0], [71.0, 278.0], [71.1, 279.0], [71.2, 279.0], [71.3, 280.0], [71.4, 280.0], [71.5, 281.0], [71.6, 281.0], [71.7, 282.0], [71.8, 282.0], [71.9, 282.0], [72.0, 282.0], [72.1, 283.0], [72.2, 283.0], [72.3, 284.0], [72.4, 284.0], [72.5, 285.0], [72.6, 285.0], [72.7, 285.0], [72.8, 286.0], [72.9, 287.0], [73.0, 288.0], [73.1, 288.0], [73.2, 289.0], [73.3, 290.0], [73.4, 291.0], [73.5, 292.0], [73.6, 292.0], [73.7, 293.0], [73.8, 293.0], [73.9, 294.0], [74.0, 294.0], [74.1, 295.0], [74.2, 296.0], [74.3, 297.0], [74.4, 298.0], [74.5, 299.0], [74.6, 299.0], [74.7, 300.0], [74.8, 301.0], [74.9, 301.0], [75.0, 302.0], [75.1, 303.0], [75.2, 303.0], [75.3, 304.0], [75.4, 305.0], [75.5, 305.0], [75.6, 306.0], [75.7, 307.0], [75.8, 307.0], [75.9, 308.0], [76.0, 309.0], [76.1, 309.0], [76.2, 310.0], [76.3, 311.0], [76.4, 312.0], [76.5, 314.0], [76.6, 315.0], [76.7, 316.0], [76.8, 316.0], [76.9, 316.0], [77.0, 317.0], [77.1, 318.0], [77.2, 318.0], [77.3, 319.0], [77.4, 319.0], [77.5, 320.0], [77.6, 321.0], [77.7, 323.0], [77.8, 324.0], [77.9, 325.0], [78.0, 325.0], [78.1, 326.0], [78.2, 328.0], [78.3, 329.0], [78.4, 330.0], [78.5, 331.0], [78.6, 331.0], [78.7, 332.0], [78.8, 334.0], [78.9, 334.0], [79.0, 335.0], [79.1, 336.0], [79.2, 337.0], [79.3, 338.0], [79.4, 339.0], [79.5, 340.0], [79.6, 340.0], [79.7, 342.0], [79.8, 343.0], [79.9, 345.0], [80.0, 346.0], [80.1, 347.0], [80.2, 348.0], [80.3, 348.0], [80.4, 349.0], [80.5, 349.0], [80.6, 350.0], [80.7, 351.0], [80.8, 353.0], [80.9, 354.0], [81.0, 355.0], [81.1, 355.0], [81.2, 356.0], [81.3, 357.0], [81.4, 358.0], [81.5, 359.0], [81.6, 361.0], [81.7, 362.0], [81.8, 362.0], [81.9, 363.0], [82.0, 365.0], [82.1, 365.0], [82.2, 366.0], [82.3, 368.0], [82.4, 369.0], [82.5, 370.0], [82.6, 372.0], [82.7, 374.0], [82.8, 376.0], [82.9, 379.0], [83.0, 380.0], [83.1, 381.0], [83.2, 382.0], [83.3, 383.0], [83.4, 387.0], [83.5, 388.0], [83.6, 392.0], [83.7, 392.0], [83.8, 394.0], [83.9, 395.0], [84.0, 397.0], [84.1, 401.0], [84.2, 402.0], [84.3, 405.0], [84.4, 407.0], [84.5, 408.0], [84.6, 409.0], [84.7, 412.0], [84.8, 413.0], [84.9, 415.0], [85.0, 419.0], [85.1, 421.0], [85.2, 424.0], [85.3, 425.0], [85.4, 426.0], [85.5, 427.0], [85.6, 429.0], [85.7, 431.0], [85.8, 435.0], [85.9, 436.0], [86.0, 438.0], [86.1, 441.0], [86.2, 443.0], [86.3, 444.0], [86.4, 446.0], [86.5, 451.0], [86.6, 453.0], [86.7, 455.0], [86.8, 458.0], [86.9, 461.0], [87.0, 464.0], [87.1, 469.0], [87.2, 472.0], [87.3, 473.0], [87.4, 478.0], [87.5, 483.0], [87.6, 488.0], [87.7, 491.0], [87.8, 493.0], [87.9, 495.0], [88.0, 499.0], [88.1, 501.0], [88.2, 506.0], [88.3, 508.0], [88.4, 511.0], [88.5, 514.0], [88.6, 519.0], [88.7, 521.0], [88.8, 527.0], [88.9, 532.0], [89.0, 533.0], [89.1, 535.0], [89.2, 540.0], [89.3, 544.0], [89.4, 549.0], [89.5, 553.0], [89.6, 558.0], [89.7, 561.0], [89.8, 564.0], [89.9, 569.0], [90.0, 576.0], [90.1, 582.0], [90.2, 583.0], [90.3, 588.0], [90.4, 589.0], [90.5, 594.0], [90.6, 600.0], [90.7, 603.0], [90.8, 604.0], [90.9, 607.0], [91.0, 612.0], [91.1, 619.0], [91.2, 622.0], [91.3, 625.0], [91.4, 631.0], [91.5, 636.0], [91.6, 641.0], [91.7, 645.0], [91.8, 647.0], [91.9, 651.0], [92.0, 653.0], [92.1, 658.0], [92.2, 667.0], [92.3, 680.0], [92.4, 685.0], [92.5, 693.0], [92.6, 697.0], [92.7, 707.0], [92.8, 712.0], [92.9, 716.0], [93.0, 720.0], [93.1, 728.0], [93.2, 732.0], [93.3, 739.0], [93.4, 746.0], [93.5, 748.0], [93.6, 756.0], [93.7, 764.0], [93.8, 778.0], [93.9, 787.0], [94.0, 800.0], [94.1, 803.0], [94.2, 815.0], [94.3, 824.0], [94.4, 830.0], [94.5, 834.0], [94.6, 840.0], [94.7, 844.0], [94.8, 858.0], [94.9, 867.0], [95.0, 868.0], [95.1, 880.0], [95.2, 891.0], [95.3, 904.0], [95.4, 924.0], [95.5, 931.0], [95.6, 950.0], [95.7, 969.0], [95.8, 986.0], [95.9, 988.0], [96.0, 1044.0], [96.1, 1065.0], [96.2, 1074.0], [96.3, 1121.0], [96.4, 1142.0], [96.5, 1193.0], [96.6, 1196.0], [96.7, 1236.0], [96.8, 1270.0], [96.9, 1312.0], [97.0, 1349.0], [97.1, 1409.0], [97.2, 1451.0], [97.3, 1516.0], [97.4, 1587.0], [97.5, 1618.0], [97.6, 1705.0], [97.7, 1770.0], [97.8, 1815.0], [97.9, 1866.0], [98.0, 1907.0], [98.1, 2042.0], [98.2, 2092.0], [98.3, 2409.0], [98.4, 2804.0], [98.5, 2902.0], [98.6, 2919.0], [98.7, 2949.0], [98.8, 2964.0], [98.9, 2980.0], [99.0, 3009.0], [99.1, 3091.0], [99.2, 3170.0], [99.3, 3176.0], [99.4, 3304.0], [99.5, 3397.0], [99.6, 3435.0], [99.7, 3619.0], [99.8, 3782.0], [99.9, 5292.0], [100.0, 6238.0]], "isOverall": false, "label": "GET - List Orders Direct Azure", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 100.0, "maxY": 2712.0, "series": [{"data": [[600.0, 115.0], [700.0, 74.0], [800.0, 69.0], [900.0, 40.0], [1000.0, 16.0], [1100.0, 20.0], [1200.0, 14.0], [1300.0, 12.0], [1400.0, 11.0], [1500.0, 8.0], [100.0, 2712.0], [1600.0, 8.0], [1700.0, 10.0], [1800.0, 11.0], [1900.0, 7.0], [2000.0, 6.0], [2100.0, 1.0], [2200.0, 2.0], [2300.0, 2.0], [2400.0, 1.0], [2500.0, 1.0], [2700.0, 3.0], [2800.0, 5.0], [2900.0, 28.0], [3000.0, 7.0], [3100.0, 11.0], [200.0, 1395.0], [3200.0, 4.0], [3300.0, 8.0], [3400.0, 6.0], [3500.0, 3.0], [3600.0, 5.0], [3700.0, 1.0], [4400.0, 1.0], [4600.0, 1.0], [4500.0, 1.0], [300.0, 521.0], [4800.0, 1.0], [4700.0, 1.0], [5200.0, 1.0], [5400.0, 4.0], [6200.0, 1.0], [400.0, 219.0], [500.0, 138.0]], "isOverall": false, "label": "GET - List Orders Direct Azure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 6200.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 149.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 4848.0, "series": [{"data": [[0.0, 4848.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 508.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [[2.0, 149.0]], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 2.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 39.610619469026545, "minX": 1.792312625E12, "maxY": 50.0, "series": [{"data": [[1.792312645E12, 50.0], [1.79231273E12, 50.0], [1.792312685E12, 50.0], [1.79231277E12, 50.0], [1.79231265E12, 50.0], [1.792312735E12, 50.0], [1.79231269E12, 50.0], [1.792312775E12, 39.610619469026545], [1.792312655E12, 50.0], [1.79231274E12, 50.0], [1.792312695E12, 50.0], [1.79231266E12, 50.0], [1.792312745E12, 50.0], [1.7923127E12, 50.0], [1.792312665E12, 50.0], [1.79231275E12, 50.0], [1.792312705E12, 50.0], [1.79231267E12, 50.0], [1.792312755E12, 50.0], [1.792312625E12, 50.0], [1.79231271E12, 50.0], [1.79231272E12, 50.0], [1.792312675E12, 50.0], [1.79231276E12, 50.0], [1.79231263E12, 50.0], [1.792312715E12, 50.0], [1.79231264E12, 50.0], [1.792312725E12, 50.0], [1.79231268E12, 50.0], [1.792312765E12, 50.0], [1.792312635E12, 50.0]], "isOverall": false, "label": "Thread Group", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.792312775E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 140.0, "minX": 1.0, "maxY": 2042.0, "series": [{"data": [[33.0, 154.0], [2.0, 1290.0], [35.0, 179.0], [34.0, 147.0], [37.0, 156.0], [36.0, 146.0], [38.0, 140.0], [41.0, 165.0], [43.0, 291.75], [3.0, 1417.0], [50.0, 336.4152325155625], [4.0, 1439.0], [5.0, 1451.0], [7.0, 176.0], [8.0, 170.0], [10.0, 162.0], [12.0, 246.66666666666666], [14.0, 146.5], [1.0, 2042.0], [18.0, 189.0], [20.0, 434.5], [21.0, 866.0], [23.0, 490.5], [25.0, 181.0], [26.0, 183.0], [27.0, 800.0], [28.0, 144.0], [29.0, 166.0], [30.0, 156.0]], "isOverall": false, "label": "GET - List Orders Direct Azure", "isController": false}, {"data": [[49.78673932788375, 337.001271571299]], "isOverall": false, "label": "GET - List Orders Direct Azure-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 50.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 1879.2, "minX": 1.792312625E12, "maxY": 314069.2, "series": [{"data": [[1.792312645E12, 234817.4], [1.79231273E12, 286182.0], [1.792312685E12, 314069.2], [1.79231277E12, 293521.4], [1.79231265E12, 281779.2], [1.792312735E12, 248024.4], [1.79231269E12, 292052.4], [1.792312775E12, 165838.8], [1.792312655E12, 299391.8], [1.79231274E12, 314066.4], [1.792312695E12, 297924.2], [1.79231266E12, 277380.6], [1.792312745E12, 101264.4], [1.7923127E12, 135019.2], [1.792312665E12, 287652.4], [1.79231275E12, 253894.8], [1.792312705E12, 300858.0], [1.79231267E12, 305263.4], [1.792312755E12, 306728.4], [1.792312625E12, 8805.6], [1.79231271E12, 287652.4], [1.79231272E12, 274441.2], [1.792312675E12, 308197.4], [1.79231276E12, 308196.0], [1.79231263E12, 226010.4], [1.792312715E12, 297924.2], [1.79231264E12, 296455.2], [1.792312725E12, 221607.6], [1.79231268E12, 303794.6], [1.792312765E12, 294989.0], [1.792312635E12, 255363.8]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.792312645E12, 50112.0], [1.79231273E12, 61074.0], [1.792312685E12, 67024.8], [1.79231277E12, 62640.0], [1.79231265E12, 60134.4], [1.792312735E12, 52930.8], [1.79231269E12, 62326.8], [1.792312775E12, 35391.6], [1.792312655E12, 63892.8], [1.79231274E12, 67024.8], [1.792312695E12, 63579.6], [1.79231266E12, 59194.8], [1.792312745E12, 21610.8], [1.7923127E12, 28814.4], [1.792312665E12, 61387.2], [1.79231275E12, 54183.6], [1.792312705E12, 64206.0], [1.79231267E12, 65145.6], [1.792312755E12, 65458.8], [1.792312625E12, 1879.2], [1.79231271E12, 61387.2], [1.79231272E12, 58568.4], [1.792312675E12, 65772.0], [1.79231276E12, 65772.0], [1.79231263E12, 48232.8], [1.792312715E12, 63579.6], [1.79231264E12, 63266.4], [1.792312725E12, 47293.2], [1.79231268E12, 64832.4], [1.792312765E12, 62953.2], [1.792312635E12, 54496.8]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.792312775E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 172.4953271028037, "minX": 1.792312625E12, "maxY": 1750.804347826087, "series": [{"data": [[1.792312645E12, 439.59375], [1.79231273E12, 577.7333333333335], [1.792312685E12, 172.4953271028037], [1.79231277E12, 260.66], [1.79231265E12, 314.2708333333335], [1.792312735E12, 443.4142011834318], [1.79231269E12, 200.77889447236183], [1.792312775E12, 273.3805309734513], [1.792312655E12, 228.31862745098024], [1.79231274E12, 218.32242990654214], [1.792312695E12, 180.26600985221685], [1.79231266E12, 320.5608465608466], [1.792312745E12, 305.8550724637682], [1.7923127E12, 1750.804347826087], [1.792312665E12, 270.8469387755103], [1.79231275E12, 1270.9768786127167], [1.792312705E12, 264.9268292682929], [1.79231267E12, 211.44711538461533], [1.792312755E12, 215.88038277511956], [1.792312625E12, 188.33333333333334], [1.79231271E12, 259.7346938775511], [1.79231272E12, 388.0481283422458], [1.792312675E12, 200.69523809523807], [1.79231276E12, 195.6714285714285], [1.79231263E12, 437.7662337662338], [1.792312715E12, 184.32512315270932], [1.79231264E12, 270.420792079208], [1.792312725E12, 246.7086092715232], [1.79231268E12, 196.93719806763292], [1.792312765E12, 219.52238805970146], [1.792312635E12, 566.4137931034483]], "isOverall": false, "label": "GET - List Orders Direct Azure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.792312775E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 167.3411214953271, "minX": 1.792312625E12, "maxY": 1380.6304347826087, "series": [{"data": [[1.792312645E12, 432.70624999999995], [1.79231273E12, 513.9128205128203], [1.792312685E12, 167.3411214953271], [1.79231277E12, 251.28999999999996], [1.79231265E12, 307.4322916666667], [1.792312735E12, 360.65680473372777], [1.79231269E12, 189.55276381909525], [1.792312775E12, 248.77876106194694], [1.792312655E12, 222.48039215686276], [1.79231274E12, 201.13551401869162], [1.792312695E12, 172.85714285714283], [1.79231266E12, 305.9206349206349], [1.792312745E12, 237.13043478260872], [1.7923127E12, 1380.6304347826087], [1.792312665E12, 257.48979591836735], [1.79231275E12, 1037.5895953757217], [1.792312705E12, 202.41951219512194], [1.79231267E12, 201.1346153846154], [1.792312755E12, 187.20095693779902], [1.792312625E12, 185.16666666666666], [1.79231271E12, 243.18367346938766], [1.79231272E12, 383.14973262032066], [1.792312675E12, 192.54285714285723], [1.79231276E12, 192.13809523809527], [1.79231263E12, 420.49350649350646], [1.792312715E12, 180.87684729064037], [1.79231264E12, 259.73762376237624], [1.792312725E12, 240.5298013245032], [1.79231268E12, 187.41545893719808], [1.792312765E12, 216.77611940298502], [1.792312635E12, 554.8333333333334]], "isOverall": false, "label": "GET - List Orders Direct Azure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.792312775E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 0.0, "minX": 1.792312625E12, "maxY": 107.7179487179487, "series": [{"data": [[1.792312645E12, 0.0], [1.79231273E12, 107.7179487179487], [1.792312685E12, 0.0], [1.79231277E12, 0.0], [1.79231265E12, 0.0], [1.792312735E12, 0.0], [1.79231269E12, 0.0], [1.792312775E12, 0.0], [1.792312655E12, 0.0], [1.79231274E12, 0.0], [1.792312695E12, 0.0], [1.79231266E12, 43.85185185185185], [1.792312745E12, 0.0], [1.7923127E12, 0.0], [1.792312665E12, 31.93367346938776], [1.79231275E12, 0.0], [1.792312705E12, 0.0], [1.79231267E12, 1.2403846153846163], [1.792312755E12, 0.0], [1.792312625E12, 0.0], [1.79231271E12, 0.0], [1.79231272E12, 38.43850267379679], [1.792312675E12, 0.0], [1.79231276E12, 0.0], [1.79231263E12, 0.0], [1.792312715E12, 0.0], [1.79231264E12, 0.0], [1.792312725E12, 34.89403973509935], [1.79231268E12, 0.0], [1.792312765E12, 0.0], [1.792312635E12, 0.0]], "isOverall": false, "label": "GET - List Orders Direct Azure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.792312775E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 114.0, "minX": 1.792312625E12, "maxY": 6238.0, "series": [{"data": [[1.792312645E12, 1086.0], [1.79231273E12, 4656.0], [1.792312685E12, 625.0], [1.79231277E12, 1123.0], [1.79231265E12, 1051.0], [1.792312735E12, 3404.0], [1.79231269E12, 1484.0], [1.792312775E12, 2042.0], [1.792312655E12, 986.0], [1.79231274E12, 840.0], [1.792312695E12, 1142.0], [1.79231266E12, 1328.0], [1.792312745E12, 3137.0], [1.7923127E12, 5292.0], [1.792312665E12, 1260.0], [1.79231275E12, 6238.0], [1.792312705E12, 5405.0], [1.79231267E12, 1298.0], [1.792312755E12, 802.0], [1.792312625E12, 209.0], [1.79231271E12, 1061.0], [1.79231272E12, 1742.0], [1.792312675E12, 1763.0], [1.79231276E12, 888.0], [1.79231263E12, 1659.0], [1.792312715E12, 793.0], [1.79231264E12, 1409.0], [1.792312725E12, 1293.0], [1.79231268E12, 739.0], [1.792312765E12, 451.0], [1.792312635E12, 2059.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.792312645E12, 143.0], [1.79231273E12, 120.0], [1.792312685E12, 117.0], [1.79231277E12, 136.0], [1.79231265E12, 152.0], [1.792312735E12, 122.0], [1.79231269E12, 116.0], [1.792312775E12, 128.0], [1.792312655E12, 130.0], [1.79231274E12, 119.0], [1.792312695E12, 114.0], [1.79231266E12, 127.0], [1.792312745E12, 121.0], [1.7923127E12, 192.0], [1.792312665E12, 125.0], [1.79231275E12, 136.0], [1.792312705E12, 116.0], [1.79231267E12, 119.0], [1.792312755E12, 125.0], [1.792312625E12, 145.0], [1.79231271E12, 120.0], [1.79231272E12, 139.0], [1.792312675E12, 118.0], [1.79231276E12, 118.0], [1.79231263E12, 140.0], [1.792312715E12, 119.0], [1.79231264E12, 143.0], [1.792312725E12, 122.0], [1.79231268E12, 115.0], [1.792312765E12, 128.0], [1.792312635E12, 168.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.792312645E12, 687.0], [1.79231273E12, 1636.8000000000002], [1.792312685E12, 234.5], [1.79231277E12, 422.0], [1.79231265E12, 488.60000000000014], [1.792312735E12, 921.0], [1.79231269E12, 261.0], [1.792312775E12, 356.0], [1.792312655E12, 318.0], [1.79231274E12, 306.5], [1.792312695E12, 235.79999999999995], [1.79231266E12, 619.0], [1.792312745E12, 573.0], [1.7923127E12, 3306.8], [1.792312665E12, 418.60000000000014], [1.79231275E12, 3406.0], [1.792312705E12, 324.4], [1.79231267E12, 269.2], [1.792312755E12, 346.0], [1.792312625E12, 209.0], [1.79231271E12, 464.70000000000044], [1.79231272E12, 712.4000000000001], [1.792312675E12, 239.9], [1.79231276E12, 276.0], [1.79231263E12, 1028.5], [1.792312715E12, 246.0], [1.79231264E12, 379.3000000000002], [1.792312725E12, 442.6], [1.79231268E12, 290.80000000000007], [1.792312765E12, 327.60000000000014], [1.792312635E12, 1275.5]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.792312645E12, 1029.8799999999987], [1.79231273E12, 3549.119999999991], [1.792312685E12, 453.4999999999997], [1.79231277E12, 829.8500000000001], [1.79231265E12, 914.289999999999], [1.792312735E12, 2707.5000000000114], [1.79231269E12, 1270.0], [1.792312775E12, 1959.2599999999998], [1.792312655E12, 734.8499999999995], [1.79231274E12, 470.0], [1.792312695E12, 774.2800000000016], [1.79231266E12, 1154.2999999999988], [1.792312745E12, 3137.0], [1.7923127E12, 5292.0], [1.792312665E12, 936.9900000000004], [1.79231275E12, 5672.639999999993], [1.792312705E12, 637.1399999999999], [1.79231267E12, 1183.12], [1.792312755E12, 791.6000000000006], [1.792312625E12, 209.0], [1.79231271E12, 968.8500000000001], [1.79231272E12, 1718.2400000000002], [1.792312675E12, 867.1499999999982], [1.79231276E12, 624.3099999999989], [1.79231263E12, 1632.0499999999995], [1.792312715E12, 708.0000000000008], [1.79231264E12, 864.0699999999999], [1.792312725E12, 1114.1199999999965], [1.79231268E12, 652.1199999999999], [1.792312765E12, 396.9], [1.792312635E12, 1955.5]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.792312645E12, 421.0], [1.79231273E12, 247.0], [1.792312685E12, 157.0], [1.79231277E12, 212.0], [1.79231265E12, 265.5], [1.792312735E12, 260.0], [1.79231269E12, 162.0], [1.792312775E12, 176.0], [1.792312655E12, 195.5], [1.79231274E12, 198.0], [1.792312695E12, 153.0], [1.79231266E12, 241.0], [1.792312745E12, 238.0], [1.7923127E12, 1830.0], [1.792312665E12, 217.5], [1.79231275E12, 473.0], [1.792312705E12, 243.0], [1.79231267E12, 175.0], [1.792312755E12, 177.0], [1.792312625E12, 201.0], [1.79231271E12, 181.0], [1.79231272E12, 252.0], [1.792312675E12, 169.5], [1.79231276E12, 172.0], [1.79231263E12, 252.5], [1.792312715E12, 159.0], [1.79231264E12, 238.0], [1.792312725E12, 169.0], [1.79231268E12, 165.0], [1.792312765E12, 200.0], [1.792312635E12, 410.0]], "isOverall": false, "label": "Median", "isController": false}, {"data": [[1.792312645E12, 746.4999999999999], [1.79231273E12, 1995.599999999999], [1.792312685E12, 289.75], [1.79231277E12, 508.4499999999999], [1.79231265E12, 599.3], [1.792312735E12, 1396.5], [1.79231269E12, 308.0], [1.792312775E12, 993.1999999999988], [1.792312655E12, 360.5], [1.79231274E12, 358.25], [1.792312695E12, 340.0], [1.79231266E12, 736.0], [1.792312745E12, 736.0], [1.7923127E12, 3428.1499999999996], [1.792312665E12, 544.3999999999996], [1.79231275E12, 3678.7999999999997], [1.792312705E12, 436.0], [1.79231267E12, 332.0], [1.792312755E12, 436.5], [1.792312625E12, 209.0], [1.79231271E12, 849.6499999999997], [1.79231272E12, 848.1999999999999], [1.792312675E12, 354.45], [1.79231276E12, 312.5999999999999], [1.79231263E12, 1309.75], [1.792312715E12, 287.3999999999997], [1.79231264E12, 521.9499999999998], [1.792312725E12, 510.4], [1.79231268E12, 416.1999999999996], [1.792312765E12, 357.9], [1.792312635E12, 1616.0]], "isOverall": false, "label": "95th percentile", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.792312775E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 161.0, "minX": 1.0, "maxY": 3311.5, "series": [{"data": [[33.0, 201.5], [32.0, 181.5], [2.0, 394.0], [34.0, 309.0], [35.0, 255.0], [37.0, 199.0], [36.0, 233.5], [39.0, 243.0], [38.0, 180.0], [41.0, 252.0], [40.0, 240.5], [43.0, 216.0], [42.0, 184.0], [44.0, 180.5], [45.0, 161.0], [47.0, 178.0], [46.0, 177.5], [48.0, 194.0], [49.0, 219.0], [50.0, 170.0], [4.0, 1428.0], [6.0, 201.0], [7.0, 464.0], [10.0, 469.0], [11.0, 455.0], [12.0, 1898.0], [13.0, 259.0], [14.0, 3311.5], [1.0, 2589.5], [18.0, 352.5], [19.0, 206.0], [23.0, 234.0], [24.0, 200.5], [25.0, 617.0], [27.0, 245.0], [28.0, 1067.0], [29.0, 259.5], [30.0, 194.0], [31.0, 244.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 50.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 153.0, "minX": 1.0, "maxY": 2144.5, "series": [{"data": [[33.0, 181.0], [32.0, 181.5], [2.0, 394.0], [34.0, 203.0], [35.0, 205.0], [37.0, 194.0], [36.0, 231.5], [39.0, 218.0], [38.0, 176.0], [41.0, 214.0], [40.0, 235.0], [43.0, 216.0], [42.0, 169.5], [44.0, 179.0], [45.0, 153.0], [47.0, 173.0], [46.0, 174.0], [48.0, 190.0], [49.0, 198.0], [50.0, 167.5], [4.0, 1233.5], [6.0, 195.0], [7.0, 464.0], [10.0, 469.0], [11.0, 455.0], [12.0, 1740.0], [13.0, 258.5], [14.0, 2144.5], [1.0, 1043.5], [18.0, 351.0], [19.0, 206.0], [23.0, 234.0], [24.0, 196.0], [25.0, 597.0], [27.0, 242.0], [28.0, 988.0], [29.0, 246.5], [30.0, 191.5], [31.0, 224.5]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 50.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 1.6, "minX": 1.792312625E12, "maxY": 43.0, "series": [{"data": [[1.792312645E12, 36.4], [1.79231273E12, 32.0], [1.792312685E12, 41.0], [1.79231277E12, 39.4], [1.79231265E12, 37.0], [1.792312735E12, 35.2], [1.79231269E12, 41.0], [1.792312775E12, 21.4], [1.792312655E12, 39.2], [1.79231274E12, 40.6], [1.792312695E12, 43.0], [1.79231266E12, 38.0], [1.792312745E12, 22.8], [1.7923127E12, 17.0], [1.792312665E12, 39.8], [1.79231275E12, 27.0], [1.792312705E12, 40.4], [1.79231267E12, 40.4], [1.792312755E12, 41.2], [1.792312625E12, 1.6], [1.79231271E12, 38.6], [1.79231272E12, 35.6], [1.792312675E12, 41.2], [1.79231276E12, 41.2], [1.79231263E12, 34.8], [1.792312715E12, 41.6], [1.79231264E12, 38.4], [1.792312725E12, 38.4], [1.79231268E12, 43.0], [1.792312765E12, 41.2], [1.792312635E12, 32.6]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.792312775E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 1.2, "minX": 1.792312625E12, "maxY": 42.8, "series": [{"data": [[1.792312645E12, 32.0], [1.79231273E12, 39.0], [1.792312685E12, 42.8], [1.79231277E12, 40.0], [1.79231265E12, 38.4], [1.792312735E12, 33.8], [1.79231269E12, 39.8], [1.792312775E12, 22.6], [1.792312655E12, 40.8], [1.79231274E12, 42.8], [1.792312695E12, 40.6], [1.79231266E12, 37.8], [1.792312745E12, 13.8], [1.7923127E12, 18.4], [1.792312665E12, 39.2], [1.79231275E12, 34.6], [1.792312705E12, 41.0], [1.79231267E12, 41.6], [1.792312755E12, 41.8], [1.792312625E12, 1.2], [1.79231271E12, 39.2], [1.79231272E12, 37.4], [1.792312675E12, 42.0], [1.79231276E12, 42.0], [1.79231263E12, 30.8], [1.792312715E12, 40.6], [1.79231264E12, 40.4], [1.792312725E12, 30.2], [1.79231268E12, 41.4], [1.792312765E12, 40.2], [1.792312635E12, 34.8]], "isOverall": false, "label": "200", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 5000, "maxX": 1.792312775E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 1.2, "minX": 1.792312625E12, "maxY": 42.8, "series": [{"data": [[1.792312645E12, 32.0], [1.79231273E12, 39.0], [1.792312685E12, 42.8], [1.79231277E12, 40.0], [1.79231265E12, 38.4], [1.792312735E12, 33.8], [1.79231269E12, 39.8], [1.792312775E12, 22.6], [1.792312655E12, 40.8], [1.79231274E12, 42.8], [1.792312695E12, 40.6], [1.79231266E12, 37.8], [1.792312745E12, 13.8], [1.7923127E12, 18.4], [1.792312665E12, 39.2], [1.79231275E12, 34.6], [1.792312705E12, 41.0], [1.79231267E12, 41.6], [1.792312755E12, 41.8], [1.792312625E12, 1.2], [1.79231271E12, 39.2], [1.79231272E12, 37.4], [1.792312675E12, 42.0], [1.79231276E12, 42.0], [1.79231263E12, 30.8], [1.792312715E12, 40.6], [1.79231264E12, 40.4], [1.792312725E12, 30.2], [1.79231268E12, 41.4], [1.792312765E12, 40.2], [1.792312635E12, 34.8]], "isOverall": false, "label": "GET - List Orders Direct Azure-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.792312775E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 1.2, "minX": 1.792312625E12, "maxY": 42.8, "series": [{"data": [[1.792312645E12, 32.0], [1.79231273E12, 39.0], [1.792312685E12, 42.8], [1.79231277E12, 40.0], [1.79231265E12, 38.4], [1.792312735E12, 33.8], [1.79231269E12, 39.8], [1.792312775E12, 22.6], [1.792312655E12, 40.8], [1.79231274E12, 42.8], [1.792312695E12, 40.6], [1.79231266E12, 37.8], [1.792312745E12, 13.8], [1.7923127E12, 18.4], [1.792312665E12, 39.2], [1.79231275E12, 34.6], [1.792312705E12, 41.0], [1.79231267E12, 41.6], [1.792312755E12, 41.8], [1.792312625E12, 1.2], [1.79231271E12, 39.2], [1.79231272E12, 37.4], [1.792312675E12, 42.0], [1.79231276E12, 42.0], [1.79231263E12, 30.8], [1.792312715E12, 40.6], [1.79231264E12, 40.4], [1.792312725E12, 30.2], [1.79231268E12, 41.4], [1.792312765E12, 40.2], [1.792312635E12, 34.8]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 5000, "maxX": 1.792312775E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

